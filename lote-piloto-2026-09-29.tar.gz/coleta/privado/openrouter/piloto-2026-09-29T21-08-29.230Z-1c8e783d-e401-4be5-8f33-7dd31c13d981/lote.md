# Lote OpenRouter - privado

- versao_protocolo: 3.2
- condicao_experimental: openrouter-v1
- modo_entrega_planejado: api-openrouter-v1
- formato_coleta: registro-unico-v1 + comprovantes JSON/SSE
- fase: PILOTO
- criado_em: 2026-09-29T21:08:29.232Z
- agente: coletor-isolado 0.1.0; uma chamada por execução; sem ferramentas ou memória
- ordem: sorteada por rodada antes da primeira chamada; plano abaixo preservado
- timeout_e_reenvios: timeout configurado por chamada; nenhum reenvio automático de geração
- fontes: textos congelados em privado/pedidos/; sources_reviewed é declaração humana, não validação científica automática
- B01: preparação por IA; revisão humana PENDENTE - somente piloto
- B02: preparação por IA; revisão humana PENDENTE - somente piloto
- metas_E1_E2_E3: N/A - não definidas por este coletor
- cambio: 5.2204 BRL/USD; 2026-09-29; PTAX venda BCB (Olinda CotacaoDolarPeriodo), 2026-09-29 13:06
- duracao: envio HTTP até término ou falha do stream, incluindo instrumentação de recebimento; sem consultas posteriores de accounting
- primeiro_texto: primeiro delta de conteúdo, excluindo raciocínio, comentários SSE e cabeçalhos
- configuracoes_ocultas: NÃO OBSERVÁVEL no provedor; ausência local de skills não elimina processamento interno do serviço

## Sistemas

| ID | Modelo solicitado | Provedor/endpoint solicitado |
| --- | --- | --- |
| S01 | anthropic/claude-opus-5.5 | anthropic |
| S02 | anthropic/claude-fable-5.1 | anthropic |
| S03 | openai/gpt-6-astra | openai |
| S04 | deepseek/deepseek-v4.1-flash | deepseek |
| S05 | meta/muse-spark-1.3 | meta |
| S06 | google/gemini-3.8-flash | google-ai-studio |

Parâmetros, limites e configuração completos: privado/configuracao.json.
Prompts e fontes efetivamente enviados: comprovantes/ID/pedido.json.
Cópia do código executado: privado/coletor/.

## Execuções previstas - nesta ordem

| Execução planejada | Sistema | Tema | Rodada | Arquivo coletado |
| --- | --- | --- | --- | --- |
| E25922611554175891518 | S02 | B01 | R01 | E25922611554175891518.md |
| E68880818928863924961 | S05 | B01 | R01 | E68880818928863924961.md |
| E80752978413979810356 | S05 | B02 | R01 | E80752978413979810356.md |
| E07644098396951605804 | S06 | B01 | R01 | E07644098396951605804.md |
| E86162589542085224347 | S03 | B01 | R01 | E86162589542085224347.md |
| E96290365979597406061 | S01 | B02 | R01 | E96290365979597406061.md |
| E12450941380389559652 | S03 | B02 | R01 | E12450941380389559652.md |
| E47419489525169154278 | S06 | B02 | R01 | E47419489525169154278.md |
| E43188925521530890203 | S02 | B02 | R01 | E43188925521530890203.md |
| E50351026877923322685 | S04 | B02 | R01 | E50351026877923322685.md |
| E49292865337802493735 | S04 | B01 | R01 | E49292865337802493735.md |
| E32822649626684547951 | S01 | B01 | R01 | E32822649626684547951.md |

O vínculo acima é reservado antes das chamadas; arquivo ausente não prova que a execução começou.
metricas.csv inclui somente tentativas registradas e nunca substitui o plano ou os comprovantes.
PENDENTE de telemetria não significa custo zero e não autoriza remover a tentativa da análise de falhas.
COMPLETA se refere à telemetria, não à qualidade da explicação ou ao APTO científico.

## Avaliadores - preencher antes do julgamento

- JC_configuracao: NÃO INFORMADO
- JP_configuracao: NÃO INFORMADO
- JT_metodo: NÃO INFORMADO - o coletor fornece evidências, não atribui T1/T2
- JE_metodo: aritmética do coletor para valores brutos; metas e notas E ainda não definidas
- passagens: JC1 e JP1 primárias; JC2 e JP2 para estabilidade
- revisao_humana: PENDENTE
