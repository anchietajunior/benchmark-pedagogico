# Resultado da coleta

- Execuções planejadas: 12.
- Tentativas registradas: 12.
- Linhas sem registro final: 0; confira o planejamento e os comprovantes, sem presumir falha ou ausência de início.
- Telemetria completa: 12.
- Telemetria pendente: 0.
- Custo conhecido: R$ 10.964717; soma das chamadas com cobrança reportada.

Abra metricas.csv para a tabela e entrada/ para as explicações com cabeçalho privado.
Não envie esses arquivos identificados diretamente aos juízes científicos ou pedagógicos.
Use PREPARAR-JULGAMENTO.md na sessão organizadora.
Não há notas automáticas de ciência ou pedagogia, nem aprovação científica implícita.

Para consultar novamente os dados faltantes, sem outra geração:

```sh
npm run recuperar -- '/home/user/benchmark-pedagogico/coleta/privado/openrouter/piloto-2026-09-29T21-08-29.230Z-1c8e783d-e401-4be5-8f33-7dd31c13d981'
```

As primeiras respostas e os registros de entrada não são substituídos por conciliações.
Os arquivos metricas.csv e comprovantes/ID/metricas.json são visões derivadas atualizáveis.
