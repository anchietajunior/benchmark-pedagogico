# Parecer JT: protocolo 3.2

Versão 3.2 | Execução E80752978413979810356 | Código Qde95149115a64f578c641e7d12bdb462 | Tema B02 | Rodada 1 | Papel JT
Situação operacional: conclusão normal. A execução foi iniciada, segundo o registro_operacional, e não há ocorrências registradas.
Ramo: explicação.

## T1: conclusão técnica
T1 = 100. O registro indica iniciada = true, status "conclusão normal" e nenhuma ocorrência. O original não está vazio e termina com a lista completa de fontes, sem sinal de truncamento.

## Tabela F/FP
| Item F/FP | Nota | Evidência | Modalidade | Verificador/versão |
| --- | --- | --- | --- | --- |
| F1 | 100 | A primeira linha não vazia é "# Resposta imune adaptativa e memória imunológica". | LLM | Nenhum verificador versionado |
| F2 | 0 | Contei cerca de 1.658 palavras antes de "## Fontes consultadas", acima do máximo de 1.200. Somente título, Ideia central, Conceitos, Mecanismo e Exemplo já somam cerca de 1.299 palavras. | LLM (contagem manual pela convenção do protocolo) | Nenhum verificador versionado |
| F3 | 100 | As oito seções aparecem uma vez cada, na ordem exigida, e nenhuma está vazia. Confusões a evitar tem 2 itens numerados. Confira seu entendimento tem 2 perguntas numeradas, cada uma com "Resposta comentada:" preenchida. Síntese tem 3 itens de lista. | LLM | Nenhum verificador versionado |
| F4 | 100 | A seção final "## Fontes consultadas" traz os identificadores autorizados [B02-F3], [B02-F4] e [B02-F5], com títulos, seções consultadas e DOI. | LLM | Nenhum verificador versionado |
| F5 | N/A | A inspeção por LLM não encontrou declaração de autoria de modelo ou fornecedor nem imagem em Markdown ou HTML. Mesmo assim, o protocolo exige revisão humana, que ainda não foi feita. | LLM (preliminar); inspeção humana pendente | Nenhum |
| FP1-FP3 | N/A | Não se aplicam porque o ramo é explicação, não PENDENTE DE FONTES. | Não aplicável | Nenhum |

## T2
T2 = N/A. O ramo é explicação, então a fórmula é (F1+F2+F3+F4+F5)/5. Os itens conhecidos somam 300 em 400 possíveis. Como F5 está N/A, o denominador não pode ser reduzido. Quando a revisão humana for feita, T2 só poderá valer 80 (se F5 = 100) ou 60 (se F5 = 0), porque F2 = 0 é um descumprimento já observado.

## Pendências e limitações
- F5 aguarda revisão humana de autoria explícita.
- Nenhum teste programático foi executado. A contagem de palavras (cerca de 1.658) foi manual, feita por LLM, e pode ter uma pequena margem de erro. Essa margem não muda F2, porque o excesso passa de 400 palavras.
- Não há rastros de ferramentas nem do agente, por isso não atribuo notas de planejamento ou de uso de ferramentas.
- Este parecer não inclui avaliação científica, pedagógica, de tempo ou de custo.