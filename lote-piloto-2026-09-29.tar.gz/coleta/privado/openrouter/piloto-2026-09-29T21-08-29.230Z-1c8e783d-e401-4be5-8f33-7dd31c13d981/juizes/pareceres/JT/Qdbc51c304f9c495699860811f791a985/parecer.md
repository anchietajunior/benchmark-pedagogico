# Parecer JT — protocolo 3.2

**Identificação:** versão 3.2 · execução E49292865337802493735 · tema B01 · rodada 1 · papel JT · código Qdbc51c304f9c495699860811f791a985.

**Situação operacional:** execução iniciada (iniciada = true), com conclusão normal e sem ocorrências registradas.

**Ramo da saída:** explicação. A resposta não começa com PENDENTE DE FONTES, não é uma recusa e tem saída não vazia.

## T1 — Conclusão técnica
**T1 = 100.**
- O registro operacional informa conclusão normal e nenhuma ocorrência.
- O original está completo: tem título, as oito seções e termina na seção de fontes com uma nota final. Não há sinal de truncamento.

## Conformidade formal (ramo explicação)

| Item F/FP | Nota 0/100/N/A | Evidência | Modalidade de verificação | Verificador/versão |
|---|---|---|---|---|
| F1 | 100 | A primeira linha não vazia é "# Como o organismo contém uma pequena hemorragia e delimita a resposta". | LLM (inspeção textual) | Não há verificador programático |
| F2 | 0 | O corpo antes de "## Fontes consultadas" tem cerca de 1.245 palavras, acima do limite de 1.200. | LLM (contagem manual pela convenção 3.2) | Não há verificador programático |
| F3 | 100 | As oito seções aparecem uma vez cada, na ordem exigida, e todas têm conteúdo. Confusões: exatamente 2 itens numerados. Perguntas: exatamente 2 numeradas, cada uma com "Resposta comentada:" preenchida. Síntese: exatamente 3 itens de lista. Os subtítulos ### ficam dentro de "Mecanismo passo a passo". | LLM (inspeção estrutural) | Não há verificador programático |
| F4 | 100 | A seção final "## Fontes consultadas" traz os identificadores autorizados [B01-F3], [B01-F2], [B01-F4] e [B01-F5], com título, seções e endereço/DOI. Só a presença formal foi conferida. | LLM (inspeção textual) | Não há verificador programático |
| F5 | N/A | A leitura pelo LLM não encontrou declaração de autoria do modelo ou fornecedor nem imagem Markdown/HTML. Mesmo assim, o protocolo exige inspeção humana, que ainda não foi feita. | LLM (triagem preliminar); inspeção humana pendente | — |
| FP1 | N/A | Não se aplica: o ramo é explicação. | — | — |
| FP2 | N/A | Não se aplica: o ramo é explicação. | — | — |
| FP3 | N/A | Não se aplica: o ramo é explicação. | — | — |

### Como as palavras foram contadas (F2)
Contei o texto anterior à linha "## Fontes consultadas". Entram o título, os subtítulos, os números de item ("1.", "2." etc.) e os identificadores de citação, como [B01-F3]. Termos unidos por hífen, barra ou travessão contam como uma palavra; marcadores Markdown isolados e o travessão isolado não contam.

Totais cumulativos por seção:

| Até o fim de | Palavras acumuladas |
|---|---|
| Título + Ideia central | 96 |
| Conceitos necessários | 206 |
| Mecanismo passo a passo (pontos 1–6) | 822 |
| Exemplo explicado | 951 |
| Confusões a evitar | 1.040 |
| Confira seu entendimento | 1.171 |
| Síntese | 1.245 |

A contagem manual por LLM tem margem de erro de poucas palavras. O excesso de cerca de 45 palavras é bem maior que essa margem, por isso a decisão F2 = 0 é robusta. Ainda assim, ela deve ser confirmada por contador programático.

## T2 — Conformidade formal
- **Ramo:** explicação. Fórmula: T2 = (F1 + F2 + F3 + F4 + F5) / 5.
- **Valores:** F1 = 100, F2 = 0, F3 = 100, F4 = 100, F5 = N/A.
- **Resultado:** o protocolo proíbe reduzir o denominador, então **T2 = N/A**. Numerador conhecido: 300; denominador: 5.
- **Limites, apenas informativos (não são T2):** 60 se a inspeção humana der F5 = 0; 80 se der F5 = 100.

## Pendências e limitações
- **F5:** falta a inspeção humana de autoria explícita. T2 só pode ser fechado depois dela.
- **Verificação:** nenhum verificador programático foi executado. Todas as verificações foram feitas por LLM e não devem ser descritas como testes determinísticos.
- **F2:** recomendo confirmar a contagem com um script que use a convenção 3.2.
- **Rastros do agente:** não há rastros de ferramentas nem de planejamento. A avaliação cobre só o output (condição openrouter-v1, uma chamada), sem notas de planejamento ou de uso de ferramentas.
- **Fora do escopo do JT:** F4 só confirma a presença formal das referências; existência e sustentação são do JC. F2 e F3 não medem qualidade nem aprendizagem.
- **Fontes:** a nota final da seção de fontes registra consulta indireta às fontes F2, F4 e F5. Isso não foi avaliado aqui, porque é competência do JC.
- **Sigilo:** nenhuma informação de autoria ou dado operacional deve ser encaminhada ao JC ou ao JP.