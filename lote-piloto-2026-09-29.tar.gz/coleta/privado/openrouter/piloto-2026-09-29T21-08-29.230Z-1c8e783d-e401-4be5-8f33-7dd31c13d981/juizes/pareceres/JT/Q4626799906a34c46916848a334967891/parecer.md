# Parecer JT: protocolo 3.2

**Dados da avaliação:** versão 3.2 | execução E96290365979597406061 | tema B02 | rodada 1 | papel JT | código Q4626799906a34c46916848a334967891

- **Situação operacional:** conclusão normal. A execução foi iniciada, e o registro traz `iniciada: true`, `status_operacional: "conclusão normal"` e nenhuma ocorrência.
- **Ramo:** explicação. Não é PENDENTE DE FONTES, recusa nem ausência de saída.

## T1: conclusão técnica
**T1 = 100.**
- Saída não vazia.
- Término normal registrado.
- Nenhum erro técnico em `ocorrencias`.
- Não há sinal de truncamento: o original termina com a seção `## Fontes consultadas` completa, com três fontes e endereços.

## Itens formais (aplicados ao original)

| Item F/FP | Nota | Evidência | Modalidade de verificação | Verificador/versão |
|---|---|---|---|---|
| F1 | 100 | A primeira linha não vazia é "# Resposta imune adaptativa: do reconhecimento do antígeno à memória imunológica". | Inspeção por LLM | Nenhum verificador programático |
| F2 | 0 | O corpo antes de "## Fontes consultadas" tem cerca de 1.642 palavras. Com os marcadores numéricos de lista ("1.", "2." etc.), são cerca de 1.656. Os dois valores estão acima do máximo de 1.200. O limite de 1.200 já era ultrapassado antes do fim de "## Exemplo explicado" (cerca de 1.201 palavras até o 3º item de "Contato posterior"). Ainda faltavam as seções de confusões, perguntas e síntese. | Contagem manual por LLM | Nenhum verificador programático |
| F3 | 100 | As oito seções aparecem uma vez cada e na ordem exigida, todas com conteúdo: Ideia central → Conceitos necessários → Mecanismo passo a passo → Exemplo explicado → Confusões a evitar → Confira seu entendimento → Síntese → Fontes consultadas. Os subtítulos `###` estão dentro de "Mecanismo passo a passo". "Confusões a evitar" tem 2 itens numerados. "Confira seu entendimento" tem 2 perguntas numeradas, cada uma com "Resposta comentada:" preenchida. "Síntese" tem 3 itens de lista. | Inspeção por LLM | Nenhum verificador programático |
| F4 | 100 | A última seção é "## Fontes consultadas". Ela traz os identificadores autorizados [B02-F3], [B02-F4] e [B02-F5], com título, seções consultadas e DOI/URL. Aqui se confere só a presença formal; existência e sustentação cabem a JC. | Inspeção por LLM | Nenhum verificador programático |
| F5 | N/A | O protocolo exige inspeção humana, que ainda não foi feita segundo o registro de testes. Na leitura por LLM, não encontrei declaração de autoria de modelo/fornecedor nem imagem em Markdown/HTML. Essa observação é só indicativa e não substitui a revisão humana. | LLM (indicativo); inspeção humana pendente | N/A |
| FP1 | N/A | Não se aplica: o ramo é explicação. | — | — |
| FP2 | N/A | Não se aplica: o ramo é explicação. | — | — |
| FP3 | N/A | Não se aplica: o ramo é explicação. | — | — |

## T2: conformidade formal (ramo explicação)
**T2 = N/A.**
- Fórmula: T2 = (F1 + F2 + F3 + F4 + F5) / 5.
- Como F5 é N/A (revisão humana pendente), T2 fica N/A. Pelo protocolo, o denominador não pode ser reduzido.
- Parcial informativo, que não é T2: F1 + F2 + F3 + F4 = 100 + 0 + 100 + 100 = 300 de 400 conhecidos.
- Se a revisão humana der F5 = 100, T2 = 400/5 = 80. Se der F5 = 0, T2 = 60.
- Em qualquer caso, o descumprimento de F2 (extensão acima da faixa de 800 a 1.200) já foi observado e continua registrado.

## Convenção de contagem (PALAVRAS_CORPO)
- **O que foi contado:** o texto antes da primeira linha exatamente "## Fontes consultadas", incluindo título, subtítulos, exemplo, confusões, perguntas, respostas e síntese.
- **Critério:** cada sequência separada por espaço ou quebra de linha que tenha letra ou número. Citações como "[B02-F3]" e expressões como "30%" contam. Marcadores isolados (#, -, **) não contam.
- **Marcadores numéricos:** os 14 marcadores de lista ou subtítulo numerados ("1." etc.) ficaram de fora do valor principal, com sensibilidade informada. Por serem ambíguos, o valor principal é 1.642 e o alternativo é 1.656.
- **Precisão:** a contagem foi manual, feita por LLM, e pode ter erro de poucas unidades. A distância de mais de 400 palavras em relação ao limite torna a conclusão F2 = 0 robusta.

## Pendências e limitações
- **F5:** falta a inspeção humana, que também define T2.
- **Verificadores:** nenhum verificador programático foi executado. As verificações foram feitas por LLM e não devem ser descritas como testes determinísticos.
- **Rastros do agente:** não há rastros de ferramentas nem de passos. Avaliei apenas o output, sem notas de planejamento ou uso de ferramentas (condição openrouter-v1, sem ferramentas).
- **Escopo deste papel:** não avaliei conteúdo científico, pedagogia, tempo nem custo. Não faço média T1/T2.
- **Sigilo:** o original não deve ser encaminhado a JC nem a JP.