# Parecer JT: protocolo 3.2

**Execução:** E47419489525169154278. **Código:** Qbcccc7df15134cf3b3aaeb735e4bd97a. **Tema:** B02. **Rodada:** 1. **Papel:** JT.
**Modo de entrega:** condição openrouter-v1. O pedido arquivado segue o protocolo 3.2; não é uma coleta 3.1.
**Situação operacional:** conclusão normal. **Execução iniciada:** sim. **Ramo:** explicação.

## T1: conclusão técnica
**T1 = 100.** O registro operacional informa `iniciada: true` e `status_operacional: "conclusão normal"`, sem nenhuma ocorrência. O original fornecido não está vazio e termina de forma completa com a seção `## Fontes consultadas`. Não há sinal de truncamento.

## Conferência formal (ramo explicação, feita no original)

| Item F/FP | Nota 0/100/N/A | Evidência | Modalidade de verificação | Verificador/versão |
|---|---|---|---|---|
| F1 | 100 | A primeira linha não vazia é `# Resposta imune adaptativa e memória imunológica`. | LLM (inspeção textual) | Sem verificador programático; não houve execução automática |
| F2 | 0 | Contagem manual, feita por LLM com a convenção do protocolo, do texto antes de `## Fontes consultadas`: cerca de 1.559 palavras (margem estimada de ±30). Subtotais cumulativos: até o Mecanismo, cerca de 903; até o Exemplo, cerca de 1.116; até as Confusões, cerca de 1.247; até o Confira, cerca de 1.450; até a Síntese, cerca de 1.559. O limite de 1.200 já é ultrapassado antes da seção "Confira seu entendimento". | LLM (contagem manual) | Sem verificador programático; o valor é estimativa, não teste determinístico |
| F3 | 100 | As oito seções aparecem uma vez cada e na ordem exigida: Ideia central, Conceitos necessários, Mecanismo passo a passo (com subtítulos ###), Exemplo explicado, Confusões a evitar, Confira seu entendimento, Síntese e Fontes consultadas. Todas têm conteúdo. Há exatamente 2 confusões numeradas e 2 perguntas numeradas, cada uma com `Resposta comentada:` preenchida. A Síntese tem exatamente 3 itens de lista. | LLM (inspeção estrutural) | Sem verificador programático |
| F4 | 100 | A seção final `## Fontes consultadas` lista [B02-F3], [B02-F4] e [B02-F5]. Todos são identificadores autorizados, com título, seções consultadas e endereço DOI. A consulta indireta pelas notas está indicada em B02-F5. Aqui só se confere a presença formal; a validade das fontes cabe a JC. | LLM (inspeção textual) | Sem verificador programático |
| F5 | N/A | A leitura por LLM não encontrou declaração de autoria do modelo ou do fornecedor, nem imagem em Markdown ou HTML. Mesmo assim, o protocolo exige inspeção humana de autoria explícita, que ainda não foi feita (campo `testes`). | LLM (preliminar); inspeção humana pendente | — |
| FP1 | N/A | Não se aplica: o ramo é explicação, não PENDENTE DE FONTES. | — | — |
| FP2 | N/A | Não se aplica: o ramo é explicação. | — | — |
| FP3 | N/A | Não se aplica: o ramo é explicação. | — | — |

## T2: conformidade formal
**T2 = N/A.** Ramo explicação: T2 = (F1 + F2 + F3 + F4 + F5) / 5.
- **Itens conhecidos:** F1 = 100, F2 = 0, F3 = 100 e F4 = 100, que somam 300.
- **Item faltante:** F5 = N/A, porque a revisão humana está pendente.
- **Regra aplicada:** um item formal necessário em N/A torna T2 N/A. O denominador não foi reduzido para 4.
- **Faixa possível:** depois da revisão de F5, T2 só poderá ser 60 (F5 = 100) ou 40 (F5 = 0). Isso não substitui o valor oficial.

## Pendências e limitações
- Nenhum verificador programático foi executado. Todas as verificações foram feitas por LLM e não devem ser descritas como testes determinísticos.
- A contagem de F2 é manual e aproximada. Ainda assim, o excesso sobre 1.200 palavras (mais de 300) supera com folga a margem de erro. Recomenda-se confirmar com um contador programático que use a convenção do protocolo.
- F5 depende de inspeção humana de autoria explícita, e é isso que impede calcular T2.
- Não há rastros de ferramentas nem do processo do agente. Por isso, não foram atribuídas notas de planejamento ou de uso de ferramentas; o parecer avalia apenas o output.
- JT não avaliou correção científica, qualidade pedagógica, tempo ou custo. A situação operacional pode ser repassada a JE sem notas T. O original com eventual autoria não deve ser encaminhado a JC ou JP.