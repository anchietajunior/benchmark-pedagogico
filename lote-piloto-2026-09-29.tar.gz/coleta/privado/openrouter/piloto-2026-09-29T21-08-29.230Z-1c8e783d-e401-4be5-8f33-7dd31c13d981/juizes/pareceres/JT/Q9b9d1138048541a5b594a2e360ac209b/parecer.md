# Parecer JT – protocolo 3.2

- Versão: 3.2 | Código: Q9b9d1138048541a5b594a2e360ac209b | Execução: E50351026877923322685
- Tema: B02 | Rodada: 1 | Papel: JT
- Situação operacional: iniciada; conclusão normal (registro_operacional sem ocorrências)
- Ramo de saída: explicação (checklist F1-F5; FP1-FP3 não se aplicam)

## T1 – Conclusão técnica
T1 = 100. O registro indica "iniciada": true, "status_operacional": "conclusão normal" e nenhuma ocorrência. O original não está vazio e termina de forma completa na seção "## Fontes consultadas", sem corte no meio de frase. Não há sinal de erro ou truncamento.

## Tabela de itens formais
| Item F/FP | Nota 0/100/N/A | Evidência | Modalidade de verificação | Verificador/versão |
| --- | --- | --- | --- | --- |
| F1 | 100 | A primeira linha não vazia é "# Resposta imune adaptativa e memória imunológica". | Inspeção por LLM | Nenhum verificador programático; LLM avaliador (sessão JT) |
| F2 | 0 | A contagem manual do texto anterior a "## Fontes consultadas" deu cerca de 1.215 palavras, fora da faixa de 800 a 1.200. Na contagem entram título, subtítulos (inclusive "1."-"6."), identificadores como "[B02-F3;" e "B02-F4]" e o marcador "Resposta comentada:". Estimativa por seção: título 6; Ideia central ≈ 62; Conceitos ≈ 155; Mecanismo ≈ 555; Exemplo ≈ 177; Confusões ≈ 80; Confira ≈ 115; Síntese ≈ 75. Na recontagem de amostra, os ajustes aumentaram o total (mais de 1.200 em todas as revisões). | Inspeção por LLM (contagem manual) | Nenhum verificador programático executado; a contagem é aproximada e deve ser confirmada |
| F3 | 100 | As oito seções "## Ideia central", "## Conceitos necessários", "## Mecanismo passo a passo", "## Exemplo explicado", "## Confusões a evitar", "## Confira seu entendimento", "## Síntese" e "## Fontes consultadas" aparecem uma vez cada, na ordem exigida e com conteúdo. Os subtítulos "###" dentro do Mecanismo são permitidos. Confusões: exatamente 2 itens numerados. Confira: exatamente 2 perguntas numeradas, cada uma com "**Resposta comentada:**" seguida de texto (o marcador está em negrito, mas contém a cadeia exigida). Síntese: exatamente 3 itens de lista com "-". | Inspeção por LLM | Nenhum verificador programático |
| F4 | 100 | A seção final "## Fontes consultadas" traz os identificadores autorizados [B02-F3], [B02-F4] e [B02-F5], com título, seções e DOI. Isso confere só a presença formal; existência e sustentação das fontes cabem ao JC. | Inspeção por LLM | Nenhum verificador programático |
| F5 | N/A | A leitura por LLM não encontrou imagem incorporada (Markdown ou HTML) nem declaração de autoria de modelo ou fornecedor. Porém o protocolo e o campo "testes" exigem revisão humana de autoria explícita, que não foi feita. | Inspeção por LLM (parcial); inspeção humana pendente | — |
| FP1 | N/A | Não se aplica: o ramo é explicação, não PENDENTE DE FONTES. | — | — |
| FP2 | N/A | Não se aplica: o ramo é explicação. | — | — |
| FP3 | N/A | Não se aplica: o ramo é explicação. | — | — |

## T2 – Conformidade formal
- Ramo: explicação. Fórmula: T2 = (F1 + F2 + F3 + F4 + F5) / 5.
- Valores conhecidos: F1 = 100, F2 = 0, F3 = 100, F4 = 100. F5 = N/A.
- Como um item necessário está N/A, T2 = N/A. O denominador não foi reduzido para 4.
- Apenas como referência, sem valor de nota: se a revisão humana confirmar F5 = 100 e a contagem programática confirmar F2 = 0, T2 seria 400/5 = 80.

## Pendências e limitações
1. F5 depende da revisão humana de autoria explícita (pendente). Por isso T2 fica N/A.
2. F2 veio de contagem manual por LLM, não de teste determinístico. O excesso estimado é pequeno (cerca de 15 palavras), então é preciso confirmar com um contador programático que siga a convenção do protocolo.
3. Nenhum verificador formal foi executado ("testes": nenhum). Todas as verificações foram feitas por LLM e não devem ser descritas como testes programáticos.
4. Não há rastros de ferramentas nem de chamadas do agente. Sem eles, não foi atribuída nota de planejamento, navegação ou uso de ferramentas. A avaliação cobre apenas a saída.
5. Este parecer não traz notas científicas ou pedagógicas, tempo, custo ou ranking. As informações de autoria do original não devem ser encaminhadas a JC nem a JP.