# Parecer JT: protocolo 3.2

- Versão: 3.2
- Execução: E68880818928863924961
- Código: Q474158c81c3e453b94fb3b7230c84d26
- Tema: B01
- Rodada: 1
- Papel: JT
- Condição do pedido: openrouter-v1

**Situação operacional:** a execução foi iniciada e terminou com conclusão normal. O registro não traz ocorrências.
**Ramo da saída:** explicação. Aplico F1-F5; FP1-FP3 não se aplicam.

## T1: conclusão técnica
- **T1 = 100.**
- Evidência: o registro operacional informa `iniciada: true`, `status_operacional: "conclusão normal"` e nenhuma ocorrência.
- A saída não está vazia e termina de forma completa na seção `## Fontes consultadas`, com quatro referências inteiras. Não há sinal de truncamento.

## Itens formais (verificados no original)

| Item F/FP | Nota 0/100/N/A | Evidência | Modalidade de verificação | Verificador/versão |
|---|---|---|---|---|
| F1 | 100 | A primeira linha não vazia é `# Como um pequeno corte para de sangrar sem entupir o vaso`. | LLM (inspeção textual) | Não há verificador versionado |
| F2 | 0 | O corpo antes de `## Fontes consultadas` tem cerca de 1.820 palavras pela convenção 3.2. A contagem acumulada já passa de 1.200 na subseção "### 6. Quando a proteção vira trombose", antes de Exemplo, Confusões, Perguntas e Síntese. A faixa pedida é de 800 a 1.200. | LLM (contagem manual estimada) | Não há verificador versionado |
| F3 | 100 | As oito seções aparecem uma vez, com os títulos exatos, na ordem definida e com conteúdo. Os subtítulos `###` ficam dentro de Mecanismo, o que é permitido. Confusões tem exatamente dois itens numerados. Confira tem exatamente duas perguntas numeradas, cada uma com `Resposta comentada:` preenchida. Síntese tem exatamente três itens de lista. | LLM (inspeção estrutural) | Não há verificador versionado |
| F4 | 100 | A seção final `## Fontes consultadas` traz os identificadores autorizados [B01-F3], [B01-F2], [B01-F4] e [B01-F5], com título, seções ou escopo e endereço. Isso confere apenas a presença formal; existência e sustentação das fontes cabem a JC. | LLM (inspeção textual) | Não há verificador versionado |
| F5 | N/A | Na leitura por LLM, não encontrei declaração de autoria do modelo ou fornecedor nem imagem em Markdown ou HTML. Porém, o protocolo e o registro de testes exigem revisão humana, que ainda não foi feita. | LLM (triagem preliminar); inspeção humana pendente | Não há verificador versionado |
| FP1 | N/A | Não se aplica: o ramo é explicação. | Não se aplica | Não se aplica |
| FP2 | N/A | Não se aplica: o ramo é explicação. | Não se aplica | Não se aplica |
| FP3 | N/A | Não se aplica: o ramo é explicação. | Não se aplica | Não se aplica |

## T2: conformidade formal (ramo explicação)
- Fórmula: T2 = (F1 + F2 + F3 + F4 + F5) / 5.
- Valores apurados: F1 = 100, F2 = 0, F3 = 100 e F4 = 100. A soma parcial é 300.
- F5 está N/A, e o protocolo não permite calcular T2 com um denominador menor.
- **T2 = N/A.** O numerador fica indefinido e o denominador é 5.
- Depois da revisão humana de F5, T2 só poderá ser 80 (se F5 = 100) ou 60 (se F5 = 0). Deixo esses valores apenas como memória de cálculo, não como nota.

## Contagem de palavras (PALAVRAS_CORPO)
- Segui a convenção 3.2: contei o texto antes da primeira linha `## Fontes consultadas`, incluindo título, subtítulos e citações.
- Contei cada sequência com pelo menos uma letra ou número. Marcadores isolados como `#`, `-` e `–` não entraram na contagem.
- Parciais acumuladas aproximadas:
  - Ideia central, com o título: cerca de 116.
  - Fim de Conceitos: cerca de 340.
  - Fim do passo 5 do Mecanismo: cerca de 1.171.
  - Fim do Mecanismo: cerca de 1.269.
  - Total: cerca de 1.820.
- As citações longas, como "[B01-F2 – consulta indireta via notas de leitura]" (7 palavras), aumentam bastante a contagem. O protocolo proíbe removê-las.
- Mesmo com erro de contagem de ±10%, o total fica acima de 1.200. Por isso, F2 = 0 é uma decisão robusta.

## Pendências e limitações
1. F5 depende da inspeção humana de autoria explícita. Enquanto ela não for feita, T2 fica N/A.
2. Nenhum verificador programático foi executado. Todas as verificações foram inspeção ou contagem por LLM, sem teste determinístico, e o valor de PALAVRAS_CORPO é aproximado.
3. Não há rastros de ferramentas nem de planejamento do agente. A condição foi uma única chamada, sem ferramentas, então não atribuo notas de planejamento, navegação ou uso de ferramentas.
4. Não avaliei correção científica, qualidade pedagógica, fontes, tempo ou custo, e não produzi média geral.
5. O original identificado não deve ser encaminhado a JC nem a JP.