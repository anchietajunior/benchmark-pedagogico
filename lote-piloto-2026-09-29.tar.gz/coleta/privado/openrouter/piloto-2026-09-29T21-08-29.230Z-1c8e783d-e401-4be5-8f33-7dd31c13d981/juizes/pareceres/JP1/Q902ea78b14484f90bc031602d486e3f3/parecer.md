## 1. Identificação e conferência do certificado

- **Protocolo:** 3.2, com a regra 3.4 do contrato de saída, que prevalece. Por essa regra, a avaliação pedagógica é cega e não exige APTO.
- **Código público:** Q902ea78b14484f90bc031602d486e3f3
- **Tema:** B01
- **Rodada:** 1
- **Passagem:** JP1

O certificado é compatível. Ele declara versao_protocolo 3.4, o mesmo código de destino, tema B01, rodada R01 (equivale à rodada 1) e passagem JP1, com elegibilidade "Resposta completa; avaliação pedagógica cega".

O pacote veio limpo: não havia notas C, pareceres científicos, autoria, nomes de modelos, tempos ou custos. Recebi uma única resposta.

## 2. Situação pedagógica

**CONCLUÍDO**

## 3. Tabela de subcritérios

| Subcritério | Nota | Evidência | Justificativa |
| --- | --- | --- | --- |
| M1.1 | 100 | Definições no primeiro uso: endotélio ("camada celular que reveste internamente os vasos"), vasoconstrição ("estreitamento local do vaso"), fator tecidual, GPIb, fosfolipídios, protrombinase, TFPI, trombomodulina, fibrinólise, tPA, plasmina, hemostasia primária e secundária. | Os termos além do conhecimento prévio do público são definidos ou recebem uma função clara na primeira menção. ADP e tromboxano A2 aparecem como "sinais"/"mediadores" que recrutam plaquetas, o que basta para o recorte. |
| M1.2 | 100 | Exemplos: "O fator von Willebrand funciona como ligação entre o colágeno e o receptor plaquetário GPIb"; "Com auxílio da proteína S, a proteína C ativada inativa Va e VIIIa". | Os sujeitos e os referentes são identificáveis. Na resposta 1, "Ela oferece superfície" retoma "ativação plaquetária" quando o sentido é a plaqueta ativada. É uma imprecisão pequena, que não gera ambiguidade relevante. |
| M2.1 | 100 | A seção "Conceitos necessários" vem antes do mecanismo, que segue seis etapas numeradas: lesão → plaquetas → trombina/fibrina → estabilização → regulação/fibrinólise → trombose. | Os componentes aparecem antes das relações que dependem deles. As etapas seguem a lógica do processo e acompanham os seis pontos do pedido. |
| M2.2 | 100 | Síntese: "Plaquetas favorecem a produção de trombina; fibrina estabiliza o tampão, integrando hemostasia primária e secundária" e "Regulação e fibrinólise equilibram vedação, remoção e preservação do fluxo sanguíneo". | Os três itens integram o início, a cooperação e o controle, e respondem ao objetivo sem trazer pré-requisito novo. |
| M3.1 | 100 | Todas as seções tratam da lesão pequena, do tampão, da fibrina, da regulação e da trombose. Não há lista completa de fatores nem de exames. | O texto respeita as exclusões do pedido. Nenhum trecho sai do recorte. |
| M3.2 | 100 | O exemplo e a resposta 1 retomam a relação plaqueta–trombina–fibrina para aplicá-la. | As retomadas servem para aplicar ou justificar. Não há repetição sem função. |
| M4.1 | 100 | "a mesma abertura que permite o sangramento revela superfícies capazes de iniciar sua contenção"; "A trombina inicial ativa plaquetas e fatores auxiliares... ampliando as condições para sua própria produção"; "A organização sobre superfícies celulares concentra e acelera as reações"; "plaquetas sustentam complexos produtores de trombina, e trombina ativa plaquetas". | O texto explica por que cada etapa leva à seguinte, em vez de apenas listá-las. A necessidade de estabilizar é justificada de modo breve ("ainda precisa de reforço", "mais resistente"). Isso é suficiente, embora pudesse ser mais desenvolvido. |
| M4.2 | 100 | O endotélio íntegro "ao redor" libera NO e prostaciclina; antitrombina, TFPI e proteína C/S são descritos com seu efeito ("Retirar esses auxiliares reduz a amplificação"); há inibidores da plasmina, porque "a vedação precisa permanecer enquanto necessária ao reparo". A resposta 2 liga o crescimento sem controle à obstrução da circulação. | Regulação, fibrinólise e seus limites estão ligados à conclusão (resposta localizada e temporária) e à distinção em relação à trombose. |
| M5.1 | 100 | "Imagine uma pequena lesão em um vaso da pele. Inicialmente, o sangue escapa porque a parede perdeu continuidade." | A situação é concreta e é a pedida pelo tema. |
| M5.2 | 50 | **Atendido:** vasoconstrição, adesão ao colágeno exposto, fator tecidual, superfície plaquetária e fibrina aparecem com sua função; há interpretação funcional ("plaquetas fornecem fechamento inicial e superfície reacional; fibrina fornece sustentação") e um limite ("não comprova que todos os componentes estejam normais"). **Limitação:** "Os reguladores restringem sua expansão, e a fibrinólise participa da remoção" só nomeia essas etapas. | Não se diz quais reguladores atuam no exemplo (por exemplo, o endotélio íntegro vizinho) nem como eles mantêm o coágulo restrito à lesão. Assim, a etapa do exemplo mais ligada ao objetivo de "limitar ao local" fica apenas rotulada. |

## 4. Resumo e memória de cálculo

| M1 | M2 | M3 | M4 | M5 | P |
| --- | --- | --- | --- | --- | --- |
| 100 | 100 | 100 | 100 | 75 | 95 |

- M1 = (100 + 100) / 2 = 100
- M2 = (100 + 100) / 2 = 100
- M3 = (100 + 100) / 2 = 100
- M4 = (100 + 100) / 2 = 100
- M5 = (100 + 50) / 2 = 75
- P = (100 + 100 + 100 + 100 + 75) / 5 = 475 / 5 = 95

## 5. Limitações e alertas

- Esta avaliação foi feita por IA, sem estudantes, e segue a rubrica 3.2 aplicada sob a regra cega 3.4. Não verifiquei a correção científica, que cabe a outro juiz.
- Ao ler, não identifiquei erro científico evidente.
- A justificativa de por que o tampão plaquetário sozinho não basta é breve. Considerei que isso não chega a descumprir M4.1, mas outro juiz pode divergir.
- Não avaliei extensão nem conformidade formal, que cabem a JT.

As notas descrevem atendimento à rubrica e qualidade didática estimada; não demonstram compreensão ou aprendizagem humana.