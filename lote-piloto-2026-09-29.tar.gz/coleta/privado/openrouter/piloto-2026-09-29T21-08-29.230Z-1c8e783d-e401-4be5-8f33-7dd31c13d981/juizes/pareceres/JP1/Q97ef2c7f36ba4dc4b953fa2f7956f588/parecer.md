## 1. Identificação e conferência do certificado
Protocolo: 3.2, com a regra 3.4 do contrato de saída aplicada à elegibilidade. Código público: Q97ef2c7f36ba4dc4b953fa2f7956f588. Tema: B01. Rodada: 1. Passagem: JP1.

Conferência do certificado:
- Versão: 3.4, compatível com a regra que prevalece.
- Código de destino: idêntico.
- Tema: B01.
- Rodada: R01, que corresponde à rodada 1.
- Passagem: JP1.
- Elegibilidade: avaliação pedagógica cega de resposta completa, que substitui a exigência de APTO.
- Pacote: sem autoria, sem notas C, sem dados operacionais e com uma única resposta.

Resultado: certificado compatível.

## 2. Situação pedagógica
CONCLUÍDO.

## 3. Avaliação dos subcritérios
| Subcritério | Nota | Evidência | Justificativa |
|---|---|---|---|
| M1.1 | 50 | O texto define "Zimogênios (enzimas precursoras inativas)" e explica o fator XIII como "fator estabilizador de fibrina, uma enzima que estabelece ligações cruzadas covalentes". Ficam sem explicação "força mecânica de cisalhamento", "fosfolipídios aniônicos", "grânulos alfa e densos", "complexos tenase (IXa-VIIIa)", "D-dímeros", "heparansulfato" (que só aparece na resposta 2), "parietal" e "cavitárias". | Muitos termos são definidos ou descritos pela função. Porém, vários termos fora do conhecimento prévio do graduando aparecem sem explicação no primeiro uso. |
| M1.2 | 100 | Exemplos: "O fator von Willebrand (vWF) liga-se ao colágeno exposto e ancora o receptor plaquetário GpIb"; "A própria trombina ativa o fator XIII". | Os sujeitos e referentes são identificáveis, e "esse complexo" retoma claramente trombina + trombomodulina. As frases são densas e nominalizadas, mas não há ambiguidade relevante. |
| M2.1 | 100 | A resposta segue a ordem Conceitos necessários (endotélio, subendotélio, plaquetas, fatores, trombina, fibrinólise) → etapas 1 a 6 (vaso → plaquetas → trombina/fibrina → estabilização → regulação → trombose). Na etapa 3, a sequência é iniciação → amplificação → propagação. | Os componentes aparecem antes das relações que dependem deles, e cada etapa parte do produto da etapa anterior. |
| M2.2 | 50 | A Síntese integra plaquetas, trombina/fibrina com o fator XIII e a regulação/fibrinólise. | A síntese responde por que o tampão precisa de estabilização, mas não retoma por que formar coágulos sem controle é um problema nem a distinção com a trombose, que fazem parte do objetivo. |
| M3.1 | 100 | Todas as seções tratam dos seis pontos. O texto não enumera todos os fatores nem exames; a menção a D-dímeros é um parêntese breve. | Os trechos contribuem para o recorte pedido. |
| M3.2 | 100 | O exemplo e a resposta 2 retomam a regulação para aplicá-la à punção. A confusão 1 retoma a integração da etapa 4 para desfazer um equívoco. | As retomadas têm função de aplicar ou esclarecer, e não há repetição sem função. |
| M4.1 | 100 | Exemplos: "O contato direto do sangue com esse microambiente trombogênico dispara..."; "Como os inibidores fisiológicos limitam precocemente essa primeira reação, ocorre uma fase de amplificação"; "a membrana fosfolipídica das plaquetas ativadas serve de plataforma física... Em contrapartida, a fibrina... ancora mecanicamente as plaquetas". | As conexões causais são explicitadas entre as etapas e na integração entre hemostasia primária e secundária, indo além de uma lista de eventos. |
| M4.2 | 100 | Exemplos: "A trombomodulina, presente no endotélio íntegro vizinho, sequestra trombina livre... cessando a amplificação"; a confusão 2 diferencia inibição de fibrinólise; a etapa 6 explica o "desequilíbrio entre estímulos pró-coagulantes e inibidores naturais". | A regulação e a fibrinólise são ligadas à localização do coágulo e à distinção com a trombose. |
| M5.1 | 100 | "Considere uma punção capilar superficial na ponta de um dedo." | A situação é concreta e pertinente à pequena lesão vascular pedida. |
| M5.2 | 100 | Exemplos: "Sobre a superfície dessas plaquetas ativadas, o complexo protrombinase produz trombina..."; "a antitrombina e a Proteína C ativada nas margens endoteliais sadias impedem que a reação avance"; a resposta 2 aplica a trombomodulina ao exemplo. | Os elementos e o resultado (sangramento contido, circulação vizinha preservada) são ligados aos conceitos. O exemplo também informa um limite da conclusão. |

## 4. Resumo das notas
| M1 | M2 | M3 | M4 | M5 | P |
|---|---|---|---|---|---|
| 75 | 75 | 100 | 100 | 100 | 90 |

Memória de cálculo:
- M1 = (50 + 100) / 2 = 75
- M2 = (100 + 50) / 2 = 75
- M3 = (100 + 100) / 2 = 100
- M4 = (100 + 100) / 2 = 100
- M5 = (100 + 100) / 2 = 100
- P = (75 + 75 + 100 + 100 + 100) / 5 = 90

## 5. Limitações e alertas
Pela regra 3.4, as notas foram concluídas normalmente. Registro, sem julgamento científico, trechos que o juiz científico pode querer verificar:

**Afirmações que não encontrei nas fontes fornecidas:**
- a ativação do fator XI na fase de amplificação (B01-F3 cita V e VIII);
- as "interações fracas e não covalentes" da fibrina inicial;
- o ressangramento tardio por falha ou "inibição medicamentosa" do fator XIII;
- os tempos "em segundos", "poucos minutos" e "horas após";
- a necessidade de "intervenção hemostática cirúrgica mecânica" em injúrias volumosas, atribuída a B01-F3.

**Outros pontos para conferir:**
- A vasoconstrição é atribuída a uma "vênula dérmica", enquanto B01-F3 descreve vasoespasmo arteriolar.
- A frase "trombina... polimeriza fibrinogênio" encurta o processo: pela fonte, a trombina converte o fibrinogênio em fibrina.

Outras limitações:
- A contagem de palavras e a estrutura formal pertencem ao JT e não foram consideradas aqui.
- As notas são categorias ancoradas, avaliadas em uma única sessão por IA, sem revisão humana.

As notas descrevem atendimento à rubrica e qualidade didática estimada; não demonstram compreensão ou aprendizagem humana.