## 1. Identificação e conferência do certificado
Protocolo de pontuação 3.2, com a cláusula 3.4 do contrato de saída, que prevalece. Código público: Qe8963b997c8a44469f6d2c41837da242. Tema: B02. Rodada: 1. Passagem: JP1.
Certificado: versão 3.4, código de destino idêntico, tema B02, rodada "R01" (equivale à rodada 1) e passagem JP1. A elegibilidade é "resposta completa; avaliação pedagógica cega". Pela regra 3.4, esse certificado substitui a exigência de APTO. O certificado é compatível e a avaliação não fica bloqueada.
Pacote limpo: não contém notas C, pareceres científicos, autoria, modelo, tempos ou custos. Há uma única resposta.

## 2. Situação pedagógica
CONCLUÍDO. Os 10 itens foram avaliados.

## 3. Tabela de subcritérios
| Subcritério | Nota | Evidência | Justificativa |
|---|---|---|---|
| M1.1 | 50 | A seção "Conceitos necessários" define antígeno, anticorpo, receptor, plasmócito, APC, MHC I/II e célula de memória. No texto, aparecem sem definição "complemento", "citocinas", "apoptose", "CD8/CD4", "adjuvantes", "afinidade", "linfócitos virgens" e "células efetoras" (esta última só é explicada na etapa 4). | **Atendido:** o núcleo terminológico foi definido. **Limitação:** vários termos além do conhecimento prévio do graduando aparecem sem explicação no primeiro uso. A sigla MHC também não é expandida. |
| M1.2 | 50 | A maioria das frases tem sujeitos claros (ex.: "T auxiliares CD4 reconhecem peptídeo em MHC de classe II..."). Há, porém, trechos com referente vago ou formulação confusa: "Os plasmócitos descritos em uma das fontes..." e "A fonte distingue..." (qual fonte e qual conclusão vale para o leitor?); na confusão 2, "Pensar que toda resposta com ajuda de T auxiliar é igual à morte direta pelo T auxiliar"; na resposta 2, "Porque a aplicação é avaliar memória além do anticorpo circulante"; e o neologismo "replenificam". | **Atendido:** clareza predominante. **Limitação:** as ambiguidades aparecem justamente em pontos centrais (vida dos plasmócitos, papel do T auxiliar e resposta de aplicação). |
| M2.1 | 50 | A ordem é "Conceitos necessários", depois as etapas 1→6 (apresentação → B → T → expansão clonal → reexposição → vacinação), o que permite acompanhar o mecanismo. Porém a etapa 2 usa "Citocinas de T auxiliares ajudam o B..." e "células efetoras" antes que T auxiliares (etapa 3) e efetores (etapa 4) sejam apresentados. | **Atendido:** progressão geral adequada. **Limitação:** a relação B–T auxiliar depende de um componente ainda não apresentado. |
| M2.2 | 100 | A síntese tem três itens: apresentação → papéis de B, T auxiliar e T citotóxico; expansão clonal → efetores e memória → resposta secundária; vacinação cria memória, mas "memória não é proteção absoluta porque depende de anticorpos presentes, velocidade e variação do patógeno e características individuais como idade". | A síntese integra os seis pontos e responde ao objetivo final do pedido, sem introduzir pré-requisito novo. |
| M3.1 | 100 | Todas as seções tratam de reconhecimento, papéis de B e T, memória e vacinação. As menções a barreiras inatas e a tipos de vacina são breves e servem para situar a resposta inata e a imunização ativa. | Não há trecho relevante fora do recorte. Citocinas específicas, subclasses e plataformas não são detalhadas. |
| M3.2 | 100 | As retomadas no exemplo, nas confusões e nas respostas comentadas aplicam os conceitos (ex.: a resposta 2 retoma as células B e T de memória para justificar a resposta mais rápida). A frase "A marca da imunidade adaptativa..." reaparece na etapa 5, mas como transição para a reexposição. | Não há repetição sem função predominante; as retomadas têm papel explicativo ou de aplicação. |
| M4.1 | 50 | Há conexões causais explícitas: "Assim, a apresentação transforma um sinal inespecífico de perigo em ativação específica"; "Essa divisão explica por que a defesa contra patógenos intracelulares..."; "há mais células específicas prontas" (etapa 5); e a resposta 1 explica por que o encontro nos linfonodos viabiliza a ativação do clone raro. Já as etapas 2 e 4 são, em grande parte, encadeamentos de afirmações parafraseadas e citadas, sem dizer por que o reconhecimento leva à proliferação, por que a maioria dos efetores morre ou por que a resposta secundária tem maior afinidade. | **Atendido:** parte das relações causais está desenvolvida. **Limitação:** vários trechos listam acontecimentos sem explicar o mecanismo que os liga, o que é insuficiente para estudo individual. |
| M4.2 | 100 | Etapa 6: "níveis elevados de anticorpos específicos não garantem automaticamente proteção"; disseminação rápida versus lenta ligada a anticorpo presente versus tempo para as células de memória proliferarem; variação do patógeno; idade e estado imune. Esses limites reaparecem no "Limite da conclusão" do exemplo e na síntese. | As condições e os limites pertinentes são conectados à conclusão de que memória não é proteção absoluta. A relação disseminação × tipo de memória é justificada. |
| M5.1 | 100 | "Imagine uma vacina hipotética contendo proteína inativada de um microrganismo... Meses depois há contato com o agente correspondente vivo." | É uma situação concreta, hipotética e pertinente ao pedido (vacinação seguida de contato), sem vacina comercial. |
| M5.2 | 50 | O resultado é interpretado com os conceitos: "anticorpos residuais podem bloquear parte inicial; se houver invasão, B e T de memória proliferam em dias...". O limite também é interpretado (disseminação, variação, idade). A resposta 2 aplica o exemplo à distinção entre anticorpo e memória. As "Etapas", porém, formam uma enumeração telegráfica ("a inata detecta..., dendríticas... apresentam...; T auxiliares... expandem-se...") que não explica por que cada etapa leva à seguinte nem por que ocorre a passagem de IgM para IgG. | **Atendido:** situação inicial, resultado e limite ligados aos conceitos. **Limitação:** as etapas do exemplo são mais listadas do que explicadas. |

## 4. Resumo e memória de cálculo
| M1 | M2 | M3 | M4 | M5 | P |
|---|---|---|---|---|---|
| 50 | 75 | 100 | 75 | 75 | 75 |

- M1 = (50 + 50) / 2 = 50
- M2 = (50 + 100) / 2 = 75
- M3 = (100 + 100) / 2 = 100
- M4 = (50 + 100) / 2 = 75
- M5 = (100 + 50) / 2 = 75
- P = (50 + 75 + 100 + 75 + 75) / 5 = 375 / 5 = 75

## 5. Limitações e alertas
- **Possíveis pontos científicos, apenas registrados.** A correção científica cabe a outro juiz; pela regra 3.4, as notas foram concluídas normalmente.
  - (a) O exemplo usa uma vacina de "proteína inativada" e afirma que "T citotóxicos e auxiliares geram efetores e depois memória". O material fornecido associa CD8 a peptídeos em MHC I de origem intracelular e não descreve como um antígeno proteico exógeno ativaria CD8 (apresentação cruzada). A generalização merece conferência.
  - (b) A definição "Antígeno é qualquer estrutura reconhecida como não própria" simplifica o texto da fonte.
  - (c) A confusão 1 ("anticorpos podem cair com o tempo sem que a memória celular tenha desaparecido") é uma inferência plausível, mas só parcialmente explícita nas fontes.
- **Escopo desta avaliação.** Não foram consideradas contagem de palavras nem conformidade formal (papel de JT). O juízo é por inspeção de LLM, sem estudantes avaliados.
- Não há ranking, identificação de autoria nem alteração de outros pareceres.

## 6. Encerramento
As notas descrevem atendimento à rubrica e qualidade didática estimada; não demonstram compreensão ou aprendizagem humana.