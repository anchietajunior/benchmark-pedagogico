## 1. Identificação e conferência do certificado
- Protocolo: 3.2, com a regra complementar 3.4 do contrato de saída (certificado de avaliação cega substitui a exigência de APTO).
- Código público: Q78e5559bb47645228c02459a464c4802. Tema: B01. Rodada: 1. Passagem: JP1.
- Certificado: versão 3.4; código de destino, tema, rodada (R01 = 1) e passagem (JP1) coincidem com a chamada. A elegibilidade declarada é "resposta completa; avaliação pedagógica cega". O certificado é compatível. O pacote não contém autoria, notas C, dados operacionais, tempos nem custos.

## 2. Situação pedagógica
CONCLUÍDO

## 3. Avaliação por subcritério
| Subcritério | Nota | Evidência | Justificativa |
|---|---|---|---|
| M1.1 | 50 | Parte atendida: há definições em "Conceitos necessários" (endotélio, subendotélio, zimogênios, trombina, fibrinólise). Limitação: "TFPI", "tPA", "PAI" e "TAFI" aparecem sem expansão nem definição; "hemostasia primária e secundária", "trombomodulina", "heparan sulfato", "plasminogênio" e "pseudópodes" não são definidos. | Os termos centrais são definidos no primeiro uso. Porém, várias siglas e termos do mecanismo regulador e fibrinolítico, além da própria distinção primária/secundária exigida no pedido, ficam sem definição para esse público. |
| M1.2 | 100 | Exemplo: "aceleram, respectivamente, a produção de trombina pelo Xa e a produção de Xa pelo IXa". | Os sujeitos e referentes são identificáveis. O único ponto menor é o "esta", em Q2, que se refere à proteína C pelo contexto; ele não gera ambiguidade relevante. |
| M2.1 | 100 | O texto segue a ordem: conceitos, depois as etapas 1→6 (lesão → plaquetas → trombina/fibrina → estabilização → regulação → trombose). | Os componentes aparecem antes das relações, e cada etapa se apoia na anterior. |
| M2.2 | 100 | Síntese: "A fibrina reticulada pelo XIIIa estabiliza um tampão que, sozinho, seria frágil…"; "sem esses controles, a resposta protetora vira trombose". | A síntese integra os três eixos e responde às duas metas finais do pedido, sem novo pré-requisito. |
| M3.1 | 100 | A menção às hemofilias em Confusões 1 serve para justificar o modelo celular. | Não há digressões fora do recorte, e a enumeração de fatores e exames é evitada. |
| M3.2 | 100 | O Exemplo e a Q2 retomam os reguladores para aplicá-los no corte. | As retomadas cumprem função aplicativa; não há repetição sem função. |
| M4.1 | 100 | "É essa exposição de componentes normalmente isolados que dispara a resposta"; "como cada molécula de fibrinogênio conecta duas plaquetas, forma-se o tampão"; "as plaquetas fornecem a superfície… sem os quais a trombina não se forma em escala". | O texto explica por que as etapas se conectam: gatilho, ponte molecular, retroalimentação e integração bidirecional. Não se limita a listar acontecimentos. |
| M4.2 | 100 | "A trombina que escapa do local e encontra endotélio íntegro liga-se à trombomodulina…"; "PAI, α2-antiplasmina e TAFI evitam que essa dissolução seja prematura"; "localização e controle é o que separa…". | A regulação e os limites são conectados à localização da resposta e à distinção entre hemostasia e trombose. |
| M5.1 | 100 | "um corte superficial rompe uma arteríola da pele". | A situação é concreta e pertinente à pequena lesão pedida. |
| M5.2 | 50 | Parte atendida: "Interpretação: um tampão só de plaquetas resistiria mal ao fluxo; a fibrina o transforma em vedação estável". A Q2 aplica os reguladores ao corte. Limitação: as "Etapas" são majoritariamente uma sequência compacta de rótulos ("aderem via vWF–GpIb… o XIIIa a reticula… endotélio íntegro ativa proteína C e antitrombina"). | O resultado é relacionado aos conceitos, mas o desenvolvimento no próprio exemplo é sumário. Parte das relações depende da retomada nas seções anteriores e em Q2, e a interpretação se resume a uma frase. |

## 4. Resumo das notas
| M1 | M2 | M3 | M4 | M5 | P |
|---|---|---|---|---|---|
| 75 | 100 | 100 | 100 | 75 | 90 |

Memória de cálculo:
- M1 = (50+100)/2 = 75
- M2 = (100+100)/2 = 100
- M3 = (100+100)/2 = 100
- M4 = (100+100)/2 = 100
- M5 = (100+50)/2 = 75
- P = (75+100+100+100+75)/5 = 90

## 5. Limitações e alertas
Não houve estudantes nem navegação. A avaliação se limita ao texto e ao material incorporado.

Observação para o juiz científico, sem efeito sobre as notas: algumas afirmações temporais do exemplo não aparecem no material fornecido. São elas "o sangramento diminui em minutos" e "Dias depois, tPA e plasmina dissolvem a fibrina". Também convém conferir a afirmação de que a trombina "ativa mais plaquetas", que tem apoio apenas indireto na fase de propagação de B01-F3. A frase "localização e controle é o que separa" tem uma pequena falha de concordância verbal.

Não foi aplicada nenhuma penalidade por extensão, pois a contagem de palavras pertence a JT. Não há ranking nem identificação de autoria.

## 6. Encerramento
As notas descrevem atendimento à rubrica e qualidade didática estimada; não demonstram compreensão ou aprendizagem humana.