## 1. Identificação e certificado
- Rubrica aplicada: Protocolo 3.2 (10 itens pedagógicos), com a regra de elegibilidade do Protocolo 3.4, conforme o contrato de saída.
- Código público: Q98066ab4588f44a68b1f20fa4108f470. Tema: B02. Rodada: 1. Passagem: JP1.
- Conferência do certificado: versão 3.4, código de destino idêntico, tema B02, rodada R01 (equivale à rodada 1) e passagem JP1. A elegibilidade vem de avaliação cega de resposta completa. Pelo Protocolo 3.4, esse certificado substitui a exigência de APTO. Certificado compatível: não há motivo para bloqueio.
- O pacote está limpo: não traz autoria explícita, notas C, dados operacionais nem mais de uma resposta.

## 2. Situação pedagógica
CONCLUÍDO. Os 10 itens foram avaliados.

## 3. Tabela de subcritérios
Subcritério | Nota | Evidência | Justificativa
--- | --- | --- | ---
M1.1 | 50 | Estão definidos: antígeno, imunidade inata e adaptativa, APC, MHC, TCR, BCR, plasmócitos e células de memória (em "Conceitos necessários"); expansão clonal ("proliferam e geram células efetoras"); e ADE, descrita pelo mecanismo. Não estão definidos: "citocinas" (1º uso no passo 1), "complemento", "apoptose", "isotipo", "afinidade", o significado de CD4+/CD8+ e "curto-lived". | O núcleo terminológico está bem definido, mas vários termos além do conhecimento prévio do graduando aparecem sem explicação no primeiro uso.
M1.2 | 100 | Frases como "Assim, CD4+ organiza a resposta; CD8+ executa a destruição de células-alvo" e "Anticorpos são proteínas secretadas por plasmócitos; células de memória são células de vida longa..." | Sujeitos e referentes são identificáveis. Os anglicismos pontuais ("microbe", "curto-lived") não geram ambiguidade de referente.
M2.1 | 100 | A seção de conceitos (APC, MHC, TCR/BCR, plasmócitos, memória) vem antes do mecanismo. Os passos seguem a ordem apresentação → B → T → expansão/memória → reexposição → vacinação. | Os componentes aparecem antes das relações. A citação de T auxiliares no passo 2 depende apenas da menção a CD4+ já feita nos conceitos, e as etapas são fáceis de acompanhar.
M2.2 | 100 | A síntese tem três itens: reconhecimento com efetoras e memória; papéis de B, plasmócitos, CD4+/CD8+ e memória; vacinas com proteção relativa. | Integra as ideias, responde ao objetivo (distinguir anticorpo de memória e explicar os limites da proteção) e não introduz pré-requisitos novos.
M3.1 | 100 | Todos os trechos tratam de reconhecimento, células B/T, memória, reexposição e vacinação. Não há descrição de todas as citocinas, subclasses ou plataformas. | O texto respeita o recorte e as exclusões. A menção à ADE está ligada ao limite da proteção pedido no ponto 6.
M3.2 | 100 | A confusão 1 retoma a distinção do passo 4. A confusão 2 e a síntese retomam fatores do passo 6. | As retomadas cumprem uma função: corrigir as confusões e integrar as ideias. Não há repetição sem finalidade que prejudique a leitura.
M4.1 | 50 | Há causalidade no passo 1 ("sem apresentação, os linfócitos T específicos dificilmente encontram o antígeno"), no passo 5 e na resposta 1 ("já existem mais linfócitos específicos... a etapa de encontro, seleção e expansão clonal é encurtada"). Os passos 2 e 3, porém, enumeram funções: não explicam por que a ajuda do T auxiliar melhora a resposta B, nem como a ativação de um clone específico decorre do reconhecimento. | Parte das etapas tem ligação causal explícita, mas trechos relevantes do mecanismo são listas de funções, com desenvolvimento insuficiente para estudo individual.
M4.2 | 100 | "contra disseminação rápida, conta sobretudo o anticorpo já presente; contra disseminação lenta, células B de memória têm tempo de proliferar"; "Anticorpos que se ligam sem inativar podem até facilitar entrada..."; "Logo, memória imunológica melhora a resposta, mas não é proteção absoluta." | As condições e os limites (velocidade do patógeno, variantes, estado imune, ADE) estão ligados à conclusão sobre a proteção relativa. A resposta 2 reforça essa ligação.
M5.1 | 100 | "Imagine uma pessoa que recebe uma vacina hipotética contra o 'agente Y'... Meses depois, a pessoa entra em contato com Y." | A situação é concreta, hipotética e pertinente: vacinação seguida de contato posterior, como pedido.
M5.2 | 100 | As etapas do exemplo remetem aos conceitos: inata, APC/MHC, ajuda de CD4+ a B, plasmócitos e B de memória. No reencontro: "Se houver anticorpos suficientes, eles podem neutralizar... Se o agente ultrapassar essa barreira, células B e T de memória proliferam". Há interpretação e limite. A resposta 2 aplica o exemplo. | O resultado (resposta mais rápida) e os limites são explicados pela relação entre anticorpos e células de memória apresentada no mecanismo.

## 4. Resumo
M1 | M2 | M3 | M4 | M5 | P
--- | --- | --- | --- | --- | ---
75 | 100 | 100 | 75 | 100 | 90

Memória de cálculo:
- M1 = (50 + 100) / 2 = 75
- M2 = (100 + 100) / 2 = 100
- M3 = (100 + 100) / 2 = 100
- M4 = (50 + 100) / 2 = 75
- M5 = (100 + 100) / 2 = 100
- P = (75 + 100 + 100 + 75 + 100) / 5 = 450 / 5 = 90

## 5. Limitações e alertas
- Esta avaliação é de um único juiz de IA e não usou dados de estudantes.
- Conformidade de extensão e de estrutura não foram avaliadas aqui; cabem a JT.
- Pontos para atenção do juiz científico (não afetam as notas acima):
  - "reduzir a chance de doença grave" e "se a dose for muito alta" no exemplo não aparecem explicitamente nas fontes fornecidas.
  - "tipicamente IgG" foi atribuído em conjunto a B02-F4 e B02-F5.
  - A definição de antígeno como "estrutura estranha" é uma simplificação.
- Não há ranking, identificação de autoria nem alteração de outros pareceres.

## 6. Encerramento
As notas descrevem atendimento à rubrica e qualidade didática estimada; não demonstram compreensão ou aprendizagem humana.