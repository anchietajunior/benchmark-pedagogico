## 1. Identificação e conferência do certificado
Rubrica aplicada: protocolo 3.2, com a regra do protocolo 3.4 para elegibilidade cega. Código público: Q3963828a7b1e4e5ab2a65631c62837c2. Tema: B01. Rodada: 1. Passagem: JP1.
O certificado informa a versão 3.4 e usa o mesmo código público de destino, o tema B01, a rodada R01 (equivalente à rodada 1) e a passagem JP1. Também declara que a resposta está completa e que a avaliação pedagógica é cega. Pela regra 3.4, esse certificado substitui a exigência de APTO. O pacote não contém notas C, pareceres científicos, identidade de autoria ou dados operacionais. Por isso, está elegível.

## 2. Situação pedagógica
CONCLUÍDO. Os 10 itens foram avaliados.

## 3. Tabela de subcritérios
| Subcritério | Nota | Evidência | Justificativa |
|---|---|---|---|
| M1.1 | 50 | "Conceitos necessários" define endotélio, plaquetas, fator von Willebrand, fibrinogênio, fator tecidual, protrombina, trombina e fator XIII. Não são explicados: "complexos tenase", a notação "VIIa/Xa/Va" (o sufixo "a" = ativado), GPIb, IIb/IIIa, tPA, plasminogênio/plasmina, trombomodulina e pseudópodes. | A maioria dos termos centrais é definida no primeiro uso, mas vários termos novos ficam sem definição. "Tenase" e o sufixo "a" são necessários para acompanhar o passo 3. |
| M1.2 | 50 | "No modelo atual, a iniciação ocorre quando fator tecidual liga fator VIIa e ativa os fatores IX e X. Essa quantidade inicial de trombina é pequena..." | Em geral, as frases têm sujeito e referente claros. Nesse trecho, porém, "Essa quantidade inicial de trombina" retoma algo que não foi mencionado: falta a etapa em que Xa gera trombina. A ambiguidade cai em um ponto-chave do mecanismo. |
| M2.1 | 100 | Ordem: conceitos → 1 lesão → 2 tampão (adesão, ativação, agregação) → 3 trombina/fibrina → 4 estabilização e integração → 5 regulação e fibrinólise → 6 trombose. | Os componentes são apresentados antes das relações. As subseções numeradas permitem acompanhar as etapas em sequência. |
| M2.2 | 100 | Os três itens da Síntese vão da lesão como ponto de partida comum, ao tampão e sua estabilização, até o controle e a remoção, "separando hemostasia útil de trombose prejudicial". | A síntese integra as três partes e responde ao objetivo (cooperação e limitação local) sem trazer pré-requisito novo. |
| M3.1 | 100 | Todas as seções tratam do recorte. Não há lista completa de fatores nem de exames. O limite do exemplo remete o que está fora do escopo à avaliação clínica. | Cada trecho contribui para o pedido, e as exclusões do tema são respeitadas. |
| M3.2 | 100 | As etapas do exemplo retomam o mecanismo aplicado ao corte. A Pergunta 2 retoma a Confusão 1 para aplicá-la. | As retomadas servem para aplicar ou justificar. As etiquetas de citação longas e repetidas (por exemplo, quatro vezes na seção 6) pesam na leitura, mas não repetem conteúdo. |
| M4.1 | 50 | Parte atendida: "Sem plaquetas ativadas faltaria superfície e sinalização para gerar trombina no local certo; sem fibrina, o agregado plaquetário se desfaria"; "o sinal inicial não é apenas o buraco...". Limitação: "a trombina ativa os fatores V e VIII, que servem como cofatores e aceleram novas reações". | A integração primária–secundária e o gatilho inicial têm explicação causal. Já no passo 3 (iniciação, amplificação e propagação), a relação é em boa parte enumerada: falta o elo Xa→trombina, e "novas reações" não diz quais reações nem por que a trombina aumenta. |
| M4.2 | 50 | Parte atendida: "A coagulação precisa ser contida porque o sangue continua passando ao lado do tampão"; o equilíbrio TxA2/prostacyclina "ajuda a manter a agregação localizada". Limitação: antitrombina, TFPI e proteína C/trombomodulina aparecem como uma lista de freios. | A necessidade de regulação é ligada à conclusão. Falta, porém, mostrar por que esses inibidores confinam a resposta ao local (por exemplo, trombomodulina no endotélio íntegro vizinho). A seção 6 também não liga a trombose à falha desses controles específicos. Há ainda uma tensão não resolvida entre "Depois que o tecido começa a se reparar, a fibrinólise..." e "ativado junto com a coagulação". |
| M5.1 | 100 | "Imagine um pequeno corte na pele que atinge um vaso de pequeno calibre. Situação inicial: endotélio rompido, colágeno e fator tecidual expostos..." | A situação é concreta, identificável e corresponde ao exemplo pedido. |
| M5.2 | 50 | Parte atendida: "o sangramento cessa porque a vedação mecânica inicial foi transformada em uma rede estável"; a Pergunta 2 aplica a falha de fibrina ao corte. Limitação: "Reguladores vizinhos impedem que o processo avance pelo vaso"; "o vaso permanece parcialmente aberto ao redor". | O resultado é interpretado pela estabilização. No exemplo, porém, a limitação local e a remoção (fibrinólise) aparecem só como rótulos ou nem aparecem. As etapas repetem nomes de processos sem explicar sua relação com o controle local. |

## 4. Resumo
| M1 | M2 | M3 | M4 | M5 | P |
|---|---|---|---|---|---|
| 50 | 100 | 100 | 50 | 75 | 75 |

Memória de cálculo:
- M1 = (50 + 50) / 2 = 50
- M2 = (100 + 100) / 2 = 100
- M3 = (100 + 100) / 2 = 100
- M4 = (50 + 50) / 2 = 50
- M5 = (100 + 50) / 2 = 75
- P = (50 + 100 + 100 + 50 + 75) / 5 = 375 / 5 = 75

## 5. Limitações e alertas
Possíveis pontos científicos, só para registro. Pela regra 3.4, as notas foram concluídas normalmente, e a decisão cabe ao juiz científico:
- (a) O texto diz que a vasoconstrição "aproxima as bordas da lesão", com citação de B01-F4. Nas notas fornecidas, B01-F4 atribui a aproximação das bordas à contração das plaquetas; a vasoconstrição aparece apenas reduzindo a perda de sangue. Pode ser uma atribuição indevida.
- (b) Chamar o tampão de "reversível" e afirmar que defeitos de plaquetas e de fatores "causam sangramentos de formas diferentes" (Confusão 1) não tem apoio explícito no material fornecido.
- (c) No passo 3, a conversão de protrombina em trombina pelo Xa na iniciação foi omitida.

Limitações gerais: a avaliação é de um único juiz de IA, baseada no texto. A extensão e a forma das seções não foram julgadas, porque pertencem a JT.

As notas descrevem atendimento à rubrica e qualidade didática estimada; não demonstram compreensão ou aprendizagem humana.