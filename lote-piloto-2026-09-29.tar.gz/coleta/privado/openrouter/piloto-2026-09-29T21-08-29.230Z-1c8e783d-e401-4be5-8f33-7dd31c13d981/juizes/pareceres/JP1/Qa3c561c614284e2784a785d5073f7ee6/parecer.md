## 1. Identificação e certificado
Protocolo 3.2, com a regra do protocolo 3.4 prevalecendo, conforme o contrato de saída. Código público Qa3c561c614284e2784a785d5073f7ee6; tema B01; rodada 1; passagem JP1.

**Certificado:** versão 3.4; código de destino idêntico; tema B01; rodada "R01", que corresponde à rodada 1; passagem JP1. A elegibilidade é "Resposta completa; avaliação pedagógica cega". Pela regra 3.4, esse certificado cego substitui a exigência de APTO. Por isso, o certificado é compatível e a avaliação não foi bloqueada. O pacote não contém autoria, notas C, dados operacionais nem mais de uma resposta.

## 2. Situação pedagógica
CONCLUÍDO. Os 10 itens são válidos.

## 3. Tabela dos 10 itens
| Subcritério | Nota | Evidência | Justificativa |
|---|---|---|---|
| M1.1 | 50 | Parte atendida: há definições para endotélio, subendotélio, vWF, plaquetas, zimogênios, trombina e fibrinogênio. Termos sem definição: "megakaryocytes", pseudópodes, degranulação, "tenase", "tPA", trombomodulina, proteína C/S e cofator. | A maior parte dos termos centrais é definida. Vários termos novos aparecem sem explicação, e um deles ficou em inglês. A sigla TFPI só pode ser deduzida pelo leitor. |
| M1.2 | 100 | Frases como "A adesão depende de o vWF funcionar como ponte entre o colágeno subendotelial e o receptor plaquetário GpIb". | Os sujeitos e os referentes são identificáveis. Não encontrei ambiguidade relevante. |
| M2.1 | 100 | Ordem: Conceitos → seções 1 a 6 do mecanismo (lesão → plaquetas → trombina/fibrina → estabilização → regulação → trombose) → exemplo. | Os componentes são apresentados antes das relações. As etapas seguem a sequência do mecanismo e podem ser acompanhadas. |
| M2.2 | 50 | Síntese: "O coágulo só é útil enquanto provisório e localizado..."; "formando o tampão que também serve de superfície para gerar trombina e fibrina". | Parte atendida: a síntese integra a formação e o controle e responde por que coágulos sem controle são um problema. Limitações: a síntese não retoma explicitamente por que o tampão precisa ser estabilizado pela fibrina. Além disso, a frase "esses dois eventos abrem e limitam a resposta" não tem base no corpo do texto. |
| M3.1 | 50 | "Observação de correção: em um trecho do material fornecido aparece 'TF-VIIIa'..." | Quase todo o texto serve ao recorte. A nota sobre um erro de digitação da fonte, porém, é metacomentário sobre o material, não contribui para o objetivo do estudante e interrompe o raciocínio sobre o mecanismo. |
| M3.2 | 100 | O exemplo e a pergunta 2 retomam a sequência adesão → agregação → fibrina. | As retomadas têm função de aplicação ou síntese. Não há repetição sem função. |
| M4.1 | 50 | Atendido: "o ADP altera a conformação do receptor GpIIb/IIIa, permitindo que o fibrinogênio conecte plaquetas vizinhas"; "O fator XIII ativado liga covalentemente..."; "o tampão plaquetário fornece a superfície onde a coagulação acontece". Limitação: "a trombina já formada ativa os fatores V e VIII, que funcionam como cofatores". | A maioria das conexões é explicada causalmente. A amplificação, porém, fica em rótulo: o texto não explica o que o cofator faz nem por que a retroalimentação transforma pouca trombina em produção robusta. |
| M4.2 | 50 | Atendido: "o equilíbrio entre tromboxano A2 e prostaciclina restringe a agregação ao local"; "Formação e remoção precisam ficar em equilíbrio..."; "a diferença... é a localização e o controle". Limitação: a seção 5 lista antitrombina, TFPI e proteína C. | A regulação está ligada à conclusão sobre localização e trombose. Os inibidores, no entanto, aparecem em sequência, sem explicar como restringem a resposta ao local; o papel da trombomodulina no endotélio íntegro, por exemplo, não é explicado. |
| M5.1 | 100 | "Situação inicial: um corte superficial rompe o endotélio de um pequeno vaso, expondo colágeno e vWF." | A situação é concreta, pertinente e usada também na pergunta 2. |
| M5.2 | 50 | Atendido: "a rede de fibrina, covalentemente ligada, transforma um agregado frágil em vedação estável". A pergunta 2 explica o efeito de falhar a agregação. O limite da conclusão está explícito. Limitação: "enquanto a antitrombina, o TFPI e a via da proteína C limitam a reação". | A estabilização é interpretada a partir dos conceitos. A parte regulatória do exemplo é só uma lista: não mostra como esses mecanismos mantêm a resposta restrita ao corte. |

## 4. Resumo e memória de cálculo
| M1 | M2 | M3 | M4 | M5 | P |
|---|---|---|---|---|---|
| 75 | 75 | 75 | 50 | 75 | 70 |

- M1 = (50+100)/2 = 75
- M2 = (100+50)/2 = 75
- M3 = (50+100)/2 = 75
- M4 = (50+50)/2 = 50
- M5 = (100+50)/2 = 75
- P = (75+75+75+50+75)/5 = 350/5 = 70

## 5. Limitações e alertas
Pela regra 3.4, as notas foram concluídas normalmente. Registro, para a conferência científica, trechos que podem conter erro ou afirmação sem apoio no material:

1. A frase "a vasoconstrição e a exposição do fator tecidual são respostas proporcionais a essa lesão [B01-F3]" traz uma proporcionalidade que não aparece no trecho fornecido.
2. O primeiro item da síntese diz que a vasoconstrição e a exposição do subendotélio "limitam a resposta", o que pode ser uma generalização indevida.
3. O texto diz que os fatores de coagulação são "produzidos no fígado". A fonte B01-F3 ressalva que os fatores III, IV e VIII são exceções.
4. A frase "sua atividade é contida... por inibidores do ativador [B01-F2]" pode atribuir a B01-F2 um conteúdo que aparece em B01-F3.

A avaliação estima a qualidade didática por IA, com base apenas no texto. A contagem de palavras e a estrutura formal pertencem ao juiz tecnológico (JT) e não foram consideradas.

## 6. Encerramento
As notas descrevem atendimento à rubrica e qualidade didática estimada; não demonstram compreensão ou aprendizagem humana.