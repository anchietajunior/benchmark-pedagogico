## 1. Identificação e certificado
Protocolo 3.2, aplicado com a regra do protocolo 3.4 indicada no contrato de saída, que prevalece sobre o texto anterior. Código público: Q916aef7f6462491a881a29bb0394dfb5. Tema: B02. Rodada: 1. Passagem: JP1.

Conferência do certificado: a versão 3.4, o código de destino, o tema B02, a rodada R01 (equivalente à rodada 1) e a passagem JP1 são compatíveis. O certificado é de avaliação cega e declara uma resposta completa. Pela regra 3.4, esse certificado substitui a exigência de APTO. O pacote não contém notas C, pareceres anteriores, identificação do modelo, tempos ou custos, e não há autoria explícita no corpo didático.

## 2. Situação pedagógica
CONCLUÍDO: os 10 itens foram avaliados.

## 3. Tabela de subcritérios
| Subcritério | Nota | Evidência | Justificativa |
|---|---|---|---|
| M1.1 | 50 | Termos definidos em "Conceitos necessários": antígeno, APC, MHC, plasmócitos, anticorpos, TCR. Também são explicados no texto: opsonização, neutralização, apoptose e imunossenescência. Não são definidos: "citocinas", "sistema complemento", "linfócitos virgens", "antígeno cognato", "depuração antigênica", "epítopos", "centros germinativos", "troca de classe" e "involução tímica". | A maior parte dos termos centrais recebe explicação no primeiro uso. Porém, vários termos além do conhecimento prévio do graduando aparecem sem definição, alguns em pontos-chave (citocinas no papel do T CD4+; epítopos no limite do exemplo). |
| M1.2 | 100 | Exemplos: "Não destroem células infectadas diretamente nem fagocitam partículas; atuam como reguladores centrais..."; "Em um novo contato com o mesmo antígeno, o sistema imune não parte do estado basal". | As frases têm sujeitos e referentes identificáveis. Não foi observada ambiguidade relevante, embora algumas frases sejam densas. |
| M2.1 | 100 | Sequência: Conceitos → 1. apresentação → 2. B/plasmócitos/anticorpos → 3. T CD4+/CD8+ → 4. expansão clonal → 5. resposta secundária → 6. vacinação e limites. | Os componentes são definidos antes de suas relações. A menção ao auxílio T no passo 2 depende de linfócitos T já definidos nos conceitos. As etapas podem ser acompanhadas em ordem causal e temporal. |
| M2.2 | 100 | "A expansão clonal multiplica clones... culmina na separação funcional entre células efetoras... e células de memória"; "A vacinação emula esse mecanismo... porém a eficácia protetora enfrenta limitações reais...". | Os três itens integram reconhecimento, expansão/memória e vacinação/limites, respondendo ao objetivo. Não introduzem pré-requisito novo: a cinética de disseminação e o estado do hospedeiro já apareciam no passo 6. |
| M3.1 | 100 | As seções tratam de reconhecimento, papéis de B e T, memória, vacinação e limites. Não há descrição de subclasses, de citocinas específicas ou de plataformas vacinais. | Cada trecho contribui para o recorte e respeita as exclusões do pedido. A "Ideia central" é breve e genérica, mas cumpre a função de enquadrar o tema. |
| M3.2 | 100 | Retomadas em "Confusões a evitar", nas respostas comentadas e na "Síntese". | As retomadas têm função: distinguir anticorpo de célula de memória, justificar respostas e integrar ideias. Não se observou repetição sem função. |
| M4.1 | 100 | Passo 1: a APC digere o antígeno, acopla os peptídeos ao MHC, migra ao linfonodo e isso "permit[e] o encontro físico". Passo 5: células de memória "estão em maior número e possuem limiar de ativação inferior", por isso "o tempo de latência diminui". Resposta 1: falha no MHC II → não ativação do T CD4+ → B sem os sinais necessários. | O texto explica por que as etapas se conectam e produzem o resultado, não apenas as lista. A pergunta causal desenvolve a cadeia explicitamente. |
| M4.2 | 100 | Passo 6: mutação antigênica → escape; replicação fulminante → dano antes da proliferação de B de memória; imunossenescência → memória menos diversa e eficaz. Também o limite do exemplo e a resposta 2 sobre o idoso. | As condições e limites são ligados à conclusão de que memória não significa proteção absoluta. Cada limite vem acompanhado de seu mecanismo. |
| M5.1 | 100 | "Um indivíduo jovem e saudável recebe uma vacina hipotética composta por antígenos proteicos purificados de uma bactéria extracelular fictícia... Meses depois, o indivíduo é exposto à bactéria selvagem." | A situação é concreta, hipotética, não depende de vacina comercial e é pertinente ao pedido (vacinação seguida de contato posterior). |
| M5.2 | 50 | Parte atendida: as etapas relacionam APC/MHC II → T CD4+ → auxílio ao B → IgM/IgG → B de memória e plasmócitos de vida longa → IgG circulante e B de memória na reexposição; o limite menciona mutação de epítopos. Limitação: "desencadeando expansão clonal" e "estabelece-se um contingente residual" funcionam como rótulos. O "Resultado interpretado" afirma que a resposta "bloqueou a disseminação" sem explicar, no exemplo, por que foi mais rápida (mais células específicas, menor limiar, anticorpos prévios). | Parte dos elementos é explicada por sua relação com os conceitos. A interpretação do resultado, porém, é assertiva e pouco relacional. O limite diz que a memória "garante rapidez", o que também é uma formulação absoluta. |

## 4. Resumo
| M1 | M2 | M3 | M4 | M5 | P |
|---|---|---|---|---|---|
| 75 | 100 | 100 | 100 | 75 | 90 |

Memória de cálculo:
- M1 = (50 + 100) / 2 = 75
- M2 = (100 + 100) / 2 = 100
- M3 = (100 + 100) / 2 = 100
- M4 = (100 + 100) / 2 = 100
- M5 = (100 + 50) / 2 = 75
- P = (75 + 100 + 100 + 100 + 75) / 5 = 90

## 5. Limitações e alertas
Pela regra 3.4, possíveis problemas científicos são apenas descritos, sem alterar o fluxo. Pontos para o juiz científico:
- "A presença de células de memória garante rapidez de resposta" é uma formulação absoluta, e as fontes relativizam a proteção.
- O antígeno é definido como estrutura "estranha ('não própria')", uma simplificação.
- O passo 1 descreve somente o MHC de classe II na APC antes da migração.

Outras limitações:
- A extensão e a estrutura formal não foram avaliadas aqui; pertencem ao JT.
- A avaliação é feita por IA, sem estudantes.
- Não há ranking nem identificação de autoria.

As notas descrevem atendimento à rubrica e qualidade didática estimada; não demonstram compreensão ou aprendizagem humana.