## 1. Identificação e certificado
- Rubrica: Protocolo 3.2, com a regra do Protocolo 3.4 no contrato de saída, que prevalece.
- Código público: Qda8fe1fdfeef44d5b2d08d01226c6160
- Tema: B02
- Rodada: 1
- Passagem: JP1
- Conferência do certificado:
  - Versão 3.4, código de destino, tema e passagem JP1 conferem.
  - A rodada "R01" corresponde à rodada 1.
  - O documento é um certificado de avaliação cega ("Resposta completa; avaliação pedagógica cega, sem a decisão científica").
  - Pela regra 3.4, esse certificado substitui a exigência de APTO. Não há bloqueio.
- Limpeza do pacote: o pacote não contém notas C, nomes de modelo, tempos ou custos. Também não há autoria explícita no corpo didático.

## 2. Situação pedagógica
CONCLUÍDO.

## 3. Avaliação por subcritério
Subcritério | Nota | Evidência | Justificativa
--- | --- | --- | ---
M1.1 | 50 | São definidos no primeiro uso: antígeno, APC, MHC I/II, TCR, plasmócitos, células de memória, apoptose ("a morte celular programada"), opsonização e expansão clonal. Aparecem sem definição: "isotipo mais adequado", "maior afinidade", "complemento", "células efetoras" e "linfócitos virgens" (na resposta comentada 1). | A maior parte dos termos novos é explicada, mas alguns termos que o leitor ainda não domina ficam sem explicação. Isotipo e afinidade são justamente o que o texto usa para justificar por que a resposta secundária é "melhor".
M1.2 | 100 | Exemplos: "Os T auxiliares (CD4+) reconhecem peptídeos em MHC de classe II, exibidos por APCs. Eles não matam nem fagocitam..." e "Em resumo: o citotóxico executa; o auxiliar coordena." | Em geral, as frases têm sujeito e referente claros. Na síntese, "células de memória de ambos os tipos" é um pouco vaga, mas o contexto (B e T) permite entender. Não encontrei ambiguidade relevante.
M2.1 | 100 | A sequência é: Conceitos necessários (antígeno, APC, MHC, T, B, anticorpos, memória) → passos 1 a 6 (reconhecimento inato → B → T → expansão → reencontro → vacina). | Os componentes aparecem antes das relações. As etapas seguem uma progressão que dá para acompanhar. O passo 2 cita a ajuda dos T auxiliares antes do passo 3, mas os linfócitos T já estavam apresentados, e a função desses auxiliares é explicada logo em seguida. Essa antecipação não impede o acompanhamento.
M2.2 | 100 | Os três itens da Síntese reúnem: ativação via APC/MHC e expansão clonal; funções de plasmócitos, T citotóxicos, T auxiliares e memória; vacinação e seus limites ("não apenas da presença de anticorpos"). | A síntese integra o mecanismo, os papéis celulares e o objetivo (vacinação e limites da proteção) sem trazer pré-requisito novo.
M3.1 | 100 | Todas as seções tratam do recorte. Não há catálogo de citocinas, de subclasses ou de plataformas vacinais. IgM/IgG e adjuvante aparecem de forma breve e funcional. | Cada trecho contribui para o que foi pedido.
M3.2 | 100 | Os limites da proteção aparecem no passo 6, na Confusão 2 e na Síntese. A secundária mais rápida aparece no passo 5 e na Pergunta 1. | As retomadas servem para distinguir conceitos, justificar a resposta comentada e sintetizar. Não encontrei repetição sem função.
M4.1 | 50 | Parte atendida: há ligações causais explícitas. Exemplos: sem apresentação, o T não reconhece o antígeno; a circulação e o acúmulo nos linfonodos aumentam a chance de encontro; a célula infectada exibe fragmentos virais em MHC I e por isso é destruída; a secundária é mais rápida por haver mais células específicas, menor exigência de antígeno e anticorpos prontos. Limitação: no exemplo, as etapas descrevem só a apresentação em MHC II e a ativação de T auxiliares e B. Mesmo assim, o texto afirma que se formam "células B e T de memória" e que T de memória "gerados pela vacina" se tornam citotóxicos efetores (resposta comentada 2). | Há uma ocorrência relevante sem conexão causal: o texto não explica como uma vacina de proteína, apresentada em MHC II, levaria à formação de T citotóxicos de memória. A resposta comentada 2 justifica o resultado sem ligar as etapas que o produziriam.
M4.2 | 100 | "Contra patógenos de disseminação rápida, importa o anticorpo já presente, pois as células de memória não teriam tempo de proliferar"; variação do patógeno; idade ("recém-nascidos têm poucas células de memória"); "Níveis elevados de anticorpos não garantem automaticamente proteção"; limite do exemplo. | As condições e os limites são ligados à conclusão de que memória não significa proteção absoluta. Esse vínculo é retomado na Confusão 2 e na Síntese.
M5.1 | 100 | "um adulto jovem recebe uma vacina hipotética contendo proteínas de um vírus respiratório com adjuvante... meses depois, a pessoa inala o vírus." | A situação é concreta, hipotética e pertinente: vacinação seguida de contato posterior, sem vacina comercial.
M5.2 | 50 | Parte atendida: o exemplo liga cada etapa aos conceitos (dendríticas/MHC II, ajuda T→B, plasmócitos e B de memória, anticorpos que reduzem a entrada). A interpretação ("contida mais rápido") e o limite (variação, idade, "não prediz o resultado em um indivíduo") estão explicitados. Limitação: o papel dos T citotóxicos no contato posterior aparece sem apoio nas etapas da vacinação, que só mencionam MHC II. | Na maior parte, os elementos do exemplo são explicados pelos conceitos, mas um resultado central (a eliminação por T citotóxicos de memória) não tem relação explicada com os passos descritos.

## 4. Resumo
M1 | M2 | M3 | M4 | M5 | P
--- | --- | --- | --- | --- | ---
75 | 100 | 100 | 75 | 75 | 85

Memória de cálculo:
- M1 = (50+100)/2 = 75
- M2 = (100+100)/2 = 100
- M3 = (100+100)/2 = 100
- M4 = (50+100)/2 = 75
- M5 = (100+50)/2 = 75
- P = (75+100+100+75+75)/5 = 425/5 = 85

## 5. Limitações e alertas
**Possível erro científico, para revisão do juiz científico (JC).** Pela regra 3.4, isso não altera a situação pedagógica.
- O exemplo e a resposta comentada 2 afirmam que uma vacina só com proteínas gera T citotóxicos (CD8+) de memória.
- As fontes fornecidas associam o MHC I a peptídeos intracelulares e o MHC II a peptídeos extracelulares, e não tratam de apresentação cruzada.
- A afirmação pode ser uma simplificação sem sustentação no material.

**Pontos menores sem apoio literal nas fontes:**
- As dendríticas "migram para os linfonodos". A fonte fala em acúmulo de T e APC nos linfonodos.
- "Anticorpos podem cair sem que a memória celular desapareça."

**Limites desta avaliação:**
- É uma estimativa de qualidade didática feita por IA com base na rubrica. Não houve estudantes avaliados.
- Não apliquei contagem de palavras nem verifiquei estrutura formal, que cabem ao juiz tecnológico (JT).

As notas descrevem atendimento à rubrica e qualidade didática estimada; não demonstram compreensão ou aprendizagem humana.