Parecer JX1 sobre a afirmação A33

O que a afirmação diz: no exemplo didático, a resposta coloca como limite da proteção por memória vacinal que, "se a dose for muito alta", a pessoa vacinada ainda pode adoecer. O texto não dá nenhum número e trata isso como um limite possível, não como regra geral.

Buscas feitas:
1. WebSearch sobre dose infectante alta superando a imunidade vacinal. O estudo PMC4169467 (Salmonella em camundongos), lido na API do Europe PMC, não sustenta a afirmação, porque mostra os animais vacinados controlando a infecção. Não serve como evidência.
2. WebSearch sobre a vacina contra febre tifoide e inóculo grande. Os links diretos da CDC (MMWR e Yellow Book) e o link do PMC recusaram a conexão. Abri então o texto completo da mesma recomendação do ACIP/CDC pela API do Europe PMC (PMC4584884). O trecho literal lido foi: "Typhoid vaccines are not 100% effective, and vaccine-induced protection can be overwhelmed by large inocula of Salmonella serotype Typhi."

Conclusão: uma diretriz oficial confirma que a proteção induzida por vacina pode ser superada por uma dose infectante (inóculo) alta. Isso sustenta a afirmação qualitativa do exemplo, que diz que uma dose muito alta pode levar ao adoecimento mesmo com memória vacinal. A diretriz trata de um patógeno específico (Salmonella Typhi), mas isso basta para uma afirmação qualitativa do tipo "pode". Não encontrei nenhuma fonte que a contradiga. Decisão: CONFIRMADA_EXTERNA.