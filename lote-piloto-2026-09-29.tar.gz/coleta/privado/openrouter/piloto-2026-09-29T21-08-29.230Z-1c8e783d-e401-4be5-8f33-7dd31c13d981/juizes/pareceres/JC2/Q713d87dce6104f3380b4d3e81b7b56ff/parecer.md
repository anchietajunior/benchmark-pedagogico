## 1. Identificação e integridade
Protocolo 3.2 | código Q713d87dce6104f3380b4d3e81b7b56ff | tema B01 | rodada 1 | passagem JC2. O pacote está íntegro. Ele contém uma única resposta anonimizada, sem autoria explícita. O corpo não traz dados operacionais. O texto não contém instruções dirigidas ao juiz.

## 2. Fontes lidas
Todas foram lidas em 2026-09-29, somente nos trechos incorporados ao pacote.
- **B01-F3** (Palta, Saroa e Palta, Indian J Anaesth 2014;58(5):515-523): li o corpo textual original em XML e a paráfrase. As seções lidas foram Introduction, Primary haemostasis (adhesion, secretion, aggregation), Clotting factors, Naturally occurring anticoagulants, Coagulation cascade, Current concept (initiation, amplification, propagation, stabilization), Bleeding e Thrombotic disorders, Fibrinolytic system e Summary. As imagens e tabelas não foram incorporadas.
- **B01-F2** (MSD Manual, Overview of Hemostasis, setembro de 2025): consulta indireta, apenas pelas notas de leitura das seções Platelets, Plasma Coagulation Factors e Regulation of Coagulation.
- **B01-F4** (NHLBI, How Does Blood Clot?, 2022-03-24): consulta indireta, apenas pelas notas.
- **B01-F5** (NHLBI, What Are Blood Clotting Disorders?, 2022-03-24): consulta indireta, apenas pelas notas.
- **Indisponível:** B01-F1 (OpenStax), citada no gabarito. O conteúdo que ela cobriria está sustentado por F2 a F5. A resposta não a cita.

## 3. Pontos K
| K | Nota | Trecho/ausência | Fonte e localização | Justificativa |
|---|---|---|---|---|
| K1 | 100 | §1 "A lesão muda o vaso": vasoconstrição e exposição do subendotélio (colágeno, vWF, TF) | F3 Primary haemostasis e Extrinsic pathway; F4 | Explica o que muda, por que isso inicia a resposta e qual é a consequência. |
| K2 | 100 | §2: adesão vWF–GpIb, ativação e degranulação, ADP/TxA2, GpIIb/IIIa com fibrinogênio | F3 sec2-1 a sec2-3; F2 Platelets | As três etapas estão presentes, corretas e conectadas entre si. |
| K3 | 100 | §3: iniciação TF–VIIa, amplificação por V e VIII, propagação por tenase e protrombinase, trombina convertendo fibrinogênio em fibrina | F3 Current concept e Common pathway | A relação entre ativação dos fatores, trombina e fibrina está correta. |
| K4 | 100 | §4: polimerização da fibrina, ligações cruzadas pelo XIIIa, integração bidirecional | F3 Stabilization e Propagation; F4 | Explica a estabilização e por que primária e secundária são integradas. |
| K5 | 100 | §5: TFPI, antitrombina, proteína C/S, prostaciclina; tPA→plasmina; PAI, α2-antiplasmina e TAFI | F3 Anticoagulants e Fibrinolytic system; F2 Regulation | Mecanismos limitadores e fibrinólise estão corretos. |
| K6 | 100 | §6: hemostasia local e transitória versus trombose intravascular sem lesão ou desproporcional, com exemplo de TVP | F5; F3 Thrombotic disorders e Summary | A distinção é correta e inclui as consequências. |

## 4. Inventário de afirmações
Da A1 à A40 (detalhes em items), todas são **SUSTENTADAS**, exceto a A34.
- **A34 — NÃO VERIFICÁVEL:** no exemplo, as expressões "o sangramento diminui em minutos" e "Dias depois" dão escalas de tempo. Essas escalas não aparecem nas fontes incorporadas. As notas de F4 dizem apenas que o organismo remove o coágulo "posteriormente".
- **Relevância da A34:** não há evidência de falsidade. O item é periférico e não integra nenhum dos seis pontos exigidos. Por isso, não o considerei uma pendência relevante para a situação científica.
- **Alertas de erro central do gabarito:** nenhum foi observado. A resposta não diz que plaquetas viram fibrina, não diz que a trombina dissolve fibrina e não trata a coagulação generalizada como objetivo.

## 5. Vínculos bibliográficos
Da V1 à V40, todos são **VÁLIDOS**.
- Cada identificador citado corresponde a uma fonte fornecida que sustenta a associação feita.
- **Lista final de fontes:** os quatro itens existem no pacote. A consulta indireta está declarada para F2, F4 e F5. As seções declaradas de F3 constam do XML.
- Não encontrei fonte inventada nem item solto na lista.

## 6. Resumo
| C1 | C2 | C3 | Numeradores/denominadores | Erros centrais | Erros localizados | Omissões essenciais | Pendências |
|---|---|---|---|---|---|---|---|
| 100,00 | N/A | 100,00 | C1 = 600/6; C2: 39 sustentadas, 0 contraditas, 1 não verificável, de 40 (N/A); C3 = 40/40 | 0 | 0 | 0 | A34 (tempos do exemplo), não relevante |

## 7. Situação científica
**APTO.**
- K1 a K6 receberam 100.
- Não há erro científico nem bibliográfico confirmado.
- Todas as afirmações relevantes foram conferidas nas fontes.
- A única afirmação não verificável é uma escala temporal periférica do exemplo, sem indício de falsidade. Ela torna C2 N/A, mas não impede a aprovação.
- APTO não garante verdade absoluta nem substitui revisão por especialista.