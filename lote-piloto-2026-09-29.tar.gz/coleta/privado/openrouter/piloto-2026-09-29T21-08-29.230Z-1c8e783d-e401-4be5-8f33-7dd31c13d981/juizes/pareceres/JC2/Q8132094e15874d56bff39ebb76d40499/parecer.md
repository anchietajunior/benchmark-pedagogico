## 1. Identificação e integridade
- **Protocolo:** 3.2
- **Código:** Q8132094e15874d56bff39ebb76d40499
- **Tema:** B02
- **Rodada:** 1
- **Passagem:** JC2
- **Integridade do pacote:** há uma única resposta, sem autoria explícita. Pedido, gabarito e fontes estão presentes.

## 2. Fontes lidas nesta sessão (2026-09-29, somente o conteúdo incorporado)
| Fonte | O que foi lido | Extensão do acesso |
| --- | --- | --- |
| B02-F3 – Marshall et al., 2018, AACI 14(Suppl 2):49 | Notas em português e texto original em inglês das seções: The immune system (Innate immunity, Adaptive immunity, T cells and APCs, B cells), Antibody-mediated vs. cell-mediated immunity e Passive vs. active immunization; Tabelas 1 e 2 convertidas em texto | Sem figuras |
| B02-F4 – Bugya et al., 2021, Vaccines 9(2):174 | Notas e texto original das seções 1, 7 (com Consequences on Vaccination), 11, 13 e 14 | Sem figuras nem tabelas |
| B02-F5 – Clem, 2011, JGID 3(1):73 | Somente as notas de leitura (consulta indireta) | Texto original não incorporado |

**Indisponíveis:** B02-F1 (Janeway) e B02-F2 (Alberts), indicadas no gabarito. Consequência: a conferência depende das fontes substitutas. O gabarito não foi usado como evidência.

## 3. Pontos K1–K6
| K | Nota | Trecho | Fonte e localização | Justificativa |
| --- | --- | --- | --- | --- |
| K1 | 100 | Conceitos (antígeno, APC, MHC); Passo 1 | F3 – Innate immunity; T cells and APCs | Define antígeno. Liga a imunidade inata (receptores de padrões, mobilização de APCs) à apresentação em MHC e à ativação dos T. |
| K2 | 100 | Passo 2 | F3 – B cells; Antibody-mediated | O B reconhece o antígeno nativo e se diferencia em plasmócitos ou em B de memória. Os anticorpos marcam o patógeno e têm limite contra infecção já estabelecida. Não atribui anticorpos aos T. |
| K3 | 100 | Passo 3 | F3 – T cells and APCs | CD8+ usa MHC I e induz apoptose; CD4+ usa MHC II, não mata e coordena por citocinas. |
| K4 | 100 | Passo 4 | F3; F4 §7; F5 (notas) | Expansão clonal, morte da maioria das células efetoras, persistência de memória T e B, distinção entre plasmócitos de vida curta, de vida longa e B de memória. |
| K5 | 100 | Passo 5; Confusão 1 | F4 §7; F5 | Resposta secundária mais rápida e melhor. Distingue anticorpos (proteínas) de células de memória (células). |
| K6 | 100 | Passo 6; Limite do exemplo; Confusão 2 | F4 §1, §7, §11, §13; F5 | Vacina sem doença. Limites citados: anticorpos elevados não garantem proteção, velocidade do patógeno, variação do patógeno e idade. Não promete proteção absoluta. |

## 4. Afirmações (A1–A41)
- **Sustentadas:** A1 a A31, A33 a A40.
  - Fontes: F3 para inato/adaptativo, antígeno, APC/MHC, T e B, anticorpos, CD4/CD8, morte das efetoras e memória. F4 para plasmócitos de vida curta e longa, B de memória, prazos, resposta secundária, menor exigência de antígeno, múltiplos níveis, limites e idade. F5 (notas) para expansão em dias, ajuda T, troca de IgM para IgG e vacina sem doença.
  - A1: F3 descreve as APCs "accumulation... in lymph nodes"; isso foi aceito como base para a chegada das dendríticas aos linfonodos (A9).
  - A2: a definição de antígeno como proteína ou carboidrato foi aceita com base nas seções de F3 sobre antígenos estranhos e composição das vacinas.
  - A33: o exemplo supõe que se formam plasmócitos de vida longa após a vacina. F4 diz que isso "not necessarily" ocorre na primeira exposição. Como o exemplo é hipotético, não há contradição.
- **Não verificável:**
  - A32 – "células inatas detectam o adjuvante": sem base nas fontes.
  - A41 – células T citotóxicas de memória geradas pela vacina proteica: sem base nas fontes. F3 associa o MHC I a peptídeos endógenos e não descreve apresentação cruzada. A afirmação não foi confirmada como falsa, mas também não foi sustentada.
- **Contraditas:** nenhuma.

## 5. Vínculos com as fontes (V1–V40)
- **Válidos:** 38 vínculos (todos os citados em A1–A31, A33 e A37–A40), com as fontes F3, F4 e F5 associadas corretamente.
- **Não verificáveis:**
  - V34: A32 associada a F3/F4 no parágrafo "Etapas".
  - V40: A41 associada a F3.
- **Lista de fontes:** as três referências existem e estão corretamente descritas. F5 foi declarada corretamente como consulta indireta. A nota sobre Janeway e Alberts não consultados é verdadeira. Não há referência inventada.

## 6. Resumo
| C1 | C2 | C3 | Numeradores/denominadores | Erros centrais | Erros localizados | Omissões essenciais | Pendências |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 100,00 | N/A | N/A | C1 = 600/6. C2: 39 sustentadas de 41, 2 não verificáveis (parcial 95,12, não oficial). C3: 38 válidos de 40, 2 não verificáveis (parcial 95,00, não oficial) | 0 | 0 | 0 | A32/V34, A41/V40; B02-F1 e B02-F2 indisponíveis |

## 7. Situação científica: PENDENTE
Não há erro confirmado nem omissão essencial, e os pontos K1 a K6 estão completos. Ainda assim, duas afirmações do exemplo e da resposta comentada 2 não podem ser conferidas com as fontes acessíveis. A principal é a formação de T citotóxicos de memória por uma vacina proteica. Por isso, o protocolo não permite APTO. Os motivos N/A estão registrados em cada item.