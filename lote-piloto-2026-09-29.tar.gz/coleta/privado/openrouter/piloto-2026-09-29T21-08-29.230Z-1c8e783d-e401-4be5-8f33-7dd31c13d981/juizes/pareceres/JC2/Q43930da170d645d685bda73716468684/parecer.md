1. IDENTIFICAÇÃO E INTEGRIDADE
Protocolo 3.2; código Q43930da170d645d685bda73716468684; tema B01; rodada 1; passagem JC2.
Integridade do pacote: há uma única resposta anonimizada, sem autoria explícita. Estão presentes o pedido, o gabarito e o material bibliográfico. O pacote está íntegro.

2. FONTES LIDAS E INDISPONÍVEIS
Todo o acesso ocorreu em 2026-09-29, somente pelos trechos incorporados ao pacote, sem navegação.
- B01-F3: Palta, Saroa e Palta, Indian J Anaesth 2014;58(5):515-523.
  - Li o corpo textual original completo em XML, com todas as seções da Introduction até o Summary.
  - Li também a paráfrase em português do pacote.
  - As imagens e tabelas não estavam incorporadas.
- B01-F2 (MSD Manual profissional, set/2025): consulta indireta. Li apenas as notas de leitura redigidas por IA, referentes às seções Platelets, Plasma Coagulation Factors e Regulation of Coagulation.
- B01-F4 (NHLBI, How Does Blood Clot?, 2022-03-24): consulta indireta, apenas pelas notas de leitura.
- B01-F5 (NHLBI, What Are Blood Clotting Disorders?, 2022-03-24): consulta indireta, apenas pelas notas de leitura.
- B01-F1 (OpenStax), indicada no gabarito, não foi fornecida. Sua falta não compromete a conferência, porque F2 a F5 cobrem os seis pontos.

3. PONTOS K
| K | Nota | Trecho | Fonte | Justificativa |
|---|---|---|---|---|
| K1 | 100 | "A lesão rompe o endotélio e expõe... colágeno e fator von Willebrand"; há vasoconstrição por reflexos, endotelina e TxA2 | F3 Primary haemostasis; F4 | A relação essencial está correta. A frase "aproxima as bordas" é um detalhe adicional não verificável, tratado em A14/V12. |
| K2 | 100 | Adesão (vWF–GPIb), ativação (forma, grânulos, Ca), agregação (ADP, TxA2, fibrinogênio–IIb/IIIa) | F3 sec2-1 a 2-3; F2 | Correto e suficiente. |
| K3 | 100 | Iniciação (FT–VIIa), amplificação, propagação; protrombinase converte protrombina em trombina, que converte fibrinogênio em fibrina | F3 Current concept, Common pathway | Correto. |
| K4 | 100 | O XIIIa faz ligações covalentes; hemostasia primária e secundária são integradas; a superfície plaquetária sustenta a geração de trombina | F3 Stabilization; F4 | Correto. |
| K5 | 100 | Antitrombina, TFPI, proteína C/S, TxA2/prostaciclina; tPA converte plasminogênio em plasmina, que degrada a fibrina; inibidores da fibrinólise | F3 Anticoagulants, Fibrinolytic; F2 | Correto. |
| K6 | 100 | A trombose é um coágulo na circulação em local, momento ou tamanho inadequado; exemplo da TVP; papel do controle | F5 | Correto. |

4. INVENTÁRIO DE AFIRMAÇÕES
Resultado: 55 afirmações, 52 sustentadas (S), 0 contraditas e 3 não verificáveis (NV). A lista completa, com fontes, está nos itens A1 a A55.
- A14: "a constrição aproxima as bordas da lesão" (NV). As notas de F4 atribuem a aproximação das bordas à contração das plaquetas. Nenhuma fonte liga esse efeito à vasoconstrição.
- A23: o tampão seria "relativamente frouxo e reversível" (NV). F3 diz apenas "seals off... temporarily".
- A52: defeitos de plaquetas e defeitos de fatores causariam "sangramentos de formas diferentes" (NV). F3 e F4 dizem apenas que ambos comprometem a hemostasia.
Nenhuma afirmação da resposta cai nos alertas de erro central: ela não diz que plaquetas viram fibrina, nem que a trombina dissolve fibrina, nem que o objetivo seria coagular todo o sangue.

5. VÍNCULOS BIBLIOGRÁFICOS
Resultado: 46 vínculos distintos, 45 válidos e 1 com problema confirmado.
- Problema confirmado (V12): o texto associa a A14 a [B01-F4], mas F4 atribui o efeito descrito a outro mecanismo. É uma associação falsa confirmada.
- V33 (TFPI com F3): F3 sustenta a inibição do complexo FT–VIIa. A parte sobre o Xa vem de F2, citada em conjunto, por isso o vínculo é válido.
- Lista final de fontes: F2, F3, F4 e F5 existem no pacote, com títulos, datas e endereços corretos. A consulta indireta está declarada para F2, F4 e F5.
  - F3 aparece como "consultado diretamente via URL". Na verdade, o texto foi fornecido incorporado ao pacote. Há uma leve imprecisão, mas nenhuma fonte inventada.
  - As seções de F3 declaradas existem no texto fornecido.

6. RESUMO
| Medida | Valor | Cálculo | Observação |
|---|---|---|---|
| C1 | 100,00 | 600/6 | Todos os K valem 100. |
| C2 | N/A | 52 sustentadas / 55; 3 NV | Com itens não verificáveis, o C2 não é calculado. |
| C3 | 97,83 | 45/46 | 1 vínculo com problema. |
- Erros centrais: nenhum.
- Erros localizados: 1 erro bibliográfico confirmado (V12).
- Omissões essenciais: nenhuma.
- Pendências: A14, A23 e A52.

7. SITUAÇÃO CIENTÍFICA: CORRIGIR
O protocolo impede aprovação quando há associação bibliográfica falsa confirmada (V12). Essa regra tem prioridade, embora C1 = 100 e não haja erro científico central. As três afirmações não verificáveis continuam registradas como pendências.