## 1. Identificação e integridade
Protocolo 3.2 | código Qe4c3d53b86194d6c9008ea58164e8b23 | tema B01 | rodada 1 | passagem JC2.
O pacote está íntegro: há uma única resposta anonimizada, sem autoria explícita, acompanhada de pedido, gabarito e material bibliográfico. Nenhuma instrução embutida na resposta foi seguida.

## 2. Fontes lidas e indisponíveis
Todas as fontes foram consultadas em 2026-09-29, e apenas no material incorporado ao pacote.
- **B01-F3** – Palta, Saroa e Palta, *Indian J Anaesth* 2014;58(5):515-523. Li o corpo textual original em XML e a paráfrase. Seções observadas: Primary haemostasis (adhesion, secretion, aggregation), Clotting factors, Naturally occurring anticoagulants, Coagulation cascade (extrinsic, intrinsic, common), Current concept (initiation, amplification, propagation, stabilization), Thrombotic disorders, Fibrinolytic system e Summary. As imagens e tabelas não foram incorporadas ao pacote. Como o texto está completo, foi possível confirmar tanto a presença quanto a ausência de afirmações atribuídas a F3.
- **B01-F2** – MSD Manual Professional, *Overview of Hemostasis* (Streiff, setembro de 2025). Havia somente notas de leitura parafraseadas das seções Platelets, Plasma Coagulation Factors e Regulation of Coagulation. A consulta foi indireta, e a ausência de uma afirmação nas notas não prova que ela esteja ausente da obra.
- **B01-F4** – NHLBI/NIH, *How Does Blood Clot?* (2022-03-24). Somente notas de leitura; consulta indireta.
- **B01-F5** – NHLBI/NIH, *What Are Blood Clotting Disorders?* (2022-03-24). Somente notas de leitura; consulta indireta.
- **B01-F1** – OpenStax, indicada no gabarito, não foi fornecida. O gabarito não serviu como evidência, e os conceitos correspondentes foram conferidos em F2 a F5.

## 3. Cobertura dos seis pontos (K1-K6)
| K | Nota | Trecho | Fonte e localização | Justificativa |
|---|---|---|---|---|
| K1 | 100 | Seção 1: vasoconstrição, exposição do colágeno e do fator tecidual (TF) e início da resposta. | F3, Primary haemostasis e Extrinsic pathway; F4 | A mudança no vaso e o motivo pelo qual ela inicia a resposta estão corretos. |
| K2 | 100 | Seção 2: adesão via vWF/GpIb, ativação com degranulação, ADP e TxA2, e agregação via GpIIb/IIIa e fibrinogênio. | F3, Platelet adhesion, secretion e aggregation; F2 | As três etapas estão presentes e conectadas corretamente. |
| K3 | 100 | Seção 3: complexo TF-VIIa, geração de Xa e trombina, amplificação, tenase e protrombinase, conversão de fibrinogênio em fibrina. | F3, Current concept e Common pathway | A sequência está correta. |
| K4 | 100 | Seção 4: fator XIII com ligações covalentes; fosfolipídios plaquetários servem de plataforma para a coagulação. | F3, Stabilization, Platelet secretion e Common pathway; F2 | A estabilização e a integração entre hemostasia primária e secundária estão presentes. |
| K5 | 100 | Seção 5: TFPI, trombomodulina/proteína C/proteína S, antitrombina, e tPA convertendo plasminogênio em plasmina, que degrada a fibrina. | F2, Regulation; F3, Anticoagulants e Fibrinolytic system | Está correto e distingue inibir a formação de fibrina de degradar a fibrina existente. |
| K6 | 100 | Seção 6: hemostasia localizada e autolimitada versus trombose patológica, mesmo sem lesão, com comprometimento de órgãos. | F5; F3, Summary | A distinção está correta. |

## 4. Inventário de afirmações
| ID | Trecho | Situação | Nota | Fonte e localização | Justificativa |
|---|---|---|---|---|---|
| A1 | Conter a perda sem interromper o fluxo e restringir o coágulo ao local | SUSTENTADA | 100 | F3 aggregation/Summary; F4; F2 | Equilíbrio e agregação localizada que preserva a patência do lúmen. |
| A2 | O endotélio íntegro produz óxido nítrico e prostaciclina | SUSTENTADA | 100 | F2; F3 Primary haemostasis | — |
| A3 | O subendotélio contém colágeno e TF, isolados do sangue | SUSTENTADA | 100 | F3 Primary haemostasis/TF | — |
| A4 | Plaquetas são fragmentos de megacariócitos com grânulos | SUSTENTADA | 100 | F3 | — |
| A5 | Fatores são zimogênios ativados em sequência | SUSTENTADA | 100 | F3 Clotting factors | F3 diz "majority"; a generalização é leve. |
| A6 | A trombina cliva fibrinogênio em fibrina e gera alças de retroalimentação | SUSTENTADA | 100 | F3 Common pathway/Amplification | — |
| A7 | A plasmina cliva a fibrina durante o reparo | SUSTENTADA | 100 | F2; F3 Fibrinolytic | — |
| A8 | Vasoconstrição reflexa neurogênica e por mediadores locais | SUSTENTADA | 100 | F3; F4 | — |
| A9 | O estreitamento reduz a força de cisalhamento | NÃO VERIFICÁVEL | N/A | — | A redução da perda consta em F4, mas o cisalhamento não aparece em nenhuma fonte. |
| A10 | A lesão expõe colágeno e TF, o que dispara adesão e coagulação | SUSTENTADA | 100 | F3; F2 | — |
| A11 | O vWF faz a ponte entre colágeno e GpIb | SUSTENTADA | 100 | F3 Platelet adhesion | — |
| A12 | A adesão ocorre "mesmo sob fluxo sanguíneo rápido" | NÃO VERIFICÁVEL | N/A | — | Ausente das fontes. |
| A13 | Na ativação surgem pseudópodes, fosfolipídios expostos e degranulação α e densa | SUSTENTADA | 100 | F3 | — |
| A14 | Liberação de Ca e ADP, síntese de TxA2 e recrutamento de plaquetas | SUSTENTADA | 100 | F3 secretion/aggregation | — |
| A15 | GpIIb/IIIa muda de conformação e o fibrinogênio liga plaquetas vizinhas | SUSTENTADA | 100 | F2; F3 | — |
| A16 | TF-VIIa inicia in vivo, ativa X e IX, e Xa gera a trombina inicial | SUSTENTADA | 100 | F2; F3 Initiation | — |
| A17 | Amplificação: a trombina ativa V e VIII; os inibidores limitam a iniciação | SUSTENTADA | 100 | F3 Initiation/Amplification | — |
| A18 | A trombina ativa o fator XI na amplificação | NÃO VERIFICÁVEL | N/A | — | F3 não menciona; não há outra fonte. |
| A19 | Tenase e protrombinase na superfície plaquetária produzem uma explosão de trombina | SUSTENTADA | 100 | F3 Propagation | — |
| A20 | Fibrinopeptídeos são clivados e os monômeros polimerizam espontaneamente | NÃO VERIFICÁVEL | N/A | — | Ausente das fontes. |
| A21 | Os polímeros iniciais se mantêm por interações fracas e não covalentes (também na resposta 1) | NÃO VERIFICÁVEL | N/A | — | Ausente das fontes. |
| A22 | A trombina ativa o fator XIII, que faz ligações covalentes | SUSTENTADA | 100 | F3 Stabilization | — |
| A23 | A malha de fibrina envolve o tampão e as hemácias | SUSTENTADA | 100 | F3; F4 | — |
| A24 | Integração: fosfolipídios plaquetários servem de plataforma e a fibrina ancora as plaquetas | SUSTENTADA | 100 | F3; F2; F4 | — |
| A25 | O TFPI inibe TF-VIIa e Xa | SUSTENTADA | 100 | F2; F3 | — |
| A26 | Trombomodulina ativa a proteína C, que com a proteína S inativa Va e VIIIa | SUSTENTADA | 100 | F2; F3 Protein C | — |
| A27 | A antitrombina neutraliza trombina e Xa | SUSTENTADA | 100 | F2; F3 | — |
| A28 | Endotélio libera tPA, plasminogênio vira plasmina e surgem PDF e D-dímeros | SUSTENTADA | 100 | F2; F3 Fibrinolytic | — |
| A29 | Hemostasia localizada versus trombose por desequilíbrio, com comprometimento de órgãos | SUSTENTADA | 100 | F5; F3 | — |
| A30 | Tempos do exemplo: "em segundos", "poucos minutos", "horas após" | NÃO VERIFICÁVEL | N/A | — | Não há dados temporais nas fontes. |
| A31 | Etapas do exemplo aplicadas à punção | SUSTENTADA | 100 | F3; F2; F4 | Repetem mecanismos já conferidos. |
| A32 | Limite do exemplo: lesões arteriais volumosas exigem intervenção cirúrgica | NÃO VERIFICÁVEL | N/A | — | Ausente de F3 e das notas. |
| A33 | Confusão 1: hemostasia primária e secundária não são eventos isolados | SUSTENTADA | 100 | F2; F3 | — |
| A34 | Confusão 2: anticoagulantes não degradam fibrina; a plasmina degrada | SUSTENTADA | 100 | F2; F3 | — |
| A35 | Resposta 1: deficiência ou inibição do fator XIII causa ressangramento tardio | NÃO VERIFICÁVEL | N/A | — | Ausente das fontes. |
| A36 | Resposta 2: trombomodulina e heparan sulfato do endotélio íntegro; antitrombina potencializada | SUSTENTADA | 100 | F3 Antithrombin/Protein C; F2 | — |

Os itens da Síntese repetem afirmações já inventariadas e não foram contados de novo.

## 5. Vínculos bibliográficos
| ID | Afirmação e referência | Resultado | Nota |
|---|---|---|---|
| V1 | A1–F3 | VÁLIDO | 100 |
| V2 | A1–F4 | VÁLIDO | 100 |
| V3 | A1–F2 | VÁLIDO | 100 |
| V4 | A2–F2 | VÁLIDO | 100 |
| V5 | A2–F3 | VÁLIDO | 100 |
| V6 | A3–F3 | VÁLIDO | 100 |
| V7 | A4–F3 | VÁLIDO | 100 |
| V8 | A5–F3 | VÁLIDO | 100 |
| V9 | A6–F2 | NÃO VERIFICÁVEL | N/A (as notas não tratam da clivagem do fibrinogênio) |
| V10 | A6–F3 | VÁLIDO | 100 |
| V11 | A7–F2 | VÁLIDO | 100 |
| V12 | A7–F3 | VÁLIDO | 100 |
| V13 | A8–F3 | VÁLIDO | 100 |
| V14 | A8–F4 | VÁLIDO | 100 |
| V15 | A9–F3 | PROBLEMA CONFIRMADO | 0 (F3 não trata de fluxo nem de cisalhamento) |
| V16 | A10–F3 | VÁLIDO | 100 |
| V17 | A10–F2 | VÁLIDO | 100 |
| V18 | A11–F3 | VÁLIDO | 100 |
| V19 | A12–F3 | PROBLEMA CONFIRMADO | 0 |
| V20 | A13–F3 | VÁLIDO | 100 |
| V21 | A14–F3 | VÁLIDO | 100 |
| V22 | A15–F2 | VÁLIDO | 100 |
| V23 | A15–F3 | VÁLIDO | 100 |
| V24 | A16–F2 | VÁLIDO | 100 |
| V25 | A16–F3 | VÁLIDO | 100 |
| V26 | A17–F3 | VÁLIDO | 100 |
| V27 | A18–F3 | PROBLEMA CONFIRMADO | 0 |
| V28 | A19–F3 | VÁLIDO | 100 |
| V29 | A20–F3 | PROBLEMA CONFIRMADO | 0 |
| V30 | A21–F3 | PROBLEMA CONFIRMADO | 0 |
| V31 | A22–F3 | VÁLIDO | 100 |
| V32 | A23–F3 | VÁLIDO | 100 |
| V33 | A23–F4 | VÁLIDO | 100 |
| V34 | A24–F3 | VÁLIDO | 100 |
| V35 | A24–F2 | VÁLIDO | 100 |
| V36 | A24–F4 | VÁLIDO | 100 |
| V37 | A25–F2 | VÁLIDO | 100 |
| V38 | A25–F3 | VÁLIDO | 100 |
| V39 | A26–F2 | VÁLIDO | 100 |
| V40 | A26–F3 | VÁLIDO | 100 |
| V41 | A27–F2 | VÁLIDO | 100 |
| V42 | A27–F3 | VÁLIDO | 100 |
| V43 | A28–F2 | VÁLIDO | 100 |
| V44 | A28–F3 | VÁLIDO | 100 |
| V45 | A29–F3 | VÁLIDO | 100 |
| V46 | A29–F5 | VÁLIDO | 100 |
| V47 | A30–F3 | PROBLEMA CONFIRMADO | 0 |
| V48 | A30–F4 | NÃO VERIFICÁVEL | N/A (só há notas de leitura) |
| V49 | A31–F3 | VÁLIDO | 100 |
| V50 | A31–F2 | VÁLIDO | 100 |
| V51 | A31–F4 | VÁLIDO | 100 |
| V52 | A32–F3 | PROBLEMA CONFIRMADO | 0 |
| V53 | A33–F2 | VÁLIDO | 100 |
| V54 | A33–F3 | VÁLIDO | 100 |
| V55 | A34–F2 | VÁLIDO | 100 |
| V56 | A34–F3 | VÁLIDO | 100 |
| V57 | A35–F3 | PROBLEMA CONFIRMADO | 0 |
| V58 | A36–F2 | VÁLIDO | 100 |
| V59 | A36–F3 | VÁLIDO | 100 |

**Lista de fontes.** F2, F3, F4 e F5 existem no pacote, com títulos e datas compatíveis e consulta indireta declarada corretamente para as notas. F2 aparece sem URL, o que não é um problema científico. Não há fonte inventada.

## 6. Resumo dos cálculos
| C1 | C2 | C3 | Numeradores/denominadores | Erros centrais | Erros localizados | Omissões essenciais | Pendências |
|---|---|---|---|---|---|---|---|
| 100,00 | N/A | N/A | C1 = 600/6. C2: 28 afirmações sustentadas de 36, com 8 não verificáveis e 0 contraditas (parcial informativo: 77,78). C3: 49 vínculos válidos de 59, com 8 problemas confirmados e 2 não verificáveis (parcial informativo: 83,05). | 0 | 0 erros científicos confirmados; 8 vínculos bibliográficos falsos confirmados, todos atribuídos a B01-F3 | 0 | A9, A12, A18, A20, A21, A30, A32, A35; V9, V48 |

## 7. Situação científica: CORRIGIR
Os seis pontos pedidos estão cobertos corretamente, e não encontrei nenhuma afirmação científica contradita pelas fontes.
Mesmo assim, o texto atribui a B01-F3 afirmações que não aparecem no corpo original desse artigo, que está disponível na íntegra. São elas:
- o cisalhamento;
- a adesão sob fluxo rápido;
- a ativação do fator XI pela trombina;
- a polimerização espontânea dos monômeros;
- as interações fracas nos polímeros iniciais;
- os tempos do exemplo;
- a necessidade de cirurgia em lesões arteriais volumosas;
- o ressangramento tardio por deficiência do fator XIII.

Pelo protocolo, uma associação bibliográfica falsa confirmada exige CORRIGIR. As afirmações não verificáveis continuam registradas como pendências.