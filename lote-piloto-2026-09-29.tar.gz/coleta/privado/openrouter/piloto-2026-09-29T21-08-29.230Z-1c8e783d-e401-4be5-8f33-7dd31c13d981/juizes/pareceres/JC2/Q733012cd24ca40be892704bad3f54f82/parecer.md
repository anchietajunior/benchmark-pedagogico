1. INTEGRIDADE DO PACOTE
Protocolo 3.2; código Q733012cd24ca40be892704bad3f54f82; tema B02; rodada 1; passagem JC2. O pacote está íntegro: há uma única resposta anonimizada, sem autoria explícita, com pedido, gabarito e material bibliográfico. Não recebi dados operacionais nem notas anteriores.

2. FONTES LIDAS
A leitura foi feita em 2026-09-29 e se limitou ao material incorporado na chamada.

- B02-F3 (Marshall et al., 2018, Allergy Asthma Clin Immunol 14(Suppl 2):49):
  - Li o texto original em inglês das seções The immune system: innate and adaptive immunity (com as subseções Innate immunity, Adaptive immunity, T cells and APCs e B cells), Antibody-mediated vs. cell-mediated immunity e Passive vs. active immunization.
  - As tabelas estavam convertidas em texto e também li as notas em português.
  - As figuras não estavam disponíveis.
- B02-F4 (Bugya et al., 2021, Vaccines 9(2):174):
  - Li o texto original em inglês das seções 1, 7 (com Consequences on Vaccination), 11, 13 (com Consequences on Vaccination) e 14, além das notas.
  - Figuras e tabelas não estavam disponíveis.
- B02-F5 (Clem, 2011, J Glob Infect Dis 3(1):73): a consulta foi apenas indireta, pelas notas de leitura em português. Não havia texto original.
- Indisponíveis:
  - Não tive acesso a B02-F1 (Janeway) nem a B02-F2 (Alberts), indicados no gabarito.
  - As fontes substitutas cobrem os seis pontos. Por isso, essa ausência não gera pendência por si só.

3. TABELA K
K | Nota | Trecho/ausência | Fonte e localização | Justificativa
K1 | 100 | Definição de antígeno; seção 'Reconhecimento inicial e apresentação' (inata, PRR, dendríticas, MHC II) | F3, Innate immunity; T cells and APCs | A relação entre antígeno, imunidade inata, APC e ativação de T está correta. A migração da APC (A11) é um detalhe não verificável, e não uma relação exigida.
K2 | 100 | 'Os linfócitos B ligam-se a antígenos intactos...'; plasmócitos; anticorpos | F3, B cells; Antibody-mediated; F4, seção 7 | A relação entre B, plasmócitos e anticorpos está correta.
K3 | 100 | CD4+ reconhece MHC II e age por citocinas, sem matar; CD8+ reconhece MHC I e induz apoptose | F3, T cells and APCs | Correto.
K4 | 100 | Expansão clonal; a maioria das efetoras morre e uma fração persiste como memória | F3, T cells and APCs; F4, seção 7 | Correto.
K5 | 100 | Resposta secundária; Confusão 1 (anticorpos vs. células de memória) | F4, seção 7; F3, B cells | Correto e diferencia anticorpos de células de memória.
K6 | 0 | 'Ela induz a resposta primária controlada, gerando plasmócitos de vida longa...'; 'A presença de células de memória garante rapidez de resposta' | F4, seção 7 (Consequences) e seção 13 | O ponto está presente e contém limites corretos, mas tem dois erros confirmados. Pela regra, a nota é 0.

4. INVENTÁRIO DE AFIRMAÇÕES
Afirmação ID | Trecho | Situação | Nota | Fonte e localização | Justificativa
- A1 | Resposta adaptativa específica com memória; base da vacinação | SUSTENTADA | 100 | F3, Adaptive immunity | 'basis for effective immunization'.
- A2 | Antígeno como estrutura estranha reconhecida pelos linfócitos | SUSTENTADA | 100 | F3, Adaptive immunity | Reconhecimento de antígenos 'não próprios'.
- A3 | APCs (dendríticas, macrófagos) capturam, processam e exibem a T | SUSTENTADA | 100 | F3, Innate immunity; T cells and APCs | —
- A4 | MHC I em nucleadas com peptídeos intracelulares; MHC II em APCs com peptídeos extracelulares | SUSTENTADA | 100 | F3, T cells and APCs | —
- A5 | B reconhecem antígeno nativo via receptor de superfície | SUSTENTADA | 100 | F3, B cells | —
- A6 | Plasmócitos derivam de B e secretam grandes volumes de anticorpos | SUSTENTADA | 100 | F3, B cells | —
- A7 | Anticorpos solúveis neutralizam ou marcam o antígeno | SUSTENTADA | 100 | F3, Tabela 2 e Antibody-mediated | —
- A8 | T amadurecem no timo; o TCR reconhece peptídeo-MHC | SUSTENTADA | 100 | F3, T cells and APCs | —
- A9 | Inata primeiro; dendríticas detectam padrões via PRR e fagocitam | SUSTENTADA | 100 | F3, Innate immunity | —
- A10 | Proteínas digeridas em peptídeos exibidos em MHC II | SUSTENTADA | 100 | F3, T cells and APCs | —
- A11 | APC migra pelos vasos linfáticos até os linfonodos | NÃO VERIFICÁVEL | N/A | F3 cita apenas acúmulo de T com APC nos linfonodos | A migração da APC não consta no material.
- A12 | Sinais de T auxiliares levam B a diferenciar-se em plasmócitos de vida curta/longa | SUSTENTADA | 100 | F3, Antibody-mediated; F4, seção 7; F5, notas | —
- A13 | IgM inicial, depois IgG | SUSTENTADA | 100 | F3, Tabela 2; F5, notas | —
- A14 | Neutralização, opsonização, complemento | SUSTENTADA | 100 | F3, Antibody-mediated; Tabela 2 | —
- A15 | CD4+: MHC II, sem ação citotóxica, citocinas ajudam B, orientam a classe e ativam macrófagos | SUSTENTADA | 100 | F3, T cells and APCs; Antibody-mediated | —
- A16 | CD8+: MHC I, apoptose de células infectadas | SUSTENTADA | 100 | F3, T cells and APCs | —
- A17 | Expansão clonal de B e T específicos | SUSTENTADA | 100 | F3; F4, seção 7; F5, notas | —
- A18 | A maioria das efetoras morre; persistem memória B, T CD4 e CD8 e LLPC na medula | SUSTENTADA | 100 | F3, T cells and APCs; F4, seções 7 e 13 | —
- A19 | Na secundária há mais células específicas e limiar menor | SUSTENTADA | 100 | F4, seção 7 | Redução da exigência mínima de antígeno.
- A20 | B de memória geram plasmócitos com anticorpos de maior afinidade; IgG | SUSTENTADA | 100 | F4, seção 7; F5, notas | —
- A21 | T de memória geram efetoras em poucos dias | SUSTENTADA | 100 | F4, seção 7 | —
- A22 | Latência menor, frequentemente antes de manifestações clínicas | SUSTENTADA | 100 | F3, Adaptive immunity; F4, Introduction | Proteção contra o desenvolvimento da doença.
- A23 | Vacinação como imunização ativa com agentes inativados, atenuados ou frações; adjuvantes | SUSTENTADA | 100 | F3, Passive vs. active | —
- A24 | Adjuvantes 'para recrutar a imunidade inata' | NÃO VERIFICÁVEL | N/A | F3 diz apenas que adjuvantes melhoram a resposta | O mecanismo não é descrito.
- A25 | A vacina induz resposta primária 'gerando plasmócitos de vida longa' e memória | CONTRADITA | 0 | F4, seção 7, Consequences on Vaccination | 'The limited number of antigens in the vaccine does not necessarily trigger the formation of LLPC during the first exposure'.
- A26 | Proteção não absoluta: variação antigênica, disseminação rápida, imunossenescência | SUSTENTADA | 100 | F4, seções 7, 11, 13 e 14 | —
- A27 | Exemplo, etapas 1 a 3: APC e MHC II, ajuda de T a B, IgM→IgG, memória | SUSTENTADA | 100 | F3; F4; F5 | Aplicação hipotética coerente.
- A28 | Exemplo, etapa 4: IgG preexistente e memória B geram resposta rápida | SUSTENTADA | 100 | F4, seção 7 | —
- A29 | 'A presença de células de memória garante rapidez de resposta' | CONTRADITA | 0 | F4, seção 13 (responsividade deteriora; memória exaurida); seção 7 (pecado antigênico original) | A generalização é contradita.
- A30 | Mutações de epítopos podem fazer a memória falhar | SUSTENTADA | 100 | F4, seção 7 | —
- A31 | Confusão 1: anticorpos são proteínas secretadas e degradadas; memória são células persistentes que respondem | SUSTENTADA | 100 | F3, B cells; F5, notas | —
- A32 | Confusão 2: CD4 não é citotóxico; CD8 destrói | SUSTENTADA | 100 | F3, T cells and APCs | —
- A33 | Pergunta 1: a ajuda de CD4 (que depende de MHC II) é necessária para proliferação e troca de classe de B | SUSTENTADA | 100 | F3, Antibody-mediated; F4, seção 7 (CD40/AID); F5, notas | —
- A34 | Pergunta 2: imunossenescência (involução tímica, menor diversidade, CG falhos) reduz LLPC, memória e títulos | SUSTENTADA | 100 | F4, seção 13 | —

5. VÍNCULOS
Os vínculos V1 a V52 estão detalhados em items.
- Válidos: 48.
- Problema confirmado: V36 (A25/F4) e V43 (A29/F4), porque a fonte citada contradiz a associação.
- Não verificáveis: V13 (A11/F3) e V35 (A24/F3).
- Lista final de fontes:
  - Os três identificadores existem, e títulos, seções e DOIs conferem.
  - F5 é declarada como consulta indireta.
  - F3 e F4 declaram texto original e notas, o que é compatível com o pacote.
  - Não há itens soltos inválidos.

6. RESUMO
C1 | C2 | C3 | Numeradores/denominadores | Erros centrais | Erros localizados | Omissões essenciais | Pendências
83,33 | N/A | N/A | C1 = 500/6; C2 parcial = 30 sustentadas/34, com 2 contraditas e 2 NV; C3 parcial = 48 válidos/52, com 2 problemas e 2 NV | Nenhum | A25 e A29 (vínculos V36 e V43) | Nenhuma | A11, A24, V13 e V35

7. SITUAÇÃO CIENTÍFICA: CORRIGIR
Há dois erros localizados confirmados no ponto 6: a formação de LLPC é apresentada como garantida na vacinação primária, e a memória é descrita como garantia de rapidez. Por isso, K6 = 0. As pendências A11 e A24 permanecem registradas. O restante do conteúdo está sustentado pelas fontes incorporadas.