## 1. Identificação e integridade
Protocolo 3.2 | código Qfd240f0c4808408c89168e0e12a86eb7 | tema B01 | rodada 1 | passagem JC2.
O pacote está íntegro: há uma única resposta, sem autoria explícita nem dados operacionais. O pedido, o gabarito e as fontes estão presentes. A resposta não contém instruções dirigidas ao juiz.

## 2. Fontes lidas (acesso em 2026-09-29, somente material incorporado)
- **B01-F3** (Palta, Saroa e Palta, Indian J Anaesth 2014;58(5):515-523). Li a nota de leitura em português e o corpo textual original em XML, na íntegra. As seções usadas foram Primary haemostasis, Clotting factors, Naturally occurring anticoagulants, Coagulation cascade/Common pathway, Current concept of coagulation, Thrombotic disorders e Fibrinolytic system. As imagens e tabelas não foram incorporadas e não foram inspecionadas.
- **B01-F2** (MSD Manual, Overview of Hemostasis, set. 2025): consulta indireta, somente pela nota de leitura (paráfrase).
- **B01-F4** (NHLBI, How Does Blood Clot?, 2022-03-24): consulta indireta, somente pela nota de leitura.
- **B01-F5** (NHLBI, What Are Blood Clotting Disorders?, 2022-03-24): consulta indireta, somente pela nota de leitura.
- **B01-F1** (OpenStax), citada no gabarito, não foi fornecida. O impacto é nulo, porque F2 a F5 sustentam os mesmos conceitos. As obras originais de F2, F4 e F5 não foram lidas; a conferência dessas fontes se limita às notas de leitura.

## 3. Pontos K
| K | Nota | Trecho | Fonte | Justificativa |
|---|---|---|---|---|
| K1 | 100 | "A lesão desencadeia vasoconstrição... expõe colágeno e... fator tecidual" | F3 Primary haemostasis/Extrinsic pathway; F4 nota | Mudança no vaso e motivo do início da resposta, ambos corretos |
| K2 | 100 | Adesão (vWF–GPIb), ativação (ADP, TxA2, IIb/IIIa), agregação (fibrinogênio entre receptores IIb/IIIa) | F3 Platelet adhesion/secretion/aggregation; F2 nota | As três etapas estão corretas e ligadas à formação do tampão |
| K3 | 100 | TF-VIIa ativa IX e X; amplificação; protrombinase; trombina converte fibrinogênio em fibrina | F3 Current concept/Common pathway | Correto |
| K4 | 100 | "ativa o fator XIII..."; "São divisões didáticas, não processos independentes" | F3 Stabilization/Platelet aggregation; nota F3 | Estabilização e integração corretas |
| K5 | 100 | Antitrombina, TFPI, proteína C/S, NO/prostaciclina; tPA→plasmina degrada fibrina; alfa-2-antiplasmina | F2 nota; F3 Fibrinolytic system | Correto |
| K6 | 100 | "Trombose é a formação patológica de um coágulo dentro da circulação... localização, extensão e controle" | F5 nota; F3 Prostacyclin | Distinção correta |

## 4. Inventário de afirmações
Foram inventariadas 37 afirmações (A1–A37), detalhadas em items. Todas são SUSTENTADAS pelas fontes: nenhuma é contradita e nenhuma ficou sem verificação.

Dois pontos pediram atenção:
- **A22.** A resposta diz que NO e prostaciclina desfavorecem "ativação e agregação". A nota F2 fala apenas em agregação, mas F3 menciona "synthesis and secretion of platelet inhibitors" pelo endotélio. Considerei a afirmação sustentada.
- **A33.** A limitação do exemplo não traz citação. Ela é sustentada por F3: deficiência parcial de FXI sem sangramento incomum.

## 5. Vínculos bibliográficos
Foram inventariados 32 vínculos (V1–V32): 28 no corpo do texto e 4 entradas da lista de fontes. Todos são VÁLIDOS.

A entrada de B01-F3 na lista de fontes omite o nome do periódico, mas traz volume, páginas e DOI corretos; isso não configura falsidade. As entradas de F2, F4 e F5 declaram corretamente a consulta indireta pelas notas.

## 6. Resumo
| C1 | C2 | C3 | Numeradores/denominadores | Erros centrais | Erros localizados | Omissões essenciais | Pendências |
|---|---|---|---|---|---|---|---|
| 100,00 | 100,00 | 100,00 | C1 600/6; C2 37/37; C3 32/32 | 0 | 0 | 0 | 0 relevantes |

A conferência de F2, F4 e F5 é indireta, feita pelas notas de leitura.

## 7. Situação científica: APTO
- K1 a K6 receberam 100.
- Todas as afirmações foram conferidas e sustentadas.
- Nenhum dos alertas do gabarito ocorre: a resposta não diz que plaquetas viram fibrina, que a trombina dissolve fibrina nem que o objetivo seja coagular todo o sangue.
- Não há referência falsa nem pendência relevante.

APTO não garante verdade absoluta nem substitui revisão por especialista.