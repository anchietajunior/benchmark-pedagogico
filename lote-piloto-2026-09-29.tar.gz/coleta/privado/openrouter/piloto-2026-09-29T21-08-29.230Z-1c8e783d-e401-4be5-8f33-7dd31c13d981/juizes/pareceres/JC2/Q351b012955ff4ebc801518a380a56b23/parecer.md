## 1. Identificação e integridade do pacote
Parecer do juiz científico, protocolo 3.2. Código público: Q351b012955ff4ebc801518a380a56b23. Tema: B02. Rodada: 1. Passagem: JC2.
O pacote está íntegro. Há uma única resposta anonimizada, e não aparece declaração de autoria nem dado operacional. Pedido, gabarito e material bibliográfico estão presentes. Nenhuma instrução contida na resposta foi tratada como comando.

## 2. Fontes lidas e fontes indisponíveis
Todas as leituras foram feitas em 2026-09-29, apenas no material incorporado à chamada.

- **B02-F3** (Marshall et al., Allergy Asthma Clin Immunol 2018;14(Suppl 2):49)
  - Li o texto original em inglês destas seções: The immune system (Innate immunity; Adaptive immunity; T cells and APCs; B cells), Antibody-mediated vs. cell-mediated immunity e Passive vs. active immunization.
  - Também li as notas de leitura em português.
  - As tabelas estão disponíveis como texto. As figuras não foram incorporadas.
- **B02-F4** (Bugya et al., Vaccines 2021;9(2):174)
  - Li o texto original em inglês das seções 1, 7 (incluindo Consequences on Vaccination), 11, 13 e 14.
  - Também li as notas de leitura. Figuras e tabelas não foram incorporadas.
- **B02-F5** (Clem, J Glob Infect Dis 2011;3(1):73)
  - Acesso indireto, somente pelas notas de leitura (paráfrases). O texto original não estava disponível.
  - Por isso, as afirmações atribuídas a F5 foram conferidas contra as notas. Todas também encontram apoio convergente em F3 ou F4.
- **Indisponíveis:** B02-F1 e B02-F2 (Janeway e Alberts), que são as fontes do gabarito, não foram fornecidas.
  - O protocolo permite conferir por fontes alternativas incorporadas. F3, F4 e F5 cobrem os seis pontos.
  - Consequência: o gabarito foi usado apenas como checklist, não como evidência.

## 3. Pontos K1-K6

| K | Nota | Trecho | Fonte e localização | Justificativa |
|---|---|---|---|---|
| K1 | 100 | Definição de antígeno; a resposta inata libera citocinas e mobiliza/ativa APC; a dendrítica processa e exibe peptídeos no MHC; MHC I/II; circulação de T nos linfonodos | F3 Innate immunity; T cells and APCs; F5 (notas) | A relação entre inata, apresentação e ativação adaptativa está correta e é suficiente. |
| K2 | 100 | B reconhece o antígeno nativo; prolifera e origina plasmócito (secreta anticorpos) ou B de memória; funções dos anticorpos; limite na infecção viral estabelecida | F3 B cells; Antibody-mediated | Está correto. Os anticorpos são atribuídos aos plasmócitos, não aos T. |
| K3 | 100 | CD4+ com MHC II: não matam, liberam citocinas e ajudam o B. CD8+ com MHC I: induzem apoptose de células infectadas ou tumorais | F3 T cells and APCs | A distinção de funções está correta. |
| K4 | 100 | Expansão clonal de clones específicos; a maioria das efetoras morre e poucas ficam como memória; plasmócitos de vida curta e de vida longa; prazos de uma semana e de semanas | F3; F4 seção 7; F5 notas | Está correto e suficiente. |
| K5 | 100 | Resposta secundária mais rápida e de melhor qualidade; LLPC atuam de imediato; memória prolifera em dias; menor antígeno mínimo; anticorpos não são células de memória (Confusão 1) | F4 seção 7; F3 B cells | Está correto e inclui a distinção entre anticorpo e célula de memória. |
| K6 | 100 | Vacina como imunização ativa, sem doença; limites: títulos altos não garantem proteção, patógeno rápido, variantes, idade (10-30% vs 50-75%) | F5 notas; F3 Passive vs active; F4 seções 1, 7, 13, 14 | A relação com a vacinação e os limites da proteção estão corretos. |

## 4. Inventário de afirmações (47 itens; todas SUSTENTADAS, nota 100)

| ID | Trecho | Fonte e localização |
|---|---|---|
| A1 | Intervalo entre a exposição e a resposta máxima | F3 innate and adaptive |
| A2 | A memória permite resposta mais rápida e eficiente | F3 |
| A3 | Definição de antígeno e origens (micróbios, vírus, toxinas, tumores) | F3, primeiro parágrafo |
| A4 | A inata é imediata ou age em horas, é inespecífica e não tem memória convencional | F3; F4 seção 1 (trained immunity justifica o termo "convencional") |
| A5 | PRR detectam estruturas comuns | F3 Innate immunity |
| A6 | A adaptativa é específica e mais lenta na primeira exposição | F3; F5 notas |
| A7 | APC digere o antígeno e exibe peptídeos no MHC; dendríticas são as usuais, mas macrófagos e B também apresentam | F3 T cells and APCs |
| A8 | T amadurecem no timo; cada um tem um único tipo de TCR | F3 |
| A9 | B reconhece o antígeno por anticorpo de membrana | F3 B cells |
| A10 | Anticorpo é proteína secretada; plasmócito produz grandes quantidades | F3 |
| A11 | Inata: citocinas como pequenas proteínas de comunicação; mobiliza e ativa APC | F3 Innate immunity |
| A12 | A dendrítica engloba, processa e exibe peptídeos no MHC | F3; F5 notas |
| A13 | MHC I em nucleadas, com peptídeos intracelulares; MHC II em algumas células imunes, com peptídeos extracelulares | F3 |
| A14 | Circulação de T e acúmulo nos linfonodos aumentam a chance de encontro | F3 |
| A15 | A inata é complementar e prepara a ativação | F3 ("not mutually exclusive"; "aided by innate") |
| A16 | B reconhece o antígeno nativo sem APC | F3 |
| A17 | B ativado origina plasmócito ou B de memória | F3 |
| A18 | Anticorpos agem via complemento, opsonização e efetoras | F3 Antibody-mediated |
| A19 | Anticorpos contêm a fase aguda, mas não eliminam vírus já estabelecido | F3 |
| A20 | CD4+/MHC II não matam e liberam citocinas diretoras | F3 |
| A21 | Th ajudam o B a multiplicar-se e orientam o tipo de anticorpo | F3 Antibody-mediated |
| A22 | B com ajuda de Th gera memória mais eficaz | F5 notas |
| A23 | CD8+/MHC I induzem apoptose de células infectadas ou tumorais | F3 |
| A24 | Lógica didática: CD8+ "enxerga dentro" da célula; CD4+ coordena | F3 (MHC I intracelular; Th "mediate") |
| A25 | Clone, ativação específica e expansão clonal geram efetoras | F3; F5 notas; F4 seção 1 ("antigen specific lymphocyte clones") |
| A26 | A maioria das efetoras T morre e poucas ficam como memória | F3 |
| A27 | Plasmócitos de vida curta e de vida longa | F4 seção 7 |
| A28 | F3 descreve plasmócitos como de vida relativamente curta | F3 B cells |
| A29 | Primária em cerca de uma semana; células de vida longa em semanas | F4 seção 7 |
| A30 | Secundária: mais células prontas; LLPC atuam de imediato; memória prolifera em dias | F4 seção 7 |
| A31 | A secundária repete a primária, mais rápida, com maior afinidade | F4 seção 7 |
| A32 | B de memória reduzem o antígeno mínimo necessário | F4 Consequences on Vaccination |
| A33 | A vacina imita o estímulo sem causar a doença | F5 notas; F4 seção 1 |
| A34 | Imunização ativa; adjuvantes | F3 Passive vs active |
| A35 | A passiva é temporária; termina com a degradação dos anticorpos | F5 notas |
| A36 | Dois níveis ideais de defesa (anticorpos e memória) | F4 seção 1 |
| A37 | Limites: títulos altos não garantem proteção; patógeno rápido; influenza; idade 10-30% vs 50-75% | F4 seções 7, 11 e 13 |
| A38 | Etapas do exemplo após a vacina | F3; F5 |
| A39 | A existência de memória T citotóxica depende do tipo de vacina | F4 seção 7 (correlatos variam por vacina) |
| A40 | No contato posterior: anticorpos bloqueiam, B de memória proliferam, CD8+ eliminam via MHC I | F3; F4 |
| A41 | Resposta mais rápida por aumento dos clones específicos | F4 seções 1 e 7 |
| A42 | Limite: velocidade de disseminação, variação antigênica, idade e estado imune | F4 seções 7 e 14 |
| A43 | Anticorpo não é célula de memória; a queda dos anticorpos não prova ausência de memória; a passiva é temporária | F3; F4; F5 |
| A44 | Memória não é proteção absoluta (tempo de proliferação, variantes, títulos) | F4 seção 7 |
| A45 | Resposta comentada 1: cadeia causal Th → B | F3; F5 |
| A46 | Resposta comentada 2: benefício condicional à velocidade de disseminação | F4 seção 7 |
| A47 | A síntese retoma as ideias do mecanismo e da vacinação com limites | F3; F4; F5 |

Observações sobre o inventário:
- A25: a frase "clones compartilham o mesmo receptor" simplifica a mutação somática nos centros germinativos descrita em F4. No recorte pedido, isso não constitui erro confirmado.
- A47: a frase "a vacinação cria anticorpos e memória" é qualificada no mesmo item pelos limites da proteção.

## 5. Vínculos bibliográficos (47 itens; todos VÁLIDOS, nota 100)
V1-V47 cobrem as associações entre afirmação e fonte declaradas no texto, distribuídas assim:
- F3: V1-V12, V14-V22, V24, V25, V27, V29, V35, V39, V42, V45
- F5: V13, V23, V26, V34, V36, V43, V46
- F4: V28, V30-V33, V37, V38, V40, V41, V44, V47

Todos os vínculos foram conferidos no trecho indicado. As citações de F5 trazem corretamente a marca de consulta indireta.

Lista final de fontes: há três entradas, e todas foram fornecidas e usadas no texto. As seções declaradas correspondem às seções incorporadas. A ausência de inspeção de figuras está declarada, e F5 aparece corretamente como consulta apenas pelas notas. Não há referência inventada nem item solto problemático.

## 6. Resumo

| C1 | C2 | C3 | Numeradores/denominadores | Erros centrais | Erros localizados | Omissões essenciais | Pendências |
|---|---|---|---|---|---|---|---|
| 100,00 | 100,00 | 100,00 | C1: 600/6; C2: 47/47; C3: 47/47 | 0 | 0 | 0 | Nenhuma relevante. Limitações: F1/F2 do gabarito indisponíveis e substituídas por F3-F5; F5 conferida apenas pelas notas |

## 7. Situação científica: APTO
- K1-K6 valem 100.
- Todas as afirmações foram conferidas nas fontes incorporadas.
- Não há erro científico ou bibliográfico confirmado.
- Não há pendência relevante.
- Nenhum dos alertas de erro central do gabarito foi observado: anticorpos são atribuídos aos plasmócitos, não se confunde anticorpo com célula e não se promete imunidade absoluta.

APTO não é garantia de verdade absoluta nem revisão por especialista.