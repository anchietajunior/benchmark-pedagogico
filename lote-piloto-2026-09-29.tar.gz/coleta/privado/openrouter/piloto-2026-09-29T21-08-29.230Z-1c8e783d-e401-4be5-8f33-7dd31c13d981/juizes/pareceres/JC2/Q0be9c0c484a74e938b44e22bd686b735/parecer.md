## Parecer do juiz científico, protocolo 3.2

**Situação: APTO.** A cobertura dos seis pontos está completa (K1 a K6 = 100). As 40 afirmações foram confirmadas nas fontes e todos os 35 vínculos bibliográficos são válidos. Não há erro científico nem pendência.

### 1. Identificação e integridade do pacote

- **Versão:** 3.2
- **Código:** Q0be9c0c484a74e938b44e22bd686b735
- **Tema:** B02, resposta imune adaptativa e memória imunológica
- **Rodada:** 1
- **Passagem:** JC2

O pacote está íntegro. Há uma única resposta anonimizada, sem declaração de autoria, notas anteriores ou dados operacionais. Estão presentes o pedido, o gabarito, a nota de cobertura das fontes e as fontes. A resposta foi tratada como dado.

### 2. Fontes lidas e indisponíveis

A leitura foi feita em 2026-09-29, somente dentro do pacote incorporado.

**Fontes lidas:**
- **B02-F3**, Marshall et al., Allergy Asthma Clin Immunol 2018;14(Suppl 2):49, DOI 10.1186/s13223-018-0278-1.
  - Li o texto original em inglês, integral nas seções incorporadas: "The immune system: innate and adaptive immunity" (Innate immunity, Adaptive immunity, T cells and APCs, B cells), "Antibody-mediated vs. cell-mediated immunity" e "Passive vs. active immunization".
  - Li as tabelas convertidas em texto (Tabela 1, barreiras; Tabela 2, funções das Ig).
  - As figuras não foram fornecidas.
- **B02-F4**, Bugya et al., Vaccines 2021;9(2):174, DOI 10.3390/vaccines9020174.
  - Li o texto original em inglês das seções 1, 7 (com "Consequences on Vaccination"), 11, 13 (com "Consequences on Vaccination") e 14.
  - As figuras e tabelas não foram fornecidas.
- **B02-F5**, Clem 2011: disponível só como notas de leitura em português, redigidas por IA. A consulta é indireta. A resposta não cita esta fonte; usei-a apenas como apoio complementar.

**Fontes indisponíveis:** B02-F1 e B02-F2 (Janeway; Alberts), que são as fontes do gabarito, não foram fornecidas. Consequência: não há impedimento, porque F3 e F4, com texto original, bastaram para conferir os seis pontos e todas as afirmações. O gabarito não foi usado como evidência.

### 3. Cobertura dos seis pontos (K)

Tabela: K | Nota | Trecho/ausência | Fonte e localização | Justificativa

| K | Nota | Trecho/ausência | Fonte e localização | Justificativa |
|---|---|---|---|---|
| K1 | 100 | "Antígeno é uma estrutura reconhecida especificamente…"; Mecanismo §1: a imunidade inata reconhece padrões, ativa APC; dendríticas processam e apresentam peptídeo–MHC; linfonodos; TCR | F3, Innate immunity (PRR/PAMP; mobilização de APC); T cells and APCs | Estão presentes a definição, a participação da imunidade inata e a apresentação, todas corretas. |
| K2 | 100 | Mecanismo §2: o B reconhece diretamente; parte origina plasmócitos; anticorpos neutralizam, opsonizam e acionam o complemento | F3, B cells; Antibody-mediated; Tabela 2 | A relação B → plasmócito → anticorpo → efeitos está correta. |
| K3 | 100 | CD4+/MHC II coordena; CD8+/MHC I induz apoptose de células infectadas | F3, T cells and APCs | A distinção funcional está correta. |
| K4 | 100 | Mecanismo §4: expansão, efetores e memória; a maioria dos efetores desaparece; distinção entre plasmócitos de vida curta e de vida longa | F3, T cells/B cells; F4 §7 | Correto, inclusive a ressalva sobre a vida dos plasmócitos. |
| K5 | 100 | Mecanismo §5: anticorpos já presentes agem de imediato; B e T de memória proliferam; resposta mais rápida; maturação de afinidade | F4 §7 (secondary response) | Correto. As Confusões e o Exemplo distinguem anticorpos de células de memória. |
| K6 | 100 | Mecanismo §6: imunização ativa sem doença; reforços; a proteção depende de anticorpos, agente, variantes e idade; impedir infecção ≠ limitar doença | F3, Passive vs. active; F4 §1, §7 Consequences, §11, §13 | A relação com a vacinação e os limites da proteção estão corretos, sem prometer imunidade absoluta. |

**C1** = (100+100+100+100+100+100)/6 = **100,00**

### 4. Inventário de afirmações (A)

Tabela: Afirmação ID | Trecho | Situação | Nota 100/0/N/A | Fonte e localização | Justificativa

Todas as afirmações estão **SUSTENTADAS** (nota 100). A justificativa de cada uma consta em items.

| ID | Trecho resumido | Fonte e localização |
|---|---|---|
| A1 | A resposta adaptativa reconhece alvos específicos e pode deixar células de memória | F3, Adaptive immunity |
| A2 | Antígeno é uma estrutura reconhecida; pode ser uma proteína do vírus, não o agente inteiro | F3: "bind to antigens on the surface of pathogens"; "specific proteins or carbohydrates" |
| A3 | Linfócitos B e T têm receptores específicos; virgens ainda não responderam | F3, TCR/B cells; F4 §7, "naive T and B cells" |
| A4 | APC capturam e exibem fragmentos; destacam-se as dendríticas | F3: "usually dendritic cells" |
| A5 | MHC expõe peptídeos; citocinas são proteínas de comunicação | F3 |
| A6 | Plasmócitos derivam de B e secretam anticorpos; células de memória persistem | F3, B cells |
| A7 | A imunidade inata reconhece padrões compartilhados e mobiliza células e sinais | F3, Innate immunity |
| A8 | A imunidade inata favorece a ativação de APC | F3: "activate the adaptive immune response through… APCs" |
| A9 | Dendríticas processam e apresentam peptídeos a T | F3 |
| A10 | Nos linfonodos aumenta a chance de encontro | F3 |
| A11 | O TCR reconhece peptídeo–MHC com sinais adequados | F3: "appropriate signals" |
| A12 | A imunidade inata treinada difere da memória convencional | F4 §1 |
| A13 | O B reconhece diretamente, sem APC | F3, B cells |
| A14 | O B internaliza o antígeno e o apresenta a T auxiliares, recebendo sinais de sobrevivência/proliferação | F4 §7 |
| A15 | Parte dos B ativados origina plasmócitos | F3 |
| A16 | Anticorpos neutralizam toxinas/vírus, facilitam a fagocitose e acionam o complemento | F3, Antibody-mediated; Tabela 2 |
| A17 | O complemento participa da eliminação de microrganismos | F3, Innate immunity; Tabela 1 |
| A18 | CD4+ reconhece MHC II, presente em algumas células imunes | F3 |
| A19 | A função do auxiliar é coordenar e ajudar B e outras células | F3 |
| A20 | CD8+ reconhece MHC I, presente nas nucleadas | F3 |
| A21 | O citotóxico induz apoptose de células infectadas | F3 |
| A22 | Anticorpos agem fora da célula; CD8 age sobre células infectadas (complementares) | F3, Antibody-mediated vs. cell-mediated |
| A23 | Expansão clonal = multiplicação dos específicos, gerando efetores e memória | F3; F4 §7 |
| A24 | A expansão explica parte da demora da resposta primária | F3 (lag time); F4 (cerca de uma semana); F5, notas |
| A25 | A maioria dos efetores desaparece; B e T de memória persistem | F3 |
| A26 | Plasmócitos de vida longa mantêm anticorpos; a descrição de F3 não deve ser generalizada | F4 §7 (LLPC vs SLPC) |
| A27 | No reencontro, anticorpos já presentes agem de imediato | F4 §7, secondary response |
| A28 | Há mais células específicas; B de memória geram plasmócitos; T de memória voltam a efetores | F4 §7; F3 |
| A29 | A resposta tende a ser mais rápida e eficiente | F3; F4 |
| A30 | Seleção por afinidade com ajuda de T; nem todas as células de memória têm igual afinidade | F4 §7 |
| A31 | A vacinação é imunização ativa, sem precisar enfrentar a doença | F3; F4 §1 |
| A32 | Reforços aproveitam as células de memória | F4 §7, Consequences |
| A33 | A proteção depende da quantidade/função/localização dos anticorpos, da resposta celular e do agente | F4 §7, Consequences; §14 |
| A34 | Patógeno rápido pode avançar antes de novos anticorpos | F4 §7 (fast pathogens rely on LLPC) |
| A35 | Alterações antigênicas reduzem o reconhecimento | F4 §7 (influenza, original antigenic sin) |
| A36 | Idade e estado imune influenciam; impedir infecção ≠ limitar doença | F4 §1, §11, §13, §14 |
| A37 | Exemplo: vacina hipotética induz B/T, efetores, plasmócitos e memória; LLPC sustentam anticorpos | F3; F4 §7 |
| A38 | Exemplo: no contato, anticorpos bloqueiam parte dos vírus, CD8 combate células infectadas e a memória amplia; resultado: menor doença, sem garantia diante de variantes | F4 §1, §7 |
| A39 | Anticorpos são proteínas e não proliferam; B de memória geram plasmócitos; memória não garante proteção absoluta | F3; F4 |
| A40 | Respostas comentadas: a expansão amplia os específicos; infecção pós-vacina não implica ausência de benefício | F3; F4 §1 |

Todas as afirmações foram decididas: 40 sustentadas, 0 contraditas, 0 não verificáveis.

Uma nuance foi verificada. F4 observa que a vacina não necessariamente induz plasmócitos de vida longa na primeira exposição. O exemplo, porém, é explicitamente condicionado ("neste exemplo, consegue induzir…") e não afirma uma generalização. Por isso não há contradição.

### 5. Vínculos bibliográficos (V)

Contei 35 vínculos, cada um sendo um par entre o parágrafo ou item e a fonte citada:

| Trecho da resposta | Vínculos |
|---|---|
| Ideia central | V1 (F3), V2 (F4) |
| Conceitos | V3 (F3), V4 (F4), V5 (F3), V6 (F3), V7 (F4) |
| Mecanismo | V8 a V24 |
| Exemplo | V25 a V30 |
| Confusões | V31, V32 (F4) |
| Perguntas | V33 (F3), V34 (F4), V35 (F4) |

- **Resultado:** todos VÁLIDOS. As referências existem no pacote e sustentam a associação.
- **Lista de fontes:** F3 e F4 estão corretas quanto a título, ano, DOI e seções efetivamente fornecidas. A consulta ao texto original incorporado está declarada corretamente.
- **Problemas:** nenhum item solto e nenhuma referência inventada. F5 não foi citada, o que não é problema.

### 6. Resumo

| C1 | C2 | C3 | Numeradores/denominadores | Erros centrais | Erros localizados | Omissões essenciais | Pendências |
|---|---|---|---|---|---|---|---|
| 100,00 | 100,00 | 100,00 | C1 600/6; C2 40/40; C3 35/35 | 0 | 0 | 0 | Nenhuma |

### 7. Situação científica

**APTO.** Os seis pontos estão cobertos de forma correta e suficiente e todas as afirmações foram sustentadas pelas fontes. Não há erro científico ou bibliográfico nem pendência relevante.

A resposta evita os erros centrais esperados:
- não atribui a produção de anticorpos aos linfócitos T;
- distingue anticorpos (proteínas) de células de memória;
- não promete imunidade absoluta.

APTO não é garantia de verdade absoluta nem revisão por especialista. Não houve revisão humana do pacote de fontes.