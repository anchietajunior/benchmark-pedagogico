## 1. Identificação e integridade
Protocolo 3.2 | código Q81614ddb9f47410cbee1d9536cb9b159 | tema B01 | rodada 1 | passagem JC2. O pacote tem uma única resposta, sem autoria explícita nem dados operacionais. Íntegro.

## 2. Fontes lidas
- **B01-F3** (Palta, Saroa, Palta, Indian J Anaesth 2014;58(5):515-523): li o corpo textual original em XML/inglês por inteiro, incluindo Primary haemostasis, Clotting factors, Naturally occurring anticoagulants, Coagulation cascade/Common pathway, Current concept, Fibrinolytic system, Thrombotic disorders e Summary, além da paráfrase em português. As imagens e tabelas não foram incorporadas.
- **B01-F2** (MSD Manual, set. 2025), **B01-F4** e **B01-F5** (NHLBI, 2022-03-24): acesso só indireto, pelas notas de leitura redigidas por IA.
- **B01-F1** (OpenStax), citada no gabarito, está indisponível. Isso não impede a avaliação, porque as outras fontes sustentam os mesmos conceitos. Acesso em 2026-09-29.

## 3. Pontos K
| K | Nota | Trecho | Fonte | Justificativa |
|---|---|---|---|---|
| K1 | 100 | Seção 1: vasoconstrição, exposição de colágeno, vWF e fator tecidual | F3 Primary haemostasis/Extrinsic; F4 | A resposta explica a mudança no vaso e por que ela inicia a hemostasia. |
| K2 | 100 | Seção 2: vWF–GpIb, pseudópodes, ADP/TxA2, GpIIb/IIIa–fibrinogênio | F3; F2 | Adesão, ativação e agregação estão corretas. |
| K3 | 100 | Seção 3: iniciação FT/VIIa, amplificação, protrombinase, trombina→fibrina | F3 Current concept/Common pathway | Correto e suficiente. |
| K4 | 100 | Seção 4: XIIIa, integração primária/secundária | F3 Stabilization; F4 | Correto. |
| K5 | 100 | Seção 5: AT, TFPI, proteína C/S, tPA→plasmina | F2; F3 | Correto. |
| K6 | 100 | Seção 6: falha de controle, coágulos sem lesão, TVP | F5 | Correto. |

## 4. Inventário A
São 40 afirmações: 39 SUSTENTADAS e 1 NÃO VERIFICÁVEL (A30, qualificador 'proporcionais'). Nenhuma foi contradita. Detalhes estão nos itens A1–A40.

Observações sobre afirmações sustentadas:
- **A13:** a mudança conformacional de GpIIb/IIIa induzida por ADP está em F3; F2 sustenta a ponte feita pelo fibrinogênio.
- **A20:** o candidato aponta corretamente a inconsistência 'TF-VIIIa' no próprio texto de F3.
- **A32:** 'não é a natureza do coágulo' é uma interpretação aceitável de F5 ('localização e controle da resposta importam').

## 5. Vínculos V
São 41 vínculos: 40 VÁLIDOS e 1 NÃO VERIFICÁVEL (V31, A30–F3). Não há fonte inventada.

A lista final corresponde ao material fornecido. A seção 'Fibrinolytic system' atribuída a F3 existe no texto incorporado. O candidato declara corretamente a consulta indireta de F2, F4 e F5.

## 6. Resumo
| C1 | C2 | C3 | Numeradores/denominadores | Erros centrais | Erros localizados | Omissões essenciais | Pendências |
|---|---|---|---|---|---|---|---|
| 100.00 | N/A | N/A | C1 600/6. C2: 39 sustentadas + 1 NV de 40 (parcial 97.50). C3: 40 válidos + 1 NV de 41 (parcial 97.56) | 0 | 0 | 0 | A30/V31 (proporcionalidade); B01-F1 indisponível |

## 7. Situação científica
**PENDENTE.** Os seis pontos K estão completos e não há erro confirmado. Mesmo assim, uma afirmação do inventário (A30) não pode ser conferida com as fontes fornecidas. Por isso C2 e C3 não são calculáveis e há uma pendência relevante que impede APTO. Não há erro que determine CORRIGIR.