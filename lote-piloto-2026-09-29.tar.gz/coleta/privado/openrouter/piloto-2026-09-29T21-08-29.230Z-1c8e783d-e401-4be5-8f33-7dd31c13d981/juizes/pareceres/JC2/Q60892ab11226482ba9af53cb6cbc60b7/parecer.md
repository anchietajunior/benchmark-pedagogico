# Parecer do juiz científico: JC2, protocolo 3.2

## 1. Identificação e integridade do pacote
- Versão: 3.2
- Código: Q60892ab11226482ba9af53cb6cbc60b7
- Tema: B02
- Rodada: 1
- Passagem: JC2

O pacote contém uma única resposta anonimizada, sem autoria explícita. Também estão presentes o pedido, o gabarito e o material bibliográfico. Não foram recebidas notas anteriores nem dados operacionais. O pacote está íntegro.

## 2. Fontes lidas e fontes indisponíveis
Todo o acesso ocorreu em 2026-09-29.

**Lidas**
- **B02-F3** — Marshall et al., *Allergy, Asthma & Clinical Immunology*, 2018;14(Suppl 2):49.
  - Texto original em inglês das seções "The immune system: innate and adaptive immunity" (Innate immunity; Adaptive immunity; T cells and APCs; B cells), "Antibody-mediated vs. cell-mediated immunity" e "Passive vs. active immunization".
  - Inclui as tabelas convertidas em texto e as notas em português. As figuras não foram incorporadas.
- **B02-F4** — Bugya et al., *Vaccines*, 2021;9(2):174.
  - Texto original das seções 1, 7 (incluindo "Consequences on Vaccination"), 11, 13 e 14, além das notas em português. Figuras e tabelas não foram incorporadas.
- **B02-F5** — Clem, *Journal of Global Infectious Diseases*, 2011;3(1):73.
  - Consulta apenas indireta, pelas notas de leitura. O texto original não foi incorporado.

**Indisponíveis**
- **B02-F1 e B02-F2** (Janeway; Alberts), indicadas no gabarito, não foram fornecidas.
- Os seis pontos puderam ser conferidos nas fontes substitutas. A falta das fontes-base, por si só, não cria pendência.

## 3. Pontos obrigatórios (K)
| K | Nota | Trecho | Fonte e localização | Justificativa |
|---|---|---|---|---|
| K1 | 100 | Definição de antígeno; inata com PRR e citocinas ativa APC; APC processa e apresenta peptídeos em MHC I/II | F3: Innate immunity; T cells and APCs. F5: notas, "Stimulation of immunity by vaccines" | Correto e suficiente |
| K2 | 100 | B reconhece antígeno nativo pelo BCR; origina plasmócitos que secretam anticorpos ou células B de memória; funções dos anticorpos | F3: B cells; Antibody-mediated. F4: seção 7 | Correto |
| K3 | 100 | CD4+ reconhece MHC II, não mata e coordena por citocinas; CD8+ reconhece MHC I e induz apoptose | F3: T cells and APCs | Correto |
| K4 | 100 | Expansão clonal gera efetoras; a maioria morre e poucas ficam como memória | F3: T cells and APCs; B cells. F5: notas | Correto |
| K5 | 100 | Reexposição com mais células, LLPC e proliferação em dias; resposta mais rápida e de melhor qualidade; memória ≠ anticorpo | F4: seção 7. F3 | Correto |
| K6 | 100 | Vacina é imunização ativa sem doença; anticorpos não garantem proteção; limites por disseminação, variantes, idade e ADE | F4: seções 1, 7, 13 e 14. F5 | Correto. As afirmações não verificáveis do exemplo não anulam o ponto |

## 4. Inventário de afirmações (A)
As repetições da síntese não foram contadas como afirmações novas.

| ID | Trecho resumido | Situação | Nota | Fonte e localização |
|---|---|---|---|---|
| A1 | Antígeno: estrutura estranha, como micróbios, vírus, toxinas, células tumorais | Sustentada | 100 | F3, parágrafo inicial |
| A2 | Inata: rápida, inespecífica, sem memória | Sustentada | 100 | F3 |
| A3 | PRR detectam padrões; inata mobiliza APC | Sustentada | 100 | F3: Innate immunity |
| A4 | Adaptativa: específica, mais lenta na primeira exposição, com memória | Sustentada | 100 | F3; F5 |
| A5 | Dendríticas fagocitam, processam e exibem peptídeos em MHC | Sustentada | 100 | F3 |
| A6 | MHC I: peptídeo intracelular para CD8+; MHC II: extracelular para CD4+ | Sustentada | 100 | F3: T cells and APCs |
| A7 | TCR é o receptor do T; BCR é anticorpo de superfície que reconhece antígeno nativo | Sustentada | 100 | F3: B cells |
| A8 | Plasmócitos secretam anticorpos; memória é célula de vida longa | Sustentada | 100 | F3; F4 |
| A9 | Citocinas inatas recrutam células e ativam APC | Sustentada | 100 | F3 |
| A10 | Sem apresentação, o T específico dificilmente reconhece o antígeno | Sustentada | 100 | F3: "T cells require the action of APCs" |
| A11 | B reconhece sem APC e pode atuar como APC | Sustentada | 100 | F3: B cells |
| A12 | B ativado origina plasmócitos ou B de memória | Sustentada | 100 | F3 |
| A13 | Citocinas de Th ajudam o B e orientam o tipo de anticorpo | Sustentada | 100 | F3: Antibody-mediated |
| A14 | Anticorpos neutralizam, opsonizam e ativam complemento | Sustentada | 100 | F3, tabela 2 e texto |
| A15 | Plasmócitos de vida curta e de vida longa; B de memória é outra população | Sustentada | 100 | F3; F4, seção 7 |
| A16 | CD4+: MHC II, não mata, citocinas dirigem B, macrófagos e CD8 | Sustentada | 100 | F3: "directing other cells to perform these tasks"; Th1 ativa macrófagos |
| A17 | CD8+: MHC I, apoptose de células infectadas ou tumorais | Sustentada | 100 | F3 |
| A18 | Expansão clonal gera efetoras | Sustentada | 100 | F3; F5 |
| A19 | A maioria das efetoras morre; poucas ficam como memória T e B | Sustentada | 100 | F3 |
| A20 | B de memória mantém receptores; T de memória vira efetora rapidamente | Sustentada | 100 | F3 |
| A21 | Memória não é anticorpo circulante | Sustentada | 100 | F3; F4 |
| A22 | Reexposição: mais células, anticorpos de LLPC imediatos, proliferação em poucos dias | Sustentada | 100 | F4, seção 7 |
| A23 | Secundária mais rápida e de melhor qualidade, com maior afinidade, isotipo adequado e IgG | Sustentada | 100 | F4; F5; F3, tabela |
| A24 | B de memória reduz o limiar de antígeno; uso em reforços | Sustentada | 100 | F4, "Consequences on Vaccination" |
| A25 | Vacinação é imunização ativa sem causar doença | Sustentada | 100 | F4, seção 1; F5 |
| A26 | Vacina imita o estímulo e gera anticorpos e memória | Sustentada | 100 | F4, seção 1; F5 |
| A27 | Anticorpos elevados não garantem proteção | Sustentada | 100 | F4, seção 7 |
| A28 | Disseminação rápida depende de anticorpo pronto; lenta dá tempo à B de memória | Sustentada | 100 | F4, seção 7 |
| A29 | Variantes escapam; idade, estado imune e comorbidades influenciam | Sustentada | 100 | F4, seções 7, 13 e 14 |
| A30 | ADE: anticorpo que se liga sem inativar pode facilitar entrada | Sustentada | 100 | F4, seção 7 |
| A31 | Exemplo: sequência inata → APC → T/B → plasmócitos e memória; consolidação em semanas | Sustentada | 100 | F4, seção 7; F3 |
| A32 | Exemplo: anticorpos neutralizam no início; memória prolifera se o agente ultrapassa; menor chance de doença | Sustentada | 100 | F4, seção 1 |
| A33 | Exemplo: dose muito alta do agente pode levar ao adoecimento | Não verificável | N/A | Nenhuma fonte trata da dose infectante |
| A34 | Exemplo: disseminação rápida, variante ou imunidade enfraquecida limitam a proteção | Sustentada | 100 | F4 |
| A35 | Medir anticorpos não mede toda a memória celular | Sustentada | 100 | Decorre da distinção em F3/F4 |
| A36 | Proteção depende da quantidade e qualidade dos anticorpos | Sustentada | 100 | F4: "amount, effectiveness and localization" |
| A37 | Pergunta 1: mais células de memória e LLPC encurtam seleção e expansão | Sustentada | 100 | F4, seção 7 |
| A38 | Pergunta 2: memória B/T pode proteger com poucos anticorpos, sem garantia | Sustentada | 100 | F4, seções 1 e 7 |
| A39 | Pergunta 2: proteção depende da "quantidade de antígeno" | Não verificável | N/A | F4 só trata do limiar reduzido pela memória, não de um limite de proteção |

## 5. Vínculos bibliográficos (V)
**V1–V38, V40–V44: válidos (nota 100).** Cada fonte citada sustenta a afirmação associada:
- V1–V6, V8–V9: afirmações de conceitos e do passo 1 → F3.
- V7: plasmócitos e memória → F4.
- V10: passo 1 → F5 (notas sobre englobamento e MHC).
- V11–V14: passo 2 → F3.
- V15: passo 2 → F4.
- V16–V17: passo 3 → F3.
- V18: passo 4 → F3.
- V19: passo 4 → F5.
- V20–V21: passo 4 → F3.
- V22: passo 4 → F4.
- V23–V24: passo 5 → F4.
- V25: passo 5 → F5 (IgG).
- V26: passo 5 → F4.
- V27 e V29: passo 6 → F4.
- V28 e V30: passo 6 → F5.
- V31–V34: passo 6 → F4.
- V35: confusão 1 → F3.
- V36: confusão 1 → F4.
- V37: confusão 2 → F4.
- V38: pergunta 1 → F4.
- V40–V41: síntese → F3.
- V42–V43: síntese → F4.
- V44: síntese → F5.

**V39: não verificável (N/A).** A resposta comentada da pergunta 2 cita B02-F4, que não sustenta a parte sobre "quantidade de antígeno".

**Lista de fontes:** F3, F4 e F5 existem e estão corretamente descritas. F5 está identificada como consulta indireta. A nota sobre Janeway e Alberts é correta. Nenhuma referência foi inventada.

## 6. Resumo
| C1 | C2 | C3 | Numeradores/denominadores | Erros centrais | Erros localizados | Omissões essenciais | Pendências |
|---|---|---|---|---|---|---|---|
| 100,00 | N/A | N/A | C1: 600/6. C2: 37 sustentadas, 2 não verificáveis, 39 inventariadas. C3: 43 válidos, 1 não verificável, 44 declarados | 0 | 0 | 0 | A33, A39/V39 |

## 7. Situação científica: PENDENTE
Não há erro confirmado nem omissão essencial, e K1 a K6 estão em 100. Porém, duas afirmações sobre limites da proteção (dose alta do agente e quantidade de antígeno) não podem ser conferidas com o material fornecido, e uma delas tem vínculo com B02-F4 que também não é verificável. Por isso a resposta não pode ser considerada APTO.

Essas pendências não indicam falsidade. Elas se resolvem com uma fonte autorizada que trate desses pontos.