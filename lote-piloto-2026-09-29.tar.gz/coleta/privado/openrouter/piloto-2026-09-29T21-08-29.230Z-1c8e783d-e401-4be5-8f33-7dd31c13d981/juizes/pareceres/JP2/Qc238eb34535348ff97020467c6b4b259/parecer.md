1. Identificação e certificado
Protocolo de pontuação 3.2, com a regra do protocolo 3.4 do contrato de saída, que substitui a exigência de APTO por um certificado de avaliação cega. Código público: Qc238eb34535348ff97020467c6b4b259. Tema: B02. Rodada: 1. Passagem: JP2.
Conferência do certificado:
- Versão 3.4, compatível com a regra que prevalece.
- Código de destino idêntico.
- Tema B02.
- Rodada R01, equivalente à rodada 1.
- Passagem JP2.
- Elegibilidade: resposta completa, com avaliação cega.
O certificado é compatível. O pacote não contém notas C, pareceres científicos, identidade do autor nem dados operacionais. Uma resposta foi recebida, sem autoria explícita.

2. Situação pedagógica: CONCLUÍDO.

3. Tabela de subcritérios (Subcritério | Nota | Evidência | Justificativa)
- M1.1 | 50 | Parte atendida: o texto define antígeno, APC, MHC (classes I e II), TCR, anticorpo, plasmócito, célula de memória, apoptose ("a morte celular programada"), opsonização e expansão clonal no primeiro uso. Limitação: "complemento", "isotipo", "afinidade", "IgG/IgM", "linfócitos virgens" e "adjuvante" (este definido só pela finalidade) aparecem sem definição. | Estes termos estão além do conhecimento prévio definido e sustentam passagens-chave: a resposta secundária, a primeira pergunta e os limites. Por isso o atendimento é parcial.
- M1.2 | 100 | Exemplos: "Os T auxiliares (CD4+) reconhecem peptídeos em MHC de classe II, exibidos por APCs. Eles não matam nem fagocitam..."; "Em resumo: o citotóxico executa; o auxiliar coordena." | Sujeitos e referentes são identificáveis em todas as seções. Abreviações como "o B" e "os T" foram introduzidas antes. Não há ambiguidade relevante.
- M2.1 | 100 | A seção Conceitos necessários apresenta antígeno, APC/MHC, T, B, anticorpos e memória. Depois, o Mecanismo percorre os passos 1 a 6: da apresentação até a vacinação e seus limites. | Os componentes vêm antes das relações. As etapas seguem a ordem do mecanismo: reconhecimento, efetores, expansão, memória e reencontro.
- M2.2 | 100 | Síntese em três itens: inata→APC/MHC→ativação e expansão; papéis de plasmócitos, CD8, CD4 e memória; vacinação e limites "não apenas da presença de anticorpos". | Os itens integram o percurso e respondem ao objetivo do pedido: participação de B e T, memória, vacinação e limites. Nenhum pré-requisito novo é introduzido.
- M3.1 | 100 | Todos os trechos tratam de reconhecimento, efetores, memória, reexposição e vacina. Citocinas e isotipos aparecem só de passagem. | O texto não se desvia para subclasses, catálogos de citocinas ou plataformas vacinais, que estão fora do recorte.
- M3.2 | 100 | Retomadas com função: "Em resumo: o citotóxico executa; o auxiliar coordena"; a primeira pergunta reaplica o passo 5; a confusão 2 condensa os limites em forma de distinção. | As retomadas servem para sintetizar, aplicar ou justificar. Não se observa repetição sem função.
- M4.1 | 100 | Trechos: "sem a apresentação, o linfócito T específico não consegue reconhecer o antígeno"; "Como os T circulam... a chance... aumenta"; "Como quase toda célula nucleada tem MHC I, uma célula infectada... é destruída"; a Q1 justifica a maior rapidez da resposta secundária pelo maior número de células, pela menor necessidade de antígeno e pelos anticorpos prontos. | As conexões entre as etapas são justificadas ("porque", "como consequência"), e o texto vai além de listar acontecimentos.
- M4.2 | 50 | Parte atendida: a condição da velocidade de disseminação vem justificada ("as células de memória não teriam tempo de proliferar"), e a idade é ligada à quantidade e à eficácia da memória. Limitação: "Níveis elevados de anticorpos não garantem automaticamente proteção" aparece sem explicar por quê. O escape de variantes também não é ligado explicitamente à especificidade dos receptores. A confusão 2 enumera fatores ("quantidade, localização e afinidade...") sem desenvolvê-los. | Um dos limites centrais pedidos fica afirmado, mas sem mecanismo. É ele que sustenta a conclusão de que memória não é proteção absoluta.
- M5.1 | 100 | O exemplo traz uma vacina hipotética com proteínas de um vírus respiratório e adjuvante, dada a um adulto jovem sem contato prévio, seguida de inalação do vírus meses depois. | A situação é concreta, hipotética, pertinente e não depende de uma vacina comercial.
- M5.2 | 50 | Parte atendida: as etapas ligam dendríticas, MHC II, T auxiliares, B, plasmócitos e memória. No contato posterior, os anticorpos presentes, a conversão rápida de B de memória e o limite (variante, idoso) são interpretados à luz dos conceitos. Limitação: nas etapas da vacina só aparecem a apresentação em MHC II e a ativação de T auxiliares. Mesmo assim, o contato posterior e a resposta à Q2 atribuem a eliminação a "T de memória gerados pela vacina" que agem como citotóxicos via MHC I. O texto não explica como uma vacina de proteínas geraria memória CD8. | Um elemento do resultado do exemplo não decorre das etapas apresentadas: o estudante não consegue reconstruir essa relação.

4. Resumo (M1 | M2 | M3 | M4 | M5 | P)
75 | 100 | 100 | 75 | 75 | 85
Memória de cálculo:
- M1 = (50 + 100)/2 = 75
- M2 = (100 + 100)/2 = 100
- M3 = (100 + 100)/2 = 100
- M4 = (100 + 50)/2 = 75
- M5 = (100 + 50)/2 = 75
- P = (75 + 100 + 100 + 75 + 75)/5 = 425/5 = 85

5. Limitações e alertas
- Possível ponto científico, para a revisão especializada (não altera as notas; ver regra 3.4): o exemplo e a Q2 afirmam que uma vacina de proteínas gera T citotóxicos de memória que reconhecem peptídeos em MHC I. Nas fontes fornecidas, as proteínas extracelulares são apresentadas em MHC II. O material não descreve como proteínas externas levariam à memória CD8 (apresentação cruzada). A afirmação pode estar incompleta ou sem sustentação nas fontes.
- Pontos menores sem respaldo literal nas fontes: a "migração" das dendríticas para os linfonodos (a fonte fala em acúmulo); a definição de antígeno atribuída a [B02-F3].
- A avaliação baseia-se só no texto anonimizado. Não houve estudantes, e a contagem de palavras e a estrutura formal ficam a cargo de JT.

6. As notas descrevem atendimento à rubrica e qualidade didática estimada; não demonstram compreensão ou aprendizagem humana.