## 1. Identificação e certificado
Protocolo 3.2, com a regra 3.4 do contrato de saída aplicada. Código público: Q16acf16f42d142f7a8c5d4df796c4c0c. Tema: B01. Rodada: 1. Passagem: JP2.

Conferência do certificado:
- Versão 3.4, o que é compatível com a regra de avaliação cega.
- O código de destino é igual ao código público.
- Tema B01 e passagem JP2 conferem.
- A rodada aparece como "R01", o que equivale à rodada 1.
- Elegibilidade: "resposta completa; avaliação pedagógica cega".

Pela regra 3.4, esse certificado substitui a exigência de APTO. Não foi recebida nenhuma informação sobre autoria, notas ou dados operacionais. O pacote está em condições de avaliação.

## 2. Situação pedagógica
CONCLUÍDO.

## 3. Avaliação dos subcritérios
| Subcritério | Nota | Evidência | Justificativa |
|---|---|---|---|
| M1.1 | 50 | Parte atendida: "Conceitos necessários" define endotélio, subendotélio, plaquetas, zimogênios ("enzimas inativas"), trombina e fibrinólise. Tenase e protrombinase são apresentadas pela sua composição. Limitação: TFPI, tPA, PAI e TAFI aparecem sem que a sigla seja desdobrada ou a função explicada. PAI e TAFI só aparecem numa lista ("PAI, α2-antiplasmina e TAFI evitam…"). Também ficam sem explicação heparan sulfato, trombomodulina e pseudópodes. | A maioria dos termos é explicada, mas há ocorrências relevantes além do conhecimento prévio do leitor sem definição no primeiro uso. |
| M1.2 | 100 | As frases têm sujeito explícito, por exemplo: "A trombina que escapa do local e encontra endotélio íntegro liga-se à trombomodulina e ativa a proteína C, que, com a proteína S, inativa Va e VIIIa". Há um pequeno desvio de concordância em "localização e controle é o que separa", sem ambiguidade. | Os referentes são identificáveis e não há ambiguidade relevante. |
| M2.1 | 100 | Os componentes aparecem antes das relações. A sequência segue da lesão (1), para o tampão (2), a trombina e a fibrina (3), a estabilização (4), a regulação e a fibrinólise (5) e a distinção da trombose (6). As fases de iniciação, amplificação e propagação são encadeadas. | A progressão permite acompanhar cada etapa, e cada uma usa o que já foi apresentado. |
| M2.2 | 100 | A síntese tem três itens que integram exposição, estabilização e controle: "sem esses controles, a resposta protetora vira trombose". Os três itens só usam termos já apresentados. | Responde ao objetivo do pedido (por que estabilizar e por que controlar) sem introduzir pré-requisito novo. |
| M3.1 | 100 | Todas as seções tratam do recorte. A menção à hemofilia, na confusão 1, serve para justificar o modelo celular. As deficiências de antitrombina, proteína C e proteína S aparecem no ponto 6 para explicar o desequilíbrio. Não há enumeração completa de fatores nem de exames. | Cada trecho contribui para o recorte solicitado. |
| M3.2 | 100 | Os mecanismos reaparecem no exemplo e na resposta 2 (trombomodulina, antitrombina, prostaciclina), mas aplicados ao caso concreto das bordas da ferida. A síntese condensa o conteúdo sem copiá-lo. | As retomadas têm função de aplicar ou justificar; não há repetição sem função. |
| M4.1 | 100 | Alguns nexos causais explicitados: "É essa exposição de componentes normalmente isolados que dispara a resposta"; "como cada molécula de fibrinogênio conecta duas plaquetas, forma-se o tampão"; a retroalimentação positiva ("o produto amplifica sua própria formação"); e "A integração é bidirecional: as plaquetas fornecem a superfície… e a trombina… ativa mais plaquetas". | O texto explica por que as etapas se conectam, não apenas as enumera. |
| M4.2 | 100 | A regulação é ligada ao local: a trombina que chega ao endotélio íntegro ativa a proteína C, o heparan sulfato ativa a antitrombina e a prostaciclina contrabalança o TxA2. Quanto à fibrinólise, o texto diz que o plasminogênio ligado à fibrina é convertido em plasmina. A trombose é explicada por desequilíbrio (aumento da atividade pró-coagulante ou queda dos inibidores). Os inibidores da fibrinólise aparecem apenas listados, mas isso não compromete a conclusão. | Condições e limites são conectados à conclusão central: localização e controle distinguem proteção de dano. |
| M5.1 | 100 | "um corte superficial rompe uma arteríola da pele". | A situação é concreta e pertinente à pequena lesão pedida. |
| M5.2 | 100 | As etapas do exemplo são mapeadas aos conceitos (vWF–GpIb, ADP/TxA2, GpIIb/IIIa, TF–VIIa, XIIIa, proteína C e antitrombina nas bordas, tPA/plasmina). Interpretação: "um tampão só de plaquetas resistiria mal ao fluxo; a fibrina o transforma em vedação estável, e os inibidores garantem que ela fique só ali". Há um limite explícito, e a pergunta 2 aprofunda a aplicação. | Os elementos e o resultado do exemplo são explicados pela relação com os conceitos. As etapas estão condensadas, mas apoiadas no mecanismo já desenvolvido e na interpretação. |

## 4. Resumo das notas
| M1 | M2 | M3 | M4 | M5 | P |
|---|---|---|---|---|---|
| 75 | 100 | 100 | 100 | 100 | 95 |

Memória de cálculo:
- M1 = (50 + 100) / 2 = 75
- M2 = (100 + 100) / 2 = 100
- M3 = (100 + 100) / 2 = 100
- M4 = (100 + 100) / 2 = 100
- M5 = (100 + 100) / 2 = 100
- P = (75 + 100 + 100 + 100 + 100) / 5 = 95

## 5. Limitações e alertas
- **Siglas sem definição:** a principal limitação pedagógica é a presença de siglas e termos sem definição (TFPI, tPA, PAI, TAFI, heparan sulfato, trombomodulina).
- **Pontos para o juiz científico, sem efeito nas notas pedagógicas:**
  - As indicações de tempo do exemplo ("o sangramento diminui em minutos", "Dias depois, tPA e plasmina dissolvem a fibrina") não aparecem explicitamente nas notas fornecidas.
  - "de forma desproporcional", na definição de trombose, amplia o que diz a nota B01-F5.
- **Contagem de palavras e estrutura:** pertencem ao juiz tecnológico (JT) e não foram avaliadas aqui.

As notas descrevem atendimento à rubrica e qualidade didática estimada; não demonstram compreensão ou aprendizagem humana.