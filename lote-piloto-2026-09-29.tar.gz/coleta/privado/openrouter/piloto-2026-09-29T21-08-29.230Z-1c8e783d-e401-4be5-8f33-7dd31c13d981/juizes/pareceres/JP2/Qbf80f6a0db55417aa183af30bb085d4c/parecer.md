## 1. Identificação e conferência do certificado
- Rubrica aplicada: protocolo 3.2, com a regra do protocolo 3.4 para a elegibilidade.
- Código público: Qbf80f6a0db55417aa183af30bb085d4c. Tema: B02. Rodada: 1 (o certificado registra "R01"). Passagem: JP2.
- Certificado: versão 3.4, com código, tema, rodada e passagem compatíveis. Ele informa "Resposta completa; avaliação pedagógica cega, sem a decisão científica". Pela regra 3.4, esse certificado cego substitui a exigência de APTO, por isso não houve bloqueio.
- O pacote chegou limpo: não traz notas C, nome de modelo, tempos, custos nem autoria explícita. Há uma única resposta.

## 2. Situação pedagógica
CONCLUÍDO. Os 10 itens foram avaliados.

## 3. Tabela de subcritérios
Subcritério | Nota | Evidência | Justificativa
--- | --- | --- | ---
M1.1 | 50 | A seção "Conceitos necessários" define antígeno, anticorpo, receptor, plasmócito, APC, MHC I/II e célula de memória. A expansão clonal é definida no passo 4. Os termos "apoptose", "citocinas", "complemento", "CD8/CD4", "linfócitos virgens" e "afinidade" são usados sem definição. | Os termos centrais são explicados. Porém vários termos além do conhecimento prévio do graduando aparecem sem explicação no primeiro uso.
M1.2 | 50 | A maior parte das frases tem sujeito claro, como em "T citotóxicos CD8 reconhecem peptídeo em MHC de classe I e destroem...". A confusão 2 foi formulada de modo confuso: "Pensar que toda resposta com ajuda de T auxiliar é igual à morte direta pelo T auxiliar". A resposta 2 abre com a frase metatextual "Porque a aplicação é avaliar memória além do anticorpo circulante". | Há dois trechos com ambiguidade relevante, justamente em seções de revisão. O restante é claro.
M2.1 | 100 | Os conceitos vêm antes do mecanismo. Os passos 1 a 6 seguem a ordem do pedido: apresentação → B/anticorpos → T → expansão clonal → novo contato → vacinação. O exemplo reproduz essa sequência. | A progressão pode ser acompanhada. Há uma antecipação pequena: a ajuda do T auxiliar aparece no passo 2 e só é explicada no passo 3, o que não impede acompanhar as etapas.
M2.2 | 100 | A síntese tem três itens que ligam apresentação e funções B/T, depois expansão clonal e memória, e por fim vacinação e os limites da proteção. | A síntese integra o recorte e responde ao objetivo final, inclusive a tese de que memória não é proteção absoluta. Não introduz pré-requisito novo.
M3.1 | 100 | Todos os passos tratam dos seis pontos. A menção a barreiras, complemento e receptores de padrão no passo 1 é breve e serve para situar a imunidade inata. Citocinas específicas e plataformas não são detalhadas. | O conteúdo fica dentro do recorte e respeita as exclusões.
M3.2 | 100 | As retomadas no exemplo, nas confusões e nas respostas aplicam os conceitos. A frase "A marca da imunidade adaptativa é..." aparece nos passos 1 e 5, mas no passo 5 introduz o tema do novo contato. | Não há redundância predominante sem função. As retomadas servem à aplicação.
M4.1 | 50 | Há conexões causais: "Assim, a apresentação transforma um sinal inespecífico de perigo em ativação específica"; "A consequência é controle mais precoce"; a resposta 1 explica por que a concentração em linfonodos favorece o encontro do clone raro. Os passos 2 e 4, porém, são sequências de afirmações parafraseadas das fontes. Não explicam como o T auxiliar reconhece e ajuda o B, nem por que a maioria dos efetores morre. | Parte das relações causais está desenvolvida. Outra parte relevante fica em enumeração de fatos, pouco adequada ao estudo individual.
M4.2 | 100 | O passo 6 e o limite do exemplo ligam a conclusão às condições: anticorpos elevados não garantem proteção, velocidade de disseminação do patógeno, variação antigênica e idade/estado imune. A limitação dos anticorpos contra vírus já estabelecido também é citada. | Condições e limites pertinentes estão ligados à conclusão de que memória não é proteção absoluta.
M5.1 | 100 | "Imagine uma vacina hipotética contendo proteína inativada... Meses depois há contato com o agente correspondente vivo." | A situação é concreta, hipotética e pertinente, como o pedido exige.
M5.2 | 50 | O exemplo explicita a situação inicial, as etapas (APC, T auxiliar, B → plasmócito ou memória), o resultado interpretado (memória prolifera em dias, com maior afinidade) e o limite. As etapas, porém, estão comprimidas em lista. Além disso, a frase "T citotóxicos e auxiliares geram efetores" aparece numa vacina de proteína inativada sem explicar como ocorre a ativação CD8, embora o texto tenha ensinado que o MHC I apresenta peptídeos intracelulares. | Os resultados se relacionam aos conceitos, mas um elemento relevante do exemplo contradiz, sem explicação, o conceito ensinado, e algumas etapas não são justificadas.

## 4. Resumo
M1 | M2 | M3 | M4 | M5 | P
--- | --- | --- | --- | --- | ---
50 | 100 | 100 | 75 | 75 | 80

Memória de cálculo:
- M1 = (50 + 50) / 2 = 50
- M2 = (100 + 100) / 2 = 100
- M3 = (100 + 100) / 2 = 100
- M4 = (50 + 100) / 2 = 75
- M5 = (100 + 50) / 2 = 75
- P = (50 + 100 + 100 + 75 + 75) / 5 = 400 / 5 = 80

## 5. Limitações e alertas
- **Possíveis pontos para o juiz científico.** Pela regra 3.4, apenas registro estes pontos, sem alterar as notas:
  - (a) O exemplo atribui geração de T citotóxicos efetores a uma vacina de proteína inativada. Isso exigiria apresentação cruzada, que não é tratada nas fontes fornecidas.
  - (b) O primeiro item da síntese fala em "apresentação de antígeno pela inata às células T", uma formulação imprecisa.
  - (c) A confusão 1 afirma que os anticorpos podem cair sem que a memória celular desapareça. As fontes sustentam isso só parcialmente.
- **Limitações da avaliação.** A contagem de palavras e a presença formal das seções cabem a JT e não foram consideradas aqui. A avaliação foi feita por IA, sem estudantes.

As notas descrevem atendimento à rubrica e qualidade didática estimada; não demonstram compreensão ou aprendizagem humana.