## 1. Identificação e conferência do certificado
- Versões: rubrica 3.2 e regra de elegibilidade 3.4. Pelo contrato de saída, a 3.4 prevalece: o certificado de avaliação cega substitui a exigência de APTO.
- Código público: Q8b24e56de2fb47129a4d6d7543ffe631. O código do certificado é igual.
- Tema: B02. O certificado também indica B02.
- Rodada: 1. O certificado indica R01, que é compatível.
- Passagem: JP2. O certificado também indica JP2.
- Elegibilidade: resposta completa, com avaliação pedagógica cega.
- Certificado: compatível.
- Pacote: não contém notas C, nome de modelo, dados operacionais nem autoria explícita. Há uma única resposta.

## 2. Situação pedagógica
CONCLUÍDO.

## 3. Tabela de subcritérios
| Subcritério | Nota | Evidência | Justificativa |
|---|---|---|---|
| M1.1 | 50 | Definições no primeiro uso: "Antígeno é uma estrutura reconhecida especificamente…", "APC", "MHC", "peptídeos", "Citocinas", "Plasmócitos", "TCR", "apoptose", "expansão clonal" e "afinidade, isto é, maior força de ligação". Sem explicação: "identificados como CD4+" / "CD8+", "imunidade inata treinada" e "sinais adequados de ativação". | Atende na maioria dos termos. Porém CD4+/CD8+ aparecem só como rótulos, sem dizer que são moléculas de superfície. "Imunidade inata treinada" é apresentada apenas pelo contraste ("diferente da memória adaptativa convencional"). Isso está além do conhecimento prévio definido. |
| M1.2 | 100 | Frases curtas com sujeito explícito, como "O B reconhece diretamente o antígeno…" e "Os T citotóxicos… reconhecem peptídeos em MHC de classe I". | Os referentes podem ser identificados em todo o texto. Não encontrei ambiguidade relevante. |
| M2.1 | 100 | Ordem: "Conceitos necessários" (antígeno, APC, MHC, plasmócitos, efetoras/memória) antes do "Mecanismo"; depois, as etapas 1→6 (apresentação → B/anticorpos → T → expansão → reencontro → vacinação). | Os componentes são definidos antes das relações que dependem deles. As seis etapas seguem a ordem do processo e podem ser acompanhadas. |
| M2.2 | 100 | Síntese: "A imunidade inata favorece a apresentação; B e T reconhecem…"; "Expansão e diferenciação geram efetores, células de memória e plasmócitos…"; "A vacinação prepara respostas futuras, mas proteção depende…". | Os três itens reúnem reconhecimento, memória e vacinação/limites, que formam o objetivo do pedido. Não introduzem pré-requisito novo. |
| M3.1 | 50 | Trecho fora do eixo: "B02-F4 descreve a imunidade inata treinada…" e "a descrição de plasmócitos de vida curta em B02-F3 não deve ser generalizada a todos". | Quase todos os trechos servem ao recorte. Porém a digressão sobre imunidade inata treinada e o comentário sobre as fontes pouco ajudam o estudante a entender o mecanismo. Também acrescentam um conceito sem explicá-lo. |
| M3.2 | 100 | A distinção entre anticorpo e célula de memória aparece nas etapas 2 e 4, na confusão 1 e na síntese. | Cada retomada tem uma função: explicar, corrigir uma confusão ou sintetizar. Não há repetição sem função. |
| M4.1 | 50 | Relações explicadas: "reconhecer não basta; é necessário ampliar e especializar a população celular" (explica a demora) e "há mais linfócitos específicos preparados para responder… A resposta tende, assim, a ser mais rápida". Relações só afirmadas: "Isso favorece a ativação das APC" e "Reforços podem aproveitar células de memória". | Expansão clonal, cooperação B–T e resposta secundária têm justificativa causal. Porém a ligação entre imunidade inata e ativação das APC/linfócitos T ("sinais adequados") é afirmada sem mecanismo. O motivo pelo qual o reforço amplia a resposta também não é desenvolvido. |
| M4.2 | 100 | "Um patógeno de disseminação rápida pode avançar antes da produção de novos anticorpos; alterações antigênicas podem reduzir o reconhecimento. Idade e estado imune também influenciam. Impedir a infecção e limitar a doença são resultados distintos." | As condições e os limites são ligados à conclusão de que memória não é proteção absoluta. A confusão 2 e a pergunta 2 retomam esses limites. |
| M5.1 | 100 | "Considere uma pessoa sem exposição anterior a um vírus hipotético. Ela recebe uma vacina… Meses depois, ocorre contato com o vírus correspondente." | A situação é concreta, hipotética e pertinente: vacinação seguida de contato posterior, sem citar vacina comercial. |
| M5.2 | 100 | "APC apresentam peptídeos e ativam T específicos; B… recebem ajuda de T auxiliares… Plasmócitos de vida longa passam a sustentar parte dos anticorpos… Anticorpos presentes podem bloquear parte dos vírus; se algumas células forem infectadas, T citotóxicos… podem combatê-las" e "não permite calcular proteção individual nem garantir o mesmo resultado diante de variantes". | Cada etapa do exemplo é relacionada aos conceitos do mecanismo. O resultado é interpretado ("controle mais rápido… mesmo sem impedir toda infecção") e o limite da conclusão é explicitado. A pergunta 2 aplica o exemplo. |

## 4. Resumo
| M1 | M2 | M3 | M4 | M5 | P |
|---|---|---|---|---|---|
| 75 | 100 | 75 | 75 | 100 | 85 |

Memória de cálculo:
- M1 = (50 + 100) / 2 = 75
- M2 = (100 + 100) / 2 = 100
- M3 = (50 + 100) / 2 = 75
- M4 = (50 + 100) / 2 = 75
- M5 = (100 + 100) / 2 = 100
- P = (75 + 100 + 75 + 75 + 100) / 5 = 425 / 5 = 85

## 5. Limitações e alertas
- Não identifiquei possível erro científico que precise de alerta. A correção científica cabe a outro juiz.
- A frase "Plasmócitos de vida longa passam a sustentar parte dos anticorpos" é apresentada no exemplo como condição didática. Isso é compatível com a ressalva do próprio texto.
- As respostas comentadas são breves, mas explicitam o raciocínio. Não gerei nota extra por elas.
- Não apliquei penalidade por extensão; isso pertence a JT.
- Esta avaliação foi feita por IA, em uma única sessão, sem estudantes.

## 6. Encerramento
As notas descrevem atendimento à rubrica e qualidade didática estimada; não demonstram compreensão ou aprendizagem humana.