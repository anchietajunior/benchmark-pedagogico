## 1. Identificação e verificação do certificado
Rubrica: Protocolo 3.2 (10 subcritérios). A regra de elegibilidade segue a cláusula do Protocolo 3.4, que prevalece. Código público: Q869c428811a24ef09429ac665b90add5. Tema: B01. Rodada: 1. Passagem: JP2.
O certificado está compatível. A versão é 3.4, que corresponde à regra de avaliação cega. O código de destino é idêntico. O tema é B01. A rodada R01 equivale à rodada 1. A passagem é JP2. O certificado declara uma resposta completa avaliada às cegas. Pelo Protocolo 3.4, ele substitui a exigência de APTO. O pacote não traz notas C, identidade do autor nem dados operacionais. Há uma única resposta anonimizada.

## 2. Situação pedagógica
CONCLUÍDO.

## 3. Tabela
| Subcritério | Nota | Evidência | Justificativa |
|---|---|---|---|
| M1.1 | 50 | Termos definidos: endotélio, plaquetas, fator von Willebrand, fibrinogênio, fator tecidual, protrombina/trombina e vasoconstrição ("isto é, estreitamento do vaso"). Termos sem definição: "receptor GPIb", "receptores IIb/IIIa", "pseudópodes", "ADP", "fatores V e VIII, que servem como cofatores", "complexos tenase e protrombinase", "trombomodulina", "tPA", "plasminogênio". | **Atendido:** os componentes centrais têm definição no primeiro uso. **Limitação:** vários termos além do conhecimento prévio do graduando aparecem sem definição. Também não se explica o que são os fatores numerados nem o sufixo "a". |
| M1.2 | 100 | Na maior parte do texto, as frases têm sujeito explícito, por exemplo "A trombina então cliva o fibrinogênio..." e "O fator XIII ativado cria ligações covalentes...". | Os sujeitos e os referentes podem ser identificados. Há uma falha pontual: "Essa quantidade inicial de trombina" vem sem antecedente explícito. Isso é mais um salto do mecanismo (tratado em M4.1) do que uma ambiguidade relevante de referente. |
| M2.1 | 100 | "Conceitos necessários" vem antes do "Mecanismo passo a passo", que tem seis subtítulos numerados em ordem: lesão → plaquetas → coagulação → fibrina → regulação → trombose. | Os componentes são apresentados antes de suas relações. A adesão, a ativação e a agregação, assim como a iniciação, a amplificação e a propagação, seguem a ordem temporal. |
| M2.2 | 100 | A Síntese tem três itens que integram o ponto de partida comum, o tampão com a fibrina e o controle local em oposição à trombose. | A síntese responde ao objetivo: por que estabilizar o tampão e por que o controle importa. Não introduz pré-requisitos novos. |
| M3.1 | 100 | Todos os trechos tratam da lesão pequena, das plaquetas, da coagulação, da regulação, da fibrinólise ou da trombose. O limite do exemplo apenas delimita o que fica fora do recorte. | Não há desvio para enumeração completa de fatores nem para exames laboratoriais. |
| M3.2 | 100 | O exemplo e a resposta comentada 2 retomam o mecanismo para aplicá-lo ao corte. | As retomadas têm função de aplicação ou revisão. As marcações repetidas de citação não são redundância conceitual. |
| M4.1 | 50 | **Causalidade explícita:** "Sem plaquetas ativadas faltaria superfície e sinalização para gerar trombina...; sem fibrina, o agregado plaquetário se desfaria sob a pressão do fluxo". **Trecho mais rotulado:** "a iniciação ocorre quando fator tecidual liga fator VIIa e ativa os fatores IX e X. Essa quantidade inicial de trombina é pequena..." e "aceleram novas reações". | **Atendido:** os pontos 1, 2 e 4 explicam o porquê das conexões. **Limitação:** no ponto 3, os nomes das fases são apresentados com pouca explicação. Falta o elo Xa→trombina na iniciação, o mecanismo da amplificação fica vago ("novas reações") e a tenase não é explicada. |
| M4.2 | 100 | "O equilíbrio entre tromboxano A2... e prostaciclina... ajuda a manter a agregação localizada"; a via da proteína C "reduz a amplificação"; a fibrinólise "serve para limitar o tamanho do coágulo"; a trombose ocorre "em local, momento ou tamanho inadequados". | A regulação, os seus limites e a fibrinólise são ligados à conclusão sobre a localização e a distinção da trombose. |
| M5.1 | 100 | "Imagine um pequeno corte na pele que atinge um vaso de pequeno calibre", com situação inicial, etapas, resultado e limite. | É uma situação concreta, identificável e pertinente ao pedido. |
| M5.2 | 50 | **Relacionado aos conceitos:** "o sangramento cessa porque a vedação mecânica inicial foi transformada em uma rede estável". A resposta comentada 2 aplica bem a integração entre hemostasia primária e secundária. **Apenas rótulo:** "Reguladores vizinhos impedem que o processo avance pelo vaso". | **Atendido:** a vedação e a estabilização são explicadas pelos conceitos. **Limitação:** a limitação da resposta, que também é objetivo do pedido, aparece no exemplo só como rótulo, sem mostrar quais reguladores agem nem como. A fibrinólise está ausente do exemplo. |

## 4. Resumo
| M1 | M2 | M3 | M4 | M5 | P |
|---|---|---|---|---|---|
| 75 | 100 | 100 | 75 | 75 | 85 |

**Cálculo:**
- M1 = (50 + 100) / 2 = 75
- M2 = (100 + 100) / 2 = 100
- M3 = (100 + 100) / 2 = 100
- M4 = (50 + 100) / 2 = 75
- M5 = (100 + 50) / 2 = 75
- P = (75 + 100 + 100 + 75 + 75) / 5 = 425 / 5 = 85

## 5. Limitações e alertas
Não houve penalidade por extensão nem por formato, que são critérios de JT.

Possíveis pontos científicos, registrados para o juiz científico e sem efeito nas notas:
- (a) No ponto 1, o texto diz que a vasoconstrição "aproxima as bordas da lesão" e cita B01-F4. Nas notas de F4, porém, essa aproximação é atribuída à contração das plaquetas. Pode haver atribuição incorreta.
- (b) No exemplo, a frase "o vaso permanece parcialmente aberto ao redor" não parece sustentada pelas fontes fornecidas.
- (c) Na iniciação, falta o passo em que Xa gera trombina.

A avaliação foi feita por IA, em uma única sessão, sem estudantes.

## 6. Encerramento
As notas descrevem atendimento à rubrica e qualidade didática estimada; não demonstram compreensão ou aprendizagem humana.