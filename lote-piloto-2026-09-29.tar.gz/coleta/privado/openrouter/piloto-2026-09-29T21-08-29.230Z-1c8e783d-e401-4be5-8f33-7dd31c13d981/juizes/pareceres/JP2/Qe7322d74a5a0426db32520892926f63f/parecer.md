## 1. Identificação e conferência do certificado
Protocolo 3.2, com a regra de avaliação cega do 3.4 prevalecendo, conforme o contrato de saída. Código público: Qe7322d74a5a0426db32520892926f63f. Tema: B01. Rodada: 1. Passagem: JP2.
O certificado 3.4 registra o mesmo código, o tema B01, a rodada R01 (equivalente à rodada 1) e a passagem JP2. Ele indica "Resposta completa; avaliação pedagógica cega, sem a decisão científica". Por isso, o certificado foi considerado compatível. Pela regra 3.4, a ausência de APTO não gera BLOQUEADO.
O pacote não contém C1-C3, notas anteriores, identidade de modelo nem dados operacionais. A resposta não traz autoria explícita.

## 2. Situação pedagógica
CONCLUÍDO. Os 10 itens foram avaliados.

## 3. Tabela
Subcritério | Nota | Evidência | Justificativa
M1.1 | 50 | Termos definidos: hemostasia (com etimologia), endotélio, subendotélio, "trombogênico, ou seja, favorece a formação de coágulo", zimogênios, fator tecidual, trombina/fibrina, TFPI ("inibidor da via do fator tecidual"). | A maior parte dos termos novos foi definida ou teve sua função explicada no primeiro uso. **Limitação:** alguns termos aparecem sem definição nem expansão da sigla: "endotelina", "megacariócitos", "tPA" ("Ativadores como o tPA"), "TAFI", "cofatores V e VIII" e "trombomodulina". O graduando definido provavelmente não domina esses termos.
M1.2 | 100 | Frases curtas com sujeitos explícitos, por exemplo "O vWF funciona como ponte entre o colágeno exposto e o receptor GPIb" e "a mesma trombina que coagula na lesão ajuda a frear a coagulação sobre o endotélio sadio". | Os referentes são identificáveis e não há ambiguidade relevante. Sobre a frase do TFPI, ver o alerta na seção 5.
M2.1 | 100 | Ordem das seções: "Conceitos necessários" apresenta os componentes antes do mecanismo. Os passos 1 a 6 vêm numerados, com conexões explícitas, como "É por essa superfície que o ponto 2 se conecta ao ponto 3". | Os componentes aparecem antes das relações. As etapas seguem a sequência lesão, tampão, trombina/fibrina, estabilização, regulação/fibrinólise e trombose, e podem ser acompanhadas.
M2.2 | 100 | Os três itens da Síntese tratam da exposição de componentes, do tampão temporário estabilizado pela fibrina e dos freios/fibrinólise ligados à trombose. | A Síntese integra as ideias e responde aos dois objetivos do pedido: por que estabilizar o tampão e por que a coagulação sem controle é um problema. Não introduz pré-requisito novo.
M3.1 | 100 | Todas as seções tratam do recorte. A lista de fatores e os exames laboratoriais foram omitidos, conforme a exclusão do pedido. | Não há digressões. A etimologia é breve e ajuda a definir o termo.
M3.2 | 100 | O exemplo e a pergunta 2 retomam o mecanismo para aplicá-lo ao corte. A confusão 1 retoma a integração das fases para justificar a distinção. | Essas retomadas cumprem função de aplicação ou justificativa. Não há repetição sem função.
M4.1 | 100 | Trechos como "A resposta começa, portanto, porque componentes antes separados entram em contato", "Como o fibrinogênio se liga a receptores de plaquetas vizinhas, ele as conecta", "A lógica é de multiplicação... mas apenas onde existe superfície adequada" e "As plaquetas fornecem a superfície para gerar trombina, e a trombina ativa mais plaquetas". | O texto explica por que cada etapa leva à seguinte e produz o resultado. Não se limita a listar processos.
M4.2 | 100 | A regulação aparece ligada à localização: "O equilíbrio entre prostaciclina e tromboxano A2 restringe a agregação ao ponto lesionado". Também há a dupla função da trombina via trombomodulina, a regulação da fibrinólise (α2-antiplasmina, TAFI) e a trombose como desequilíbrio: "a atividade pró-coagulante aumenta ou os inibidores naturais diminuem". | Condições e limites são conectados à conclusão sobre resposta localizada e temporária e ao risco de trombose. O tema reaparece na pergunta 1, com a ressalva "aumento de risco, não de certeza".
M5.1 | 100 | "Situação inicial: um pequeno corte na pele rompe vasos de pequeno calibre". | A situação é concreta e pertinente ao pedido, que menciona uma pequena lesão vascular.
M5.2 | 100 | Etapas ligadas aos conceitos: "O colágeno exposto, via vWF, prende plaquetas", "O fator tecidual exposto inicia a geração de trombina sobre essas plaquetas". Resultado interpretado: "cessa apenas no ponto lesionado porque os freios atuam onde o endotélio está preservado". Limite declarado. A pergunta 2 aplica uma variação ao mesmo corte. | Os elementos e o resultado são explicados por relação causal com o mecanismo, e o limite da conclusão é declarado.

## 4. Resumo
M1 = (50 + 100) / 2 = 75
M2 = (100 + 100) / 2 = 100
M3 = (100 + 100) / 2 = 100
M4 = (100 + 100) / 2 = 100
M5 = (100 + 100) / 2 = 100
P = (75 + 100 + 100 + 100 + 100) / 5 = 475 / 5 = 95

## 5. Limitações e alertas
- **Possível imprecisão científica, para o juiz científico:** no passo 3 está escrito "O Xa gera uma pequena quantidade de trombina, que o inibidor da via do fator tecidual (TFPI) consegue bloquear". Pela redação, o TFPI parece bloquear a trombina. B01-F3 diz que a geração de trombina nessa fase pode ser interrompida pelo TFPI, e B01-F2 diz que o TFPI restringe o Xa e o complexo fator tecidual/VIIa. O passo 5 descreve o TFPI corretamente. Pela regra 3.4, as notas foram concluídas normalmente.
- **Afirmação sem sustentação direta nas fontes:** a frase "Cada enzima ativa muitas moléculas da etapa seguinte" é uma generalização. Cabe ao juiz científico verificá-la.
- **Sem penalidade por extensão:** a extensão e a estrutura formal pertencem ao juiz tecnológico e não geraram penalidade aqui.
- **Escopo do julgamento:** julgamento de um único avaliador de IA, sem estudantes.

As notas descrevem atendimento à rubrica e qualidade didática estimada; não demonstram compreensão ou aprendizagem humana.