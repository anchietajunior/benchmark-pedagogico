## 1. Identificação e certificado
- Protocolo: 3.2 | Código: Q2c45ad304ba44733b255606c8cbec688 | Tema: B02 | Rodada: 1 | Passagem: JP2.
- Certificado conferido: versão 3.2; o código de destino confere; tema B02; rodada R01, compatível com a rodada 1; passagem de origem JC2, correta para JP2; situação APTO. O certificado é compatível.
- O pacote não traz notas C, pareceres científicos, identidade de modelo nem dados operacionais. Há uma única resposta, sem autoria explícita.
- Não identifiquei trecho que justifique pedir revisão científica.

## 2. Situação pedagógica
CONCLUÍDO

## 3. Avaliação por subcritério
| Subcritério | Nota | Evidência | Justificativa |
|---|---|---|---|
| M1.1 | 100 | Termos definidos no primeiro uso: antígeno, linfócitos virgens, APC, MHC, peptídeos, citocinas, plasmócitos, anticorpos, células efetoras e de memória, TCR, apoptose, complemento, expansão clonal, afinidade e imunização ativa. CD4+ e CD8+ aparecem como “identificados como”. | Os termos novos do recorte são explicados no primeiro uso. As siglas CD4+ e CD8+ servem só como rótulos de identificação e não sustentam o raciocínio. O texto dá o sentido mínimo de “imunidade inata treinada” (a imunidade inata também pode se modificar). |
| M1.2 | 100 | “O B reconhece diretamente o antígeno…”; “Assim, anticorpos podem atuar sobre vírus fora das células, enquanto T citotóxicos ajudam a eliminar células já infectadas.” | Sujeitos e referentes são identificáveis. A frase “reconhecer o alvo orienta mecanismos de combate, mas não significa destruí-lo sozinho” fica um pouco elíptica, mas o contexto (anticorpos) resolve a dúvida. |
| M2.1 | 100 | “Conceitos necessários” vem antes das etapas 1 a 6: detecção e apresentação, depois B/anticorpos, T auxiliares/citotóxicos, expansão, reencontro e vacinação. | Os componentes aparecem antes das relações que dependem deles, e as etapas seguem a ordem causal do mecanismo. |
| M2.2 | 50 | Síntese: “A imunidade inata favorece a apresentação; B e T reconhecem antígenos de maneiras diferentes”; “Expansão e diferenciação geram efetores, células de memória e plasmócitos…”; “proteção depende da interação entre defesa, agente e organismo”. | **Parte atendida:** a síntese integra o encadeamento e o limite da proteção, sem introduzir pré-requisito novo. **Limitação:** não explicita a distinção entre anticorpos (proteínas) e células de memória, que é um objetivo final declarado. Também não retoma a diferença funcional entre T auxiliares e citotóxicos. |
| M3.1 | 50 | “Isso não exige afirmar que a imunidade inata nunca se modifica: B02-F4 descreve a imunidade inata treinada…”; “a descrição de plasmócitos de vida curta em B02-F3 não deve ser generalizada a todos: B02-F4 distingue…”. | **Parte atendida:** quase todo o texto serve ao recorte. **Limitação:** o parágrafo sobre imunidade treinada foge do objetivo (memória adaptativa). A discussão sobre divergências entre fontes se dirige à conferência das fontes, e não ao estudante; só o conteúdo sobre plasmócitos de vida longa tem função didática. |
| M3.2 | 100 | O exemplo retoma APC, B, expansão e plasmócitos de vida longa para aplicá-los; as confusões e a pergunta 2 retomam os limites da proteção para justificar respostas. | As retomadas têm função de aplicação ou de justificativa. Não observei repetição sem função. |
| M4.1 | 50 | “Isso explica parte da demora da resposta inicial: reconhecer não basta; é necessário ampliar e especializar a população celular”; “há mais linfócitos específicos preparados… A resposta tende, assim, a ser mais rápida”; em contraste: “Isso favorece a ativação das APC”; “Reforços podem aproveitar células de memória já formadas para ampliar a resposta.” | **Parte atendida:** há relações causais explícitas entre expansão clonal e latência, entre número de células preparadas e anticorpos presentes e a rapidez da resposta secundária, e entre anticorpos extracelulares e T citotóxicos intracelulares. **Limitação:** duas ligações relevantes ficam apenas afirmadas. O texto não explica como a resposta inata promove a ativação das APC, nem por que o reforço amplia a resposta (mecanismo das células B de memória). Isso limita o estudo individual dessas etapas. |
| M4.2 | 100 | “proteção depende da quantidade, função e localização dos anticorpos… Um patógeno de disseminação rápida pode avançar antes da produção de novos anticorpos; alterações antigênicas podem reduzir o reconhecimento. Idade e estado imune também influenciam. Impedir a infecção e limitar a doença são resultados distintos.” | As condições e os limites (velocidade do agente, variação antigênica, idade, localização dos anticorpos) são ligados à conclusão de que memória não significa proteção absoluta. A confusão 2 e a pergunta 2 retomam essa ligação. |
| M5.1 | 100 | “Considere uma pessoa sem exposição anterior a um vírus hipotético. Ela recebe uma vacina… Meses depois, ocorre contato com o vírus correspondente.” | Há uma situação concreta, hipotética e pertinente: vacinação seguida de contato, como o pedido exige. |
| M5.2 | 100 | “APC apresentam peptídeos e ativam T específicos; B… recebem ajuda de T auxiliares… Plasmócitos de vida longa passam a sustentar parte dos anticorpos”; “Anticorpos presentes podem bloquear parte dos vírus; se algumas células forem infectadas, T citotóxicos… podem combatê-las”; “não permite calcular proteção individual nem garantir o mesmo resultado diante de variantes”. | Cada elemento e o resultado (controle mais rápido sem necessariamente impedir a infecção) são explicados pelos conceitos apresentados antes. O limite da conclusão está explícito, e a pergunta 2 aplica o exemplo com raciocínio comentado. |

## 4. Resumo
| M1 | M2 | M3 | M4 | M5 | P |
|---|---|---|---|---|---|
| 100 | 75 | 75 | 75 | 100 | 85 |

Memória de cálculo:
- M1 = (100+100)/2 = 100
- M2 = (100+50)/2 = 75
- M3 = (50+100)/2 = 75
- M4 = (50+100)/2 = 75
- M5 = (100+100)/2 = 100
- P = (100+75+75+75+100)/5 = 425/5 = 85

## 5. Limitações e alertas
- A avaliação é feita por IA, sem estudantes e sem validação psicométrica da rubrica.
- Não apliquei penalidade por extensão ou estrutura, que são da competência de JT.
- Não há alerta científico. Não houve ranking nem comparação com outras respostas.

As notas descrevem atendimento à rubrica e qualidade didática estimada; não demonstram compreensão ou aprendizagem humana.