## 1. Identificação e conferência do certificado
Versão da rubrica: 3.2, com a regra do protocolo 3.4 prevalecendo na elegibilidade. Código público: Q270a21cceae040f09e47e9a9e7cb447f. Tema: B02. Rodada: 1. Passagem: JP2.

O certificado indica a versão 3.4, com o mesmo código de destino, tema B02, rodada R01 (equivalente a 1) e passagem JP2. Ele declara avaliação pedagógica cega, sem a decisão científica. Pelo protocolo 3.4, esse certificado substitui a exigência de APTO, e todos os dados são compatíveis. O pacote não traz notas C, pareceres científicos, autoria nem dados operacionais. Há uma única resposta.

## 2. Situação pedagógica
CONCLUÍDO

## 3. Tabela dos 10 subcritérios
| Subcritério | Nota | Evidência | Justificativa |
|---|---|---|---|
| M1.1 | 50 | Estes termos são definidos: antígeno, APC, MHC, plasmócito, anticorpo, TCR, apoptose, opsonização, neutralização e imunossenescência. Estes são usados sem definição: "citocinas", "sistema complemento", "linfócitos virgens", "antígeno cognato", "CD4+/CD8+", "BCR" (a sigla não é expandida), "epítopos", "centros germinativos", "troca de classe" e "involução tímica". | O glossário inicial cobre a maior parte dos componentes. Porém, vários termos além do conhecimento prévio do graduando aparecem sem explicação no primeiro uso, e "citocinas" é central para a função do T auxiliar. |
| M1.2 | 100 | Exemplos de frases com sujeito explícito: "Os linfócitos B ligam-se a antígenos intactos…"; "Linfócitos T auxiliares (CD4+) não possuem maquinário citotóxico…". | Em geral, sujeitos e referentes são identificáveis. A vaga "preservam a identidade do antígeno" é imprecisa, mas não cria ambiguidade de referente que atrapalhe a leitura. |
| M2.1 | 100 | Ordem: Conceitos → 1. apresentação → 2. B/plasmócitos/anticorpos → 3. T auxiliar/citotóxico → 4. expansão clonal → 5. resposta secundária → 6. vacinação. | Os componentes são apresentados antes das relações, e as etapas podem ser acompanhadas. A pequena inversão (o auxílio do T aparece no passo 2, e a função do T auxiliar só no passo 3) não impede a leitura, pois o linfócito T já foi definido nos Conceitos. |
| M2.2 | 100 | A Síntese tem três itens: reconhecimento, expansão clonal com separação entre efetoras e memória, e vacinação com seus limites. | Os itens integram o percurso e respondem ao objetivo sem trazer pré-requisitos novos. A cinética de disseminação já aparece no passo 6. |
| M3.1 | 100 | Todas as seções tratam de reconhecimento, linfócitos B e T, memória e vacinação. As subclasses de anticorpos e as plataformas vacinais foram evitadas. | O texto respeita o recorte e as exclusões. A primeira frase da Ideia central é genérica, mas contextualiza o tema. |
| M3.2 | 100 | Ideias retomadas na Confusão 1, na Q1 e na Síntese. | As retomadas servem para distinguir conceitos, justificar respostas ou sintetizar. Não há repetição sem função; as citações frequentes são marcação de fonte, não redundância. |
| M4.1 | 100 | Passo 1: "migra… até os linfonodos…, permitindo o encontro físico". Passo 5: "estão em maior número e possuem limiar de ativação inferior… O tempo de latência diminui". Q1: explica a cadeia MHC II → T CD4+ → auxílio ao B. | As etapas são ligadas por causa e consequência (por que a memória acelera a resposta, por que o T auxiliar condiciona a resposta humoral), e não apenas listadas. A frase vaga "com estímulo adequado" no passo 2 é compensada pela Q1. |
| M4.2 | 50 | Parte atendida: o passo 6 relaciona mutação antigênica, disseminação rápida versus proliferação da memória B e imunossenescência à conclusão de que "proteção vacinal não é absoluta", e a Q2 aprofunda a questão da idade. Limitação: no limite do exemplo, "A presença de células de memória garante rapidez de resposta". | Os limites estão ligados à conclusão. Porém, a afirmação "garante" contradiz as condições descritas (por exemplo, a idade) exatamente no ponto em que o exemplo delimita sua conclusão. Também falta dizer que títulos de anticorpos não asseguram proteção por si. |
| M5.1 | 100 | "Um indivíduo jovem e saudável recebe uma vacina hipotética… Meses depois, o indivíduo é exposto à bactéria selvagem." | A situação é concreta, hipotética e corresponde ao pedido: vacinação seguida de contato posterior. |
| M5.2 | 50 | Parte atendida: as etapas 1 a 4 retomam APC, MHC II, T CD4+, expansão clonal, IgM→IgG e memória B e plasmócitos de vida longa. Limitação: o "Resultado interpretado" apenas afirma que a resposta "bloqueou a disseminação". | As etapas estão ligadas aos conceitos, mas o resultado não é explicado pela diferença entre as respostas primária e secundária (número de células, limiar, anticorpos pré-existentes). O texto também não justifica por que uma bactéria extracelular direciona para MHC II e resposta humoral, nem comenta a memória T no caso. |

## 4. Resumo
| M1 | M2 | M3 | M4 | M5 | P |
|---|---|---|---|---|---|
| 75 | 100 | 100 | 75 | 75 | 85 |

Memória de cálculo:
- M1 = (50 + 100) / 2 = 75
- M2 = (100 + 100) / 2 = 100
- M3 = (100 + 100) / 2 = 100
- M4 = (100 + 50) / 2 = 75
- M5 = (100 + 50) / 2 = 75
- P = (75 + 100 + 100 + 75 + 75) / 5 = 425 / 5 = 85

## 5. Limitações e alertas
Possíveis pontos científicos para o juiz científico, que não alteram as notas acima:
- (a) A definição de antígeno como "qualquer estrutura molecular estranha" é uma simplificação.
- (b) A frase "adjuvantes para recrutar a imunidade inata" atribui ao adjuvante um mecanismo que as fontes não detalham; elas dizem apenas que o adjuvante melhora a resposta.
- (c) Na Q1, "troca de classe (de IgM para IgG de maior afinidade)" mistura troca de isotipo com maturação de afinidade.
- (d) A frase "garante rapidez de resposta" é uma generalização mais forte que as fontes (F4 sobre idosos).
- (e) A frase "neutralizar o patógeno frequentemente antes do início de manifestações clínicas" não tem apoio explícito no material.

A contagem de palavras e a estrutura formal cabem ao juiz tecnológico e não foram consideradas. Não há ranking nem identificação de autoria.

## 6. Encerramento
As notas descrevem atendimento à rubrica e qualidade didática estimada; não demonstram compreensão ou aprendizagem humana.