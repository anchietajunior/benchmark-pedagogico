## Parecer do juiz pedagógico JP2: protocolo 3.2, com a regra de elegibilidade 3.4

### 1. Identificação e conferência do certificado
- **Versões:** avaliação feita pelas rubricas da versão 3.2. A elegibilidade segue a regra da versão 3.4, que prevalece: o certificado de avaliação cega substitui a exigência de APTO.
- **Código público:** Qfbac42b7cd3c42cfa1e6bb38edf4046d.
- **Tema, rodada e passagem:** B02, rodada 1, passagem JP2.
- **Certificado conferido:**
  - versão 3.4;
  - código de destino idêntico ao desta avaliação;
  - tema B02;
  - rodada R01, compatível com a rodada 1;
  - passagem JP2;
  - elegibilidade: "resposta completa; avaliação pedagógica cega".
- **Resultado:** o certificado é compatível. O pacote não traz notas C, pareceres científicos, nome de modelo, tempos, custos nem declaração de autoria.

### 2. Situação pedagógica
**CONCLUÍDO.**

### 3. Tabela de subcritérios

| Subcritério | Nota | Evidência | Justificativa |
|---|---|---|---|
| M1.1 | 50 | Antígeno, imunidade inata e adaptativa, APC, TCR, BCR, plasmócitos e células de memória estão definidos em "Conceitos necessários". Ficam sem explicação: "citocinas", "complemento", "opsonização", "isotipo", "afinidade", "apoptose", "CD4+/CD8+" e a sigla "ADE". A sigla MHC não é expandida. | Os termos centrais são definidos. Vários termos técnicos que vão além do conhecimento prévio do leitor definido aparecem sem explicação no primeiro uso. |
| M1.2 | 100 | Frases como "Assim, CD4+ organiza a resposta; CD8+ executa a destruição de células-alvo" têm sujeitos e referentes claros. | Não há ambiguidade relevante de referente. Os deslizes lexicais "curto-lived" e "microbe" não tornam os sujeitos ou referentes ambíguos. |
| M2.1 | 100 | A ordem é: conceitos (antígeno, APC, MHC, TCR/BCR); depois os passos 1 a 6 (apresentação → B/anticorpos → T auxiliares e citotóxicos → expansão clonal → reexposição → vacinação); depois o exemplo. | Os componentes são apresentados antes das relações. A menção antecipada a T auxiliares no passo 2 já estava coberta pela definição de CD4+ em "Conceitos necessários". |
| M2.2 | 100 | Os três itens da síntese tratam de: reconhecimento com efetoras e memória; papéis de B, CD4+ e CD8+ e das células de memória; e vacina com proteção relativa. | A síntese integra os eixos do objetivo (B/T, anticorpo × memória, vacinação e limites) e não introduz pré-requisito novo. |
| M3.1 | 100 | Todas as seções tratam do recorte. Citocinas, subclasses e plataformas vacinais não são detalhadas. ADE aparece apenas como limite da proteção. | Cada trecho serve ao pedido. As exclusões do tema foram respeitadas. |
| M3.2 | 100 | Os limites da proteção reaparecem no passo 6, no exemplo, na confusão 2, na pergunta 2 e na síntese. | Essas retomadas têm função: aplicam o conceito no exemplo, distinguem a confusão e justificam a resposta. A confusão 2 fica próxima do passo 6, mas cumpre a função exigida pela seção. |
| M4.1 | 50 | **Atendido:** "sem apresentação, os linfócitos T específicos dificilmente encontram o antígeno" e "a etapa de encontro, seleção e expansão clonal é encurtada". **Limitação:** "Ativado, ele prolifera e se diferencia..."; "mobiliza inata, APC, MHC, T e B". | Há conexões causais na apresentação e na resposta secundária. Várias etapas, porém, são enumeradas sem explicação: como o B é ativado e se diferencia, por que a maioria das efetoras morre e poucas persistem, e como a vacina desencadeia a cadeia. |
| M4.2 | 50 | **Atendido:** "contra disseminação rápida, conta sobretudo o anticorpo já presente; contra disseminação lenta, células B de memória têm tempo de proliferar", ligado a "não é proteção absoluta". **Limitação:** "Patógenos variáveis podem escapar da memória, e idade, estado imune e comorbidades alteram a resposta". | A condição da velocidade de disseminação é ligada à conclusão com justificativa. As condições de variabilidade do patógeno e de idade aparecem só como rótulos, sem explicar por que reduzem a proteção. |
| M5.1 | 100 | Vacina hipotética contra o "agente Y", em pessoa sem contato prévio, seguida de contato meses depois. | A situação é concreta, identificável e corresponde ao que o pedido exige. |
| M5.2 | 50 | **Atendido:** "Se houver anticorpos suficientes, eles podem neutralizar o agente logo no início. Se o agente ultrapassar essa barreira, células B e T de memória proliferam". **Limitação:** a primeira fase do exemplo resume as etapas em lista. O resultado "mais rápida e intensa" não é justificado dentro do exemplo, e o limite "se a dose for muito alta" não é explicado. | O exemplo liga anticorpos e memória aos momentos da reexposição. Nem todos os elementos e resultados, porém, são explicados pela relação com os conceitos. |

### 4. Resumo

| M1 | M2 | M3 | M4 | M5 | P |
|---|---|---|---|---|---|
| 75 | 100 | 100 | 50 | 75 | 80 |

**Memória de cálculo:**
- M1 = (50 + 100) / 2 = 75
- M2 = (100 + 100) / 2 = 100
- M3 = (100 + 100) / 2 = 100
- M4 = (50 + 50) / 2 = 50
- M5 = (100 + 50) / 2 = 75
- P = (75 + 100 + 100 + 50 + 75) / 5 = 400 / 5 = 80

### 5. Limitações e alertas
- **Possíveis pontos científicos, apenas registrados.** Pela regra 3.4, a correção científica cabe a outro juiz e as notas foram concluídas normalmente.
  - (a) No limite do exemplo, a condição "se a dose for muito alta" não aparece no material fornecido.
  - (b) A frase "reduzir a chance de doença grave" especifica mais do que as fontes, que falam em proteção contra o desenvolvimento da doença.
  - (c) A frase "muitos plasmócitos são relativamente curto-lived" mistura inglês e português.
  - Não houve verificação científica por este papel.
- **Extensão e formato:** não foram avaliados. Pertencem a JT.
- **Natureza da avaliação:** única avaliação de um juiz em IA, sem estudantes, sem ranking e sem alterar outros pareceres.

### 6. Encerramento
As notas descrevem atendimento à rubrica e qualidade didática estimada; não demonstram compreensão ou aprendizagem humana.