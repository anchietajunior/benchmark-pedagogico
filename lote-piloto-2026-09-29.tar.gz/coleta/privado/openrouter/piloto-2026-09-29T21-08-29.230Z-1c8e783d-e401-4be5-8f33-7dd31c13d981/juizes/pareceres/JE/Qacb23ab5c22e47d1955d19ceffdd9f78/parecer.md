## 1. Identificação
Protocolo 3.2 | Execução E07644098396951605804 | Código Qacb23ab5c22e47d1955d19ceffdd9f78 | Tema B01 | Rodada 1 | Papel JE.
Modo de entrega: coleta instrumentada OpenRouter (api-openrouter-v1). Os dados vêm dos registros do coletor.
Situação operacional validada por JT: INICIADA = sim; STATUS_OPERACIONAL = conclusão normal; RAMO_SAIDA = explicação. Não há conflito entre os registros recebidos.
Tentativas: uma chamada de geração, sem reenvio automático, ferramentas ou chamadas internas adicionais registradas.

## 2. Medidas brutas
| Medida | Valor bruto | Unidade | Origem | Medido/estimado/indisponível | Observação |
|---|---|---|---|---|---|
| Latência total | 25,04 (25.042791433) | s | Coletor: do envio HTTP ao fim do stream | Medido | Uma única tentativa. Não houve ferramentas nem reenvios. O registro fornece a duração, mas não horários absolutos nem fuso; o intervalo não depende deles. |
| Primeiro fragmento textual | 8,41 (8.4132071) | s | Coletor: first_text_seconds | Medido | Mede o primeiro fragmento de texto, não TTFT por token. |
| Tempo até falha | — | s | — | Não aplicável | A execução teve conclusão normal. |
| Tokens de entrada (prompt) | 14.194 | tokens | usage/native_tokens_* | Registrado (telemetria PENDENTE) | — |
| Tokens de saída (completion) | 5.332 | tokens | usage/native_tokens_* | Registrado (telemetria PENDENTE) | Inclui raciocínio. |
| Tokens totais | 19.526 | tokens | usage | Registrado | 14.194 + 5.332 = 19.526, sem inconsistência. |
| Tokens em cache | 0 | tokens | usage | Registrado | É um subconjunto da entrada. |
| Tokens de raciocínio | 1.732 | tokens | usage | Registrado | É um subconjunto da saída. |
| Custo de geração (USD) | null | USD | /generation | Indisponível | cost_source é nulo. |
| Custo de geração (BRL) | null | BRL | — | Indisponível | Não há valor em USD para converter. |

## 3. Tokens e sobreposições
Os campos do provedor foram preservados: prompt 14.194, completion 5.332, total 19.526, cached 0 e reasoning 1.732.
- O cache é detalhamento da entrada. O raciocínio é detalhamento da saída. Nenhum deles foi somado de novo ao total.
- A saída visível pode ser estimada em 5.332 − 1.732 = 3.600 tokens, se reasoning for mesmo subconjunto de completion. Isso é inferência sobre a estrutura dos campos, não medida publicada.
- A fonte dos tokens é usage, complementado por native_tokens_* quando disponível. Como telemetry_status = PENDENTE, esses valores ainda não são medidas completas conciliadas.

## 4. Memória de cálculo do custo
- Tarifa de cobrança observada: indisponível, porque cost_usd é nulo.
- Estimativa por tabela de preços: não foi fornecida e não é inventada aqui.
- Câmbio documentado: 5,2204 BRL/USD, PTAX venda BCB (Olinda CotacaoDolarPeriodo) de 2026-09-29, 13:06. Sem valor em USD, a conversão não pode ser aplicada.
- Ferramentas: nenhuma registrada, logo não há taxas distintas.
- Tentativas: 1 de 1. A cobertura de custo é 0 de 1 tentativa com custo conhecido.
- Custo total de geração: N/A. Não há subtotal publicável.
- Custos de avaliação (JC/JP/JT/JE) ficam fora do custo de geração.
Resultado: ORIGEM_CUSTO = indisponível.

## 5. Notas E
| E1 | E2 | E3 | Versão das metas | Motivos de N/A |
|---|---|---|---|---|
| N/A | N/A | N/A | N/A (não há metas definidas neste lote) | E1 e E2 não têm latencia_alvo_s/limite_s nem primeiro_texto_alvo_s/limite_s pré-fixados. E3 não tem metas de custo e o custo bruto é desconhecido. |
Fórmula prevista, não aplicada: nota(x) = 100 se x ≤ alvo; 0 se x ≥ limite; 100 × (limite − x)/(limite − alvo) nos demais casos. As medidas brutas conhecidas de latência e primeiro texto seguem publicadas. Não há média de eficiência.

## 6. Pendências
1. Conciliar o custo em USD via /generation ou registrar cobrança observada. Uma estimativa por tabela de preços também serve, desde que datada e identificada.
2. Resolver telemetry_status = PENDENTE para que tokens e custo possam ser tratados como completos.
3. Definir e versionar metas E1-E3 antes da coleta definitiva, se as notas normalizadas forem desejadas.