## 1. Identificação
Protocolo 3.2 | Código público Qa8b54e9a4dbc46b1ad688417d52139aa | Execução E25922611554175891518 | Tema B01 | Rodada 1 | Papel JE.
Situação operacional conferida por JT: INICIADA = sim; STATUS_OPERACIONAL = conclusão normal; RAMO_SAIDA = explicação (origem: JT validado).
Tentativas: uma chamada de geração, sem reenvio automático. Condição: coletor instrumentado OpenRouter; a duração vai do envio HTTP ao fim do stream. Não houve conflito entre os registros de situação.

## 2. Medidas brutas
| Medida | Valor bruto | Unidade | Origem | Medido/estimado/indisponível | Observação |
|---|---|---|---|---|---|
| Latência total | 69,83 (69,825925977) | s | coletor: envio HTTP até fim do stream | Medido | Tentativa única; conclusão normal |
| Primeiro fragmento textual | 15,65 (15,647067389) | s | coletor: first_text_seconds | Medido | Fragmento de texto, não TTFT de token |
| Tempo até falha | — | s | — | Não aplicável | Sem falha |
| Tokens de entrada | 21.143 | tokens | usage/native_tokens_* | Registrado (telemetria PENDENTE) | |
| Tokens de saída | 5.235 | tokens | usage/native_tokens_* | Registrado (telemetria PENDENTE) | Inclui raciocínio |
| Tokens totais | 26.378 | tokens | usage | Registrado | = 21.143 + 5.235 |
| Tokens em cache | 0 | tokens | usage | Registrado | Subconjunto da entrada |
| Tokens de raciocínio | 807 | tokens | usage | Registrado | Subconjunto da saída |
| Custo em USD | N/A | USD | /generation | Indisponível | cost_usd nulo |
| Custo em BRL | N/A | BRL | — | Indisponível | Não há USD para converter |

## 3. Tokens e sobreposições
Campos preservados: prompt_tokens = 21143; completion_tokens = 5235; total_tokens = 26378; cached_tokens = 0; reasoning_tokens = 807. A conta 21143 + 5235 = 26378 bate com o total informado. Os 807 tokens de raciocínio estão dentro de completion_tokens. Os tokens em cache, que aqui somam 0, estão dentro de prompt_tokens. Nenhum dos dois foi somado de novo. A saída faturada, de 5.235 tokens, inclui raciocínio oculto e não corresponde apenas ao texto visível. Origem dos tokens: usage, com campos faltantes completados por native_tokens_* quando disponíveis. Como telemetry_status = PENDENTE, esses valores são registros publicados, mas não uma medida completa conciliada.

## 4. Memória de cálculo do custo
- Chamadas de geração: 1. Reenvios: 0. Não há taxas de ferramentas registradas, pois a condição openrouter-v1 não usa ferramentas.
- Custo observado em USD: nulo. Origem do custo: nula.
- Câmbio registrado: 5,2204 BRL/USD, PTAX de venda do BCB (Olinda CotacaoDolarPeriodo), em 29/09/2026 às 13:06. Ele não pode ser aplicado porque não há valor em USD.
- Não recebi tabela de preços nem ID do modelo ou provedor para uma estimativa documentada. Também não fiz reconstrução por suposição.
- Cobertura do custo de geração no recorte: 0 de 1 chamada. O custo total fica N/A e não há subtotal a publicar.
- Custos de juízes e de pesquisa ficam fora deste cálculo.

## 5. Notas E
| E1 | E2 | E3 | Versão das metas | Motivos de N/A |
|---|---|---|---|---|
| N/A | N/A | N/A | N/A | Não há metas pré-fixadas neste lote. Em E3, falta também o custo observado. |
Fórmula prevista: nota(x) = 100 se x ≤ alvo; 0 se x ≥ limite; caso contrário, 100 × (limite − x) / (limite − alvo). Ela não foi aplicada porque faltam alvo e limite. Os valores brutos de E1 (69,83 s) e E2 (15,65 s) continuam publicados. Não calculei média de eficiência.

## 6. Pendências
1. Conciliar o custo via /generation ou com uma estimativa documentada (tarifas, data e moeda) e convertê-lo pela PTAX registrada.
2. Tirar a telemetria do estado PENDENTE.
3. Pré-fixar as metas latencia_*, primeiro_texto_* e custo_* antes da coleta definitiva.