**JE – Apuração de tempo, consumo e custo (protocolo 3.2)**

Resumo: medi a latência e o tempo até o primeiro texto, e transcrevi os tokens como registro provisório. O custo de geração e as notas E1-E3 ficam N/A, porque faltam o valor cobrado e as metas.

## 1. Identificação
- Protocolo: 3.2; papel: JE
- Código: Qa4a705a91d2946f98b7ae673802c9e38
- Execução: E68880818928863924961
- Tema e rodada: B01, rodada 1 (piloto OpenRouter)
- Modo: coleta instrumentada via OpenRouter (api-openrouter-v1)
- Situação operacional: validada por JT. A execução foi iniciada, terminou em conclusão normal e o ramo de saída é explicação. Não há conflito entre registros.
- Tentativas: uma chamada de geração, sem reenvio automático e sem ferramentas registradas.

## 2. Medidas brutas
| Medida | Valor bruto | Unidade | Origem | Situação | Observação |
|---|---|---|---|---|---|
| Latência total | 75,84 (75,842444825) | s | Coletor instrumentado: do envio HTTP ao fim do stream | Medido | Tentativa única; o intervalo coincide com o da execução |
| Primeiro texto | 29,42 (29,415836552) | s | Coletor: primeiro fragmento textual observado no stream | Medido | Mede fragmento, não o primeiro token (TTFT); o raciocínio oculto não entra |
| Tempo até falha | — | s | — | Não aplicável | A execução teve conclusão normal |
| Tokens de entrada (prompt) | 13.032 | tokens | usage, complementado por native_tokens_* | Registrado, telemetria PENDENTE | Provisório |
| Tokens de saída (completion) | 4.961 | tokens | usage | Registrado, telemetria PENDENTE | Provisório |
| Tokens totais | 17.993 | tokens | usage | Registrado, telemetria PENDENTE | Confere com a soma 13.032 + 4.961 |
| Tokens de cache | 0 | tokens | usage | Registrado, telemetria PENDENTE | Parte da entrada |
| Tokens de raciocínio | 1.402 | tokens | usage | Registrado, telemetria PENDENTE | Parte da saída faturada |
| Custo de geração | — | BRL | /generation retornou nulo | Indisponível | Ausência de dado não é custo zero |

## 3. Tokens e sobreposições
Os campos de tokens foram preservados como vieram do registro. O total de 17.993 é exatamente a entrada mais a saída (13.032 + 4.961).

Cache e raciocínio não entram de novo nessa soma:
- **Cache (0):** detalha os tokens de entrada.
- **Raciocínio (1.402):** detalha os tokens de saída. Pela convenção de usage, o raciocínio já está dentro de completion_tokens, então sobram cerca de 3.559 tokens não classificados como raciocínio. Isso é uma inferência pela convenção, não uma medida de texto visível.

Com a telemetria PENDENTE, esses números não são consumo completo confirmado.

## 4. Cálculo do custo
- **Tarifas:** não foram usadas. Nenhum preço por token foi fornecido e não reconstruí o custo por tabela, porque isso seria uma estimativa sem documentação.
- **Câmbio disponível:** PTAX venda BCB de 5,2204 BRL/USD, em 29/09/2026 às 13:06.
- **Conversão:** não há valor em USD para converter. CUSTO_BRL = cost_usd × 5,2204 fica N/A.
- **Ferramentas:** nenhuma taxa registrada; há uma única tentativa.
- **Cobertura:** 0 de 1 chamada com custo conhecido. O custo total é N/A e não há subtotal a publicar.
- **Orçamento separado:** custos de JC, JP, JT, JE, pairwise e pesquisa não entram aqui.

## 5. Notas E
| E1 | E2 | E3 | Versão das metas | Motivos de N/A |
|---|---|---|---|---|
| N/A | N/A | N/A | N/A (não definida) | E1 e E2: faltam as metas (latencia_alvo_s/limite_s, primeiro_texto_alvo_s/limite_s), embora as medidas brutas existam. E3: faltam as metas e o custo. |

Fórmula que seria aplicada, com 0 <= alvo < limite:
- nota = 100, se x <= alvo
- nota = 0, se x >= limite
- nota = 100 × (limite − x) / (limite − alvo), nos demais casos

Não é aplicável sem metas pré-fixadas. Não calculo média de eficiência.

## 6. Pendências
1. Conciliar o custo em /generation (USD) e documentar sua origem. Depois disso, converter para BRL com a cotação registrada.
2. Concluir a telemetria para confirmar os tokens.
3. Fixar metas E1-E3 versionadas antes da coleta definitiva, iguais para todos os sistemas.

A conciliação deve acrescentar evidências sem alterar o registro original.