Parecer JX2 – afirmação única pendente A46.

A afirmação: no exemplo da vacina hipotética de proteína inativada, a resposta diz, como etapa esperada e sem nenhuma ressalva, que "T citotóxicos e auxiliares geram efetores e depois memória". Portanto, atribui a um antígeno proteico exógeno e não replicante a indução de resposta CD8 citotóxica efetora e de memória.

Buscas feitas:
(1) Europe PMC com os termos "protein vaccines", CD8 e cross-presentation. Os resultados não eram pertinentes.
(2) Texto completo de Clem 2011 (PMC3068582, via fullTextXML do Europe PMC). O artigo não trata da resposta CD8 induzida por vacinas inativadas ou de subunidade. Ele diz apenas que vacinas inativadas "produce weaker immune responses".
(3) Europe PMC com TITLE_ABS contendo "cross-presentation", "subunit vaccines" e CD8. Vários resumos convergem: as vacinas de subunidade não conseguem induzir imunidade celular robusta.
(4) Resumo completo da revisão "Vaccine adjuvants to engage the cross-presentation pathway" (PMID 35979365; PMC9376467), aberto via API do Europe PMC. O resumo afirma: "Adjuvants are indispensable components of vaccines for stimulating optimal immune responses to non-replicating, inactivated and subunit antigens... currently used vaccines elicit strong antibody responses, but poorly stimulate CD8 cytotoxic T lymphocyte (CTL) responses. To elicit potent CTL memory, vaccines need to engage the cross-presentation pathway, and this requirement has been a crucial bottleneck in the development of subunit vaccines".

Conclusão: a revisão contradiz a afirmação. Segundo ela, vacinas inativadas ou de subunidade estimulam mal a resposta CTL CD8. Gerar memória CTL potente depende da apresentação cruzada, que é justamente um gargalo desse tipo de vacina. A resposta, ao contrário, apresenta a geração de efetores e memória CD8 como resultado natural de uma vacina de proteína inativada. Não menciona a apresentação cruzada nem essa limitação. Além disso, entra em conflito com o que a própria resposta atribui a [B02-F3]: o MHC de classe I apresenta peptídeos intracelulares.

Uma nuance: a fonte não diz que a indução de CD8 é impossível. Ela é fraca e depende de adjuvantes ou formulações que ativem a apresentação cruzada. Mesmo assim, o conteúdo essencial da afirmação, apresentado sem ressalva como desfecho esperado, é contradito. Classificação: CONTRADITA_EXTERNA.