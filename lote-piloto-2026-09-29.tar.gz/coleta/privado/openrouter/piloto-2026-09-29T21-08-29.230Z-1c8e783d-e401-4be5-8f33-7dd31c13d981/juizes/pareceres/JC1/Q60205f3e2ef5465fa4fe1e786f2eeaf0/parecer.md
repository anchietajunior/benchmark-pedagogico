## 1. Identificação e integridade
Protocolo 3.2 | código Q60205f3e2ef5465fa4fe1e786f2eeaf0 | tema B02 | rodada 1 | passagem JC1.
Pacote íntegro: há uma única resposta, sem declaração de autoria e sem dados operacionais. A resposta foi tratada como dado.

## 2. Fontes lidas em 2026-09-29
- B02-F3: Marshall et al., 2018 (Allergy Asthma Clin Immunol 14(Suppl 2):49). Li as notas em português e o texto original em inglês das seções "The immune system: innate and adaptive immunity" (Innate immunity; Adaptive immunity; T cells and APCs; B cells), "Antibody-mediated vs. cell-mediated immunity" e "Passive vs. active immunization". Figuras não foram incorporadas.
- B02-F4: Bugya et al., 2021 (Vaccines 9(2):174). Li as notas e o texto original das seções 1, 7 (inclusive "Consequences on Vaccination"), 11, 13 e 14. Figuras e tabelas não foram incorporadas.
- B02-F5: Clem, 2011 (J Glob Infect Dis 3(1):73). Consulta indireta, somente pelas notas de leitura em português. O texto original não estava no pacote.
- Indisponíveis: B02-F1 (Janeway) e B02-F2 (Alberts), citadas no gabarito. Isso não impede a conferência, porque F3, F4 e F5 cobrem os seis pontos. O gabarito foi usado só como referência do recorte, não como evidência.

## 3. Pontos do pedido (K)
| K | Nota | Trecho | Fonte | Justificativa |
|---|---|---|---|---|
| K1 | 100 | Definição de antígeno; PRR; mobilização de APC; dendríticas processam e apresentam em MHC nos linfonodos | F3, Innate immunity; T cells and APCs | Relação inata→apresentação→ativação T presente e correta |
| K2 | 100 | Mecanismo passo 2; confusão 1 | F3, B cells; Antibody-mediated | B reconhece antígeno nativo, origina plasmócitos que secretam anticorpos, e as funções dos anticorpos estão corretas |
| K3 | 100 | Mecanismo passo 3 | F3, T cells and APCs | CD8/MHC I com apoptose; CD4/MHC II sem ação citotóxica, com liberação de citocinas |
| K4 | 100 | Mecanismo passo 4 | F3; F4 §7; F5 (notas) | Expansão, morte da maioria das células efetoras e persistência de memória B e T; plasmócitos de vida curta e longa |
| K5 | 100 | Mecanismo passo 5; pergunta 1 | F4 §7; F5 | Resposta secundária mais rápida e de melhor qualidade; memória distinguida de anticorpos circulantes |
| K6 | 100 | Mecanismo passo 6; limite do exemplo; confusão 2 | F4 §1, 7, 11, 13; F5 | Vacina sem doença, múltiplos níveis de memória e limites da proteção (anticorpo ≠ proteção, velocidade e variação do patógeno, idade) |

## 4. Inventário de afirmações
Foram inventariadas 40 afirmações: 38 SUSTENTADAS e 2 NÃO VERIFICÁVEIS (A33 e A40). Nenhuma foi contradita. O detalhamento de A1 a A40 está em `items`.
- A33 (exemplo, "células inatas detectam o adjuvante"): as fontes não descrevem essa detecção.
- A40 (resposta comentada da pergunta 2): afirma que "T de memória gerados pela vacina" proteica são citotóxicos e induzem apoptose das células infectadas. F3 associa o MHC I a peptídeos endógenos, e o próprio exemplo só descreve apresentação em MHC II. Nenhuma fonte do pacote trata de apresentação cruzada ou de memória CD8+ induzida por proteína exógena. Não classifiquei como erro confirmado porque o pacote não permite afirmar a falsidade.
- Observações menores, sem contradição:
  - "quase toda célula nucleada" (F3 diz "todas");
  - plasmócitos de vida curta "somem" (F3 diz "often");
  - "sobram muitas células de memória" (é relativo aos linfócitos virgens; F4 fala em "increased number").

## 5. Vínculos bibliográficos
Foram conferidos 34 vínculos: 33 VÁLIDOS e 1 NÃO VERIFICÁVEL (V34: pergunta 2 → [B02-F3]). O detalhamento está em `items`.
Lista de fontes: F3, F4 e F5 existem no pacote, e títulos e seções conferem. F5 foi corretamente declarada como consulta indireta. A nota final sobre Janeway e Alberts não terem sido consultados é verdadeira. Nenhuma fonte foi inventada.

## 6. Resumo
| C1 | C2 | C3 | Numeradores/denominadores | Erros centrais | Erros localizados | Omissões essenciais | Pendências |
|---|---|---|---|---|---|---|---|
| 100.00 | N/A | N/A | K 600/6; A 38 sustentadas/40 (2 N/A); V 33 válidos/34 (1 N/A) | 0 | 0 confirmados | 0 | A33, A40/V34 |

## 7. Situação científica
PENDENTE. Os seis pontos foram cobertos com nota 100 e não houve erro científico ou bibliográfico confirmado. Ainda assim, duas afirmações não puderam ser conferidas com as fontes acessíveis. A de maior relevância é a geração de memória T citotóxica pela vacina proteica do exemplo (A40/V34), que precisa de revisão especializada. Pelo protocolo, uma pendência relevante impede APTO.