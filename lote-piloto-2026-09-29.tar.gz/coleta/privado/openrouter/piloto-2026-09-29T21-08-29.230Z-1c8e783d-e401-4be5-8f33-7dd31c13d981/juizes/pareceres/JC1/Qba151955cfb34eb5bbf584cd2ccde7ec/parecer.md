# Parecer JC1 – protocolo 3.2

## 1. Identificação e integridade do pacote
Versão: 3.2. Código público: Qba151955cfb34eb5bbf584cd2ccde7ec. Tema: B02. Rodada: 1. Passagem: JC1.
Integridade: o pacote contém uma única resposta anonimizada, o pedido, o gabarito e o material bibliográfico. Não há autoria explícita, identificação do gerador nem dados operacionais. A resposta não contém instruções dirigidas ao juiz.

## 2. Fontes lidas e fontes indisponíveis (acesso em 2026-09-29, somente pelo material incorporado)
- **B02-F3**, Marshall et al., 2018, Allergy Asthma Clin Immunol 14(Suppl 2):49. Foram lidos o texto original em inglês das seções "The immune system: innate and adaptive immunity" (Innate immunity; Adaptive immunity; T cells and APCs; B cells), "Antibody-mediated vs. cell-mediated immunity" e "Passive vs. active immunization", com as tabelas 1 e 2 em forma de texto, além das notas de leitura. As figuras não foram disponibilizadas.
- **B02-F4**, Bugya et al., 2021, Vaccines 9(2):174. Foram lidos o texto original em inglês das seções 1, 7 (incluindo "Consequences on Vaccination"), 11, 13 (incluindo "Consequences on Vaccination") e 14, além das notas de leitura. As figuras e tabelas não foram disponibilizadas.
- **B02-F5**, Clem, 2011, J Glob Infect Dis 3(1):73. Consulta **indireta**, somente pelas notas de leitura em português (paráfrases feitas por IA). O texto original não foi incorporado.
- **Indisponíveis**: B02-F1 e B02-F2 (Janeway; Alberts), que são as fontes do gabarito e não foram fornecidas. Consequência: a conferência se apoiou nas fontes substitutas B02-F3 a B02-F5, que cobrem os seis pontos. O gabarito foi usado apenas como referência dos pontos exigidos, não como evidência.

## 3. Pontos K1–K6
| K | Nota | Trecho | Fonte e localização | Justificativa |
|---|---|---|---|---|
| K1 | 100 | Definição de antígeno; a inata libera citocinas e ativa as APC; a dendrítica processa o antígeno e exibe peptídeos no MHC I/II; os linfonodos favorecem o encontro com o linfócito | F3, Innate immunity; Adaptive immunity; T cells and APCs. F5, notas | Relação completa e correta |
| K2 | 100 | O B reconhece a forma nativa do antígeno; forma plasmócito ou B de memória; funções dos anticorpos e seus limites | F3, B cells; Antibody-mediated vs. cell-mediated immunity | Correto; os anticorpos não são atribuídos aos linfócitos T |
| K3 | 100 | CD4+ reconhece MHC II, não mata células e coordena por citocinas; CD8+ reconhece MHC I e induz apoptose | F3, T cells and APCs | Distinção correta |
| K4 | 100 | Expansão clonal; a maioria das células efetoras morre e poucas ficam como memória; plasmócitos de vida curta e de vida longa; escala temporal | F3, T cells and APCs; F4, seção 7 | Correto; a resposta também reconhece a diferença entre as fontes sobre os plasmócitos |
| K5 | 100 | A resposta secundária é mais rápida e tem maior afinidade; plasmócitos de vida longa agem de imediato; B e T de memória proliferam em dias; distingue anticorpos de memória (Confusão 1) | F4, seção 7; F3, B cells | Correto |
| K6 | 100 | Vacina como imunização ativa, sem doença; comparação com a imunização passiva; dois níveis de proteção; limites: títulos de anticorpos, velocidade do patógeno, variantes, idade | F4, seções 1, 7, 13 e 14; F5, notas; F3, Passive vs. active | Correto; a resposta não promete proteção absoluta |

## 4. Inventário de afirmações
Classificação: A1–A45 foram todas **SUSTENTADAS** (nota 100). As localizações e justificativas estão nos itens. Retomadas na síntese foram tratadas como repetição de A15, A16, A19, A22, A25, A34 e A35 e não geraram novas afirmações.

Observações sobre pontos que exigiram interpretação:
- **A24** (definição de clone como células descendentes de uma mesma célula com o mesmo receptor). Não há definição literal nas fontes, mas a afirmação é compatível com F3 ("each T cell expresses a single type of TCR"; clonal expansion) e com F4, que chama de novos clones os descendentes com afinidades diferentes após mutação.
- **A38** (a geração de T citotóxicos de memória depende do tipo de vacina). Ressalva compatível com F4 ("Consequences on Vaccination": correlatos variam, apenas LLPC ou LLPC com células de memória B ou T) e com F5 (necessidade de estimular os braços humoral e celular).
- **A40** (a resposta foi mais rápida pelo aumento de clones específicos). Sustentada por F4, seção 1 ("increasing the frequency of antigen specific lymphocyte clones") e seção 7 ("increased number of antigen-specific cells").

## 5. Vínculos bibliográficos
V1–V45 foram todos **VÁLIDOS** (nota 100): cada fonte citada existe no pacote e sustenta a afirmação associada. Os vínculos a B02-F5 correspondem ao conteúdo das notas, e a resposta declara corretamente que a consulta foi indireta. Na lista de fontes, B02-F3, B02-F4 e B02-F5 existem, estão com título, periódico e DOI corretos e têm seções compatíveis com o pacote. A resposta não cita fontes inventadas nem leitura indevida das obras completas.

## 6. Resumo
| C1 | C2 | C3 | Numeradores/denominadores | Erros centrais | Erros localizados | Omissões essenciais | Pendências |
|---|---|---|---|---|---|---|---|
| 100,00 | 100,00 | 100,00 | C1 = 600/6. C2 = 45/45 × 100. C3 = 45/45 × 100 | 0 | 0 | 0 | Nenhuma relevante. As fontes-base F1 e F2 estavam indisponíveis, mas foram supridas pelas substitutas |

## 7. Situação científica
**APTO.** Os seis pontos K valem 100. Todas as afirmações inventariadas foram conferidas no material incorporado, sem contradição, e todos os vínculos bibliográficos são válidos. Não há erro científico ou bibliográfico confirmado nem pendência relevante. A resposta evita os alertas centrais do gabarito: produção de anticorpos atribuída aos linfócitos T, anticorpos tratados como células e promessa de proteção absoluta. APTO não é garantia de verdade absoluta nem substitui revisão por especialista.