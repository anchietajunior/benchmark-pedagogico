# Parecer JC1: Protocolo 3.2

## 1. Identificação e integridade

- **Versão:** 3.2
- **Código:** Qf8527290bfda4c69ad050b4940fd8652
- **Tema:** B01
- **Rodada:** 1
- **Passagem:** JC1

O pacote está íntegro:
- há uma única resposta;
- não há autoria explícita do modelo ou do fornecedor;
- não há dados operacionais;
- a resposta não contém instruções dirigidas ao juiz.

## 2. Fontes lidas e indisponíveis

Acesso em 2026-09-29, restrito ao material incorporado na chamada:
- **B01-F3** (Palta, Saroa e Palta, Indian J Anaesth 2014;58(5):515-523): li o corpo textual original em XML e as notas de leitura. Seções usadas: Introduction, Primary haemostasis (adhesion, secretion, aggregation), Clotting factors, Naturally occurring anticoagulants, Coagulation cascade, Current concept of coagulation, Thrombotic disorders, Fibrinolytic system, Disorders of fibrinolysis e Summary. As imagens e tabelas não foram inspecionadas.
- **B01-F2** (MSD Manual, Overview of Hemostasis, set/2025): consulta indireta, somente pelas notas de leitura em paráfrase.
- **B01-F4** (NHLBI, How Does Blood Clot?, 2022): consulta indireta, somente pelas notas.
- **B01-F5** (NHLBI, What Are Blood Clotting Disorders?, 2022): consulta indireta, somente pelas notas.
- **Indisponível:** B01-F1 (OpenStax), citada no gabarito. A falta dessa fonte não impede a conferência, porque as fontes incorporadas cobrem os seis pontos.
- **Limitação:** o gabarito não foi usado como evidência.

## 3. Pontos K

| K | Nota | Trecho/ausência | Fonte e localização | Justificativa |
|---|---|---|---|---|
| K1 | 100 | Seção 1 da resposta: vasoconstrição e exposição do subendotélio (colágeno, vWF e TF) | F3 Primary haemostasis e Extrinsic pathway; F4 notas | A resposta explica o que muda no vaso e por que isso dispara a resposta. |
| K2 | 100 | Seção 2 da resposta: adesão vWF–GpIb, ativação e degranulação, recrutamento por ADP/TxA2, GpIIb/IIIa e fibrinogênio | F3 Platelet adhesion, secretion e aggregation; F2 notas | Adesão, ativação e agregação estão explicadas, com a função de cada uma. |
| K3 | 100 | Seção 3 da resposta: iniciação (TF–VIIa), amplificação (V/VIII), propagação (tenase e protrombinase), trombina e fibrina | F3 Current concept e Common pathway | O mecanismo que leva à trombina e à fibrina está correto. |
| K4 | 100 | Seção 4 da resposta: ligações cruzadas pelo XIII, retenção de hemácias e integração bidirecional | F3 Stabilization e Propagation; F4 notas | A resposta explica a estabilização e a integração entre hemostasia primária e secundária. |
| K5 | 100 | Seção 5 da resposta: TFPI, antitrombina, proteína C/S, prostaciclina; tPA e plasmina; PAI, α2-antiplasmina e TAFI | F3 Anticoagulants e Fibrinolytic system; F2 notas | A regulação e a fibrinólise estão corretas e são tratadas como mecanismos distintos. |
| K6 | 100 | Seção 6 da resposta: resposta local e transitória × coágulo sem lesão ou desproporcional; obstrução e TVP | F5 notas; F3 Intro e Thrombotic disorders | A distinção entre hemostasia e trombose é correta e usa localização e controle como critério. |

## 4. Inventário de afirmações

| ID | Trecho | Situação | Nota | Fonte |
|---|---|---|---|---|
| A1 | Endotélio íntegro produz NO e prostaciclina | SUSTENTADA | 100 | F2 notas |
| A2 | Subendotélio contém colágeno, vWF e TF, separados do sangue | SUSTENTADA | 100 | F3 Primary haemostasis; Clotting factors (TF) |
| A3 | Plaquetas são fragmentos anucleados com grânulos (ADP, Ca, fibrinogênio, fator V) | SUSTENTADA | 100 | F3 Primary haemostasis |
| A4 | Fatores são zimogênios; a forma ativa recebe o sufixo "a" | SUSTENTADA | 100 | F3 Clotting factors |
| A5 | Trombina converte fibrinogênio solúvel em fibrina insolúvel | SUSTENTADA | 100 | F3 Coagulation pathways; Common pathway |
| A6 | Fibrinólise é a dissolução da fibrina pela plasmina | SUSTENTADA | 100 | F3 Fibrinolytic; F2 notas |
| A7 | Vasoconstrição arteriolar por reflexo neurogênico, endotelina e TxA2 | SUSTENTADA | 100 | F3 Primary haemostasis |
| A8 | O estreitamento do vaso reduz a perda de sangue | SUSTENTADA | 100 | F4 notas |
| A9 | A exposição do subendotélio põe o TF em contato com o fator VII e dispara a resposta | SUSTENTADA | 100 | F3 Extrinsic pathway; Clotting factors |
| A10 | vWF faz a ponte entre colágeno e GpIb | SUSTENTADA | 100 | F3 Platelet adhesion |
| A11 | Ativação: mudança de forma, pseudópodes, degranulação | SUSTENTADA | 100 | F3 Primary haemostasis; Platelet secretion |
| A12 | ADP e TxA2 recrutam outras plaquetas | SUSTENTADA | 100 | F3 Platelet aggregation |
| A13 | Cálcio liga-se a fosfolipídios e cria superfície para os fatores | SUSTENTADA | 100 | F3 Platelet secretion |
| A14 | ADP muda GpIIb/IIIa, que liga fibrinogênio; este une plaquetas; o tampão veda temporariamente | SUSTENTADA | 100 | F3 Platelet aggregation; F2 notas |
| A15 | Modelo atual em fases sobre superfícies celulares | SUSTENTADA | 100 | F3 Coagulation cascade; Current concept |
| A16 | TF–VIIa ativa IX e X; o Xa gera pouca trombina | SUSTENTADA | 100 | F3 Initiation |
| A17 | Trombina ativa V e VIII; eles aceleram II→IIa e X→Xa | SUSTENTADA | 100 | F3 Amplification |
| A18 | Tenase e protrombinase na plaqueta geram muita trombina | SUSTENTADA | 100 | F3 Propagation; Intrinsic pathway |
| A19 | Protrombinase = Xa, Va, fosfolipídios e Ca | SUSTENTADA | 100 | F3 Common pathway |
| A20 | As vias não são independentes: o TF inicia e a via intrínseca amplifica | SUSTENTADA | 100 | F3 Current concept; F2 notas |
| A21 | Fibrina incorporada ao tampão; XIIIa faz ligações covalentes cruzadas | SUSTENTADA | 100 | F3 Common pathway; Stabilization |
| A22 | A rede de fibrina sustenta o tampão e retém hemácias | SUSTENTADA | 100 | F4 notas |
| A23 | A contração plaquetária aproxima as bordas | SUSTENTADA | 100 | F4 notas |
| A24 | Plaquetas fornecem a superfície; trombina ativa plaquetas | SUSTENTADA | 100 | F3 Primary haemostasis; Amplification; Propagation |
| A25 | Hemostasia primária e secundária formam um processo integrado | SUSTENTADA | 100 | F3 Platelet aggregation; F3 notas |
| A26 | TFPI inibe TF–VIIa e Xa e encerra a iniciação | SUSTENTADA | 100 | F2 notas; F3 Initiation; TFPI |
| A27 | Antitrombina, ativada por heparan sulfato endotelial, neutraliza trombina e Xa | SUSTENTADA | 100 | F3 Antithrombin; F2 notas |
| A28 | Trombina + trombomodulina em endotélio íntegro ativam proteína C; com a proteína S, esta inativa Va e VIIIa | SUSTENTADA | 100 | F2 notas; F3 Protein C pathway |
| A29 | Prostaciclina contrabalança o TxA2 | SUSTENTADA | 100 | F3 Platelet aggregation |
| A30 | tPA endotelial converte plasminogênio ligado à fibrina em plasmina, que degrada a fibrina | SUSTENTADA | 100 | F3 Fibrinolytic; F2 notas |
| A31 | PAI, α2-antiplasmina e TAFI limitam a fibrinólise | SUSTENTADA | 100 | F3 Fibrinolytic; Stabilization |
| A32 | A hemostasia é local e transitória; o coágulo é removido após o reparo | SUSTENTADA | 100 | F3 Intro; F4 e F5 notas |
| A33 | Trombose: coágulos sem lesão aparente ou desproporcionais comprometem órgãos (TVP) | SUSTENTADA | 100 | F5 notas; F3 Intro |
| A34 | Desequilíbrio por excesso pró-coagulante ou falta de inibidores; deficiências de AT, PC e PS | SUSTENTADA | 100 | F3 Intro; Thrombotic disorders |
| A35 | No exemplo, o sangramento diminui "em minutos" | NÃO VERIFICÁVEL | N/A | Nenhuma fonte fornece escala temporal |
| A36 | No exemplo, a fibrina é dissolvida "dias depois" | NÃO VERIFICÁVEL | N/A | F4 diz só "posteriormente"; F3 descreve fibrinólise paralela, sem prazo |
| A37 | Um tampão só de plaquetas é frágil; a fibrina o estabiliza | SUSTENTADA | 100 | F3 "temporarily"; Stabilization; F4 notas |
| A38 | Deficiência de plaquetas ou de fatores altera o resultado | SUSTENTADA | 100 | F4 notas |
| A39 | Confusão 1: o modelo clássico descreve testes in vitro; o paradoxo das hemofilias A e B | SUSTENTADA | 100 | F3 Coagulation cascade |
| A40 | Confusão 2: inibir a produção de fibrina ≠ degradar fibrina formada | SUSTENTADA | 100 | F2 notas. A expressão "momentos diferentes" é vaga; F3 descreve a fibrinólise em paralelo, mas não há contradição direta. |
| A41 | Resposta 1: pouca trombina na iniciação, contida pelo TFPI; retroalimentação positiva | SUSTENTADA | 100 | F3 Initiation; Amplification; Propagation |
| A42 | Resposta 2: trombomodulina/PC/PS, heparan sulfato/AT e prostaciclina fora da lesão | SUSTENTADA | 100 | F2 notas; F3 |

A síntese repete A20–A34 e não gera itens novos.

## 5. Vínculos bibliográficos

| ID | Afirmação → referência | Resultado | Nota |
|---|---|---|---|
| V1 | Ideia central → F3 | VÁLIDO | 100 |
| V2 | A1 → F2 | VÁLIDO | 100 |
| V3 | A2 → F3 | VÁLIDO | 100 |
| V4 | A3 → F3 | VÁLIDO | 100 |
| V5 | A4 → F3 | VÁLIDO | 100 |
| V6 | A5 → F3 | VÁLIDO | 100 |
| V7 | A6 → F2, F3 | VÁLIDO | 100 |
| V8 | A7/A8 → F3, F4 | VÁLIDO | 100 |
| V9 | A9 → F3 | VÁLIDO | 100 |
| V10 | A10 → F3 | VÁLIDO | 100 |
| V11 | A11–A13 → F3 | VÁLIDO | 100 |
| V12 | A14 → F2, F3 | VÁLIDO | 100 |
| V13 | A15 → F3 | VÁLIDO | 100 |
| V14 | A16–A19 → F3 | VÁLIDO | 100 |
| V15 | A20 → F2, F3 | VÁLIDO | 100 |
| V16 | A21 → F3 | VÁLIDO | 100 |
| V17 | A22/A23 → F4 | VÁLIDO | 100 |
| V18 | A24 → F3 | VÁLIDO | 100 |
| V19 | A26/A27 → F2, F3 | VÁLIDO | 100 |
| V20 | A28 → F2, F3 | VÁLIDO | 100 |
| V21 | A29 → F3 | VÁLIDO | 100 |
| V22 | A30/A31 → F2, F3 | VÁLIDO | 100 |
| V23 | A32 → F3, F5 | VÁLIDO | 100 |
| V24 | A33 → F5 | VÁLIDO | 100 |
| V25 | A34 → F3 | VÁLIDO | 100 |
| V26 | Etapas mecanísticas do exemplo → F3, F4 | VÁLIDO | 100 |
| V27 | "Dias depois… tPA e plasmina" → F3, F4 | NÃO VERIFICÁVEL | N/A |
| V28 | A38 → F4 | VÁLIDO | 100 |
| V29 | A39 → F3 | VÁLIDO | 100 |
| V30 | A40 → F2 | VÁLIDO | 100 |
| V31 | A41 → F3 | VÁLIDO | 100 |
| V32 | A42 → F2, F3 | VÁLIDO | 100 |

Sobre V27: o mecanismo citado é sustentado pelas fontes, mas o prazo de "dias" não é.

**Lista de fontes da resposta:** as quatro entradas (F2–F5) existem no pacote, e as seções declaradas de F3 constam do XML. A consulta indireta às notas está indicada. Não há fonte inventada nem item solto problemático.

## 6. Resumo

| C1 | C2 | C3 | Numeradores/denominadores | Erros centrais | Erros localizados | Omissões essenciais | Pendências |
|---|---|---|---|---|---|---|---|
| 100,00 | N/A | N/A | C1: 600/6. C2: 40 sustentadas, 0 contraditas, 2 não verificáveis em 42 (seria 95,24 se as duas fossem contadas como não sustentadas; não é calculável). C3: 31 válidos, 0 com problema, 1 não verificável em 32. | 0 | 0 | 0 | A35, A36, V27 (escalas temporais do exemplo) |

## 7. Situação científica: PENDENTE

- Os seis pontos K estão completos e corretos.
- Não há erro científico nem bibliográfico confirmado.
- Duas afirmações temporais do exemplo ("em minutos", "dias depois") não podem ser conferidas nas fontes incorporadas.

Pela regra do protocolo, pendência relevante impede APTO, e não há erro que justifique CORRIGIR. As duas afirmações podem ser resolvidas com fonte que as sustente ou por revisão especializada. APTO não seria garantia de verdade absoluta.