## 1. Identificação e integridade
Protocolo 3.2; código Qa6eaf848a80d48338ee9071311dd6632; tema B02; rodada 1; passagem JC1. O pacote contém uma única resposta, sem autoria explícita e sem dados operacionais. O pacote está íntegro.

## 2. Fontes
- **Lidas:** notas de leitura em português de B02-F3, B02-F4 e B02-F5, preparadas em 2026-09-29.
- **Texto original em inglês disponível:**
  - B02-F3 (Marshall et al., 2018, Allergy Asthma Clin Immunol 14(Suppl 2):49): seções The immune system: innate and adaptive immunity (Innate immunity, Adaptive immunity, T cells and APCs, B cells), Antibody-mediated vs. cell-mediated immunity, Passive vs. active immunization.
  - B02-F4 (Bugya et al., 2021, Vaccines 9(2):174): seções 1, 7 (incluindo Consequences on Vaccination), 11, 13 e 14.
- **Somente notas:** para B02-F5 (Clem, 2011), a consulta foi indireta, apenas pelas notas.
- **Fora do alcance:** figuras, tabelas não incorporadas de B02-F4 e obras citadas pelos artigos.
- **Indisponíveis:** B02-F1 e B02-F2 (Janeway, Alberts), apontadas pelo gabarito. As fontes substitutas bastaram para conferir quase todo o conteúdo. A exceção é a ativação de CD8 por vacina proteica (A41).

## 3. K1–K6
| K | Nota | Trecho | Fonte | Justificativa |
|---|---|---|---|---|
| K1 | 0 | "Antígeno é qualquer estrutura reconhecida como não própria…"; §1 inata/APC/MHC | F3, Adaptive immunity; T cells and APCs | A parte sobre imunidade inata e apresentação de antígenos está correta. Porém, a definição de antígeno, exigida pelo ponto, é contradita pela fonte, que reconhece antígenos próprios. Houve erro confirmado. |
| K2 | 100 | §2: B → plasmócitos que secretam anticorpos, B de memória; funções dos anticorpos | F3, B cells; Antibody-mediated | Correto e suficiente. |
| K3 | 100 | §3 e confusão 2: CD4/MHC II coordenam por citocinas; CD8/MHC I induzem apoptose | F3, T cells and APCs | Correto. |
| K4 | 100 | §4: expansão clonal, morte da maioria das células efetoras, persistência de memória | F3; F4 §7 | Correto. |
| K5 | 100 | §5: resposta secundária mais rápida e de maior afinidade; confusão 1 | F4 §7; F3 | Correto, distinguindo anticorpos de células de memória. |
| K6 | 100 | §6 e limite do exemplo | F4 §1, §7, §11, §13; F3 | Relação com a vacinação e limites da proteção estão corretos. |

## 4. Inventário de afirmações
Foram inventariadas 48 afirmações (A1–A48; detalhes nos itens):
- **A1 — CONTRADITA:** definição de antígeno como estrutura não própria. B02-F3 fala em reconhecer antígenos "non-self" "distinguishing them from 'self' antigens" e trata do controle de respostas a "self-antigens".
- **A41 — NÃO VERIFICÁVEL:** geração de T citotóxicos efetores e de memória por uma vacina de proteína inativada.
- **Demais 46 — SUSTENTADAS.**

## 5. Vínculos
Foram conferidos 50 vínculos (V1–V50):
- 48 válidos;
- V2 (A1–F3) com problema confirmado;
- V42 (A41–F3/F4) não verificável.

Não há problemas na lista de fontes: F3, F4 e F5 existem, as seções declaradas correspondem às fornecidas e a consulta indireta a F5 foi indicada corretamente.

## 6. Resumo
| C1 | C2 | C3 | Numeradores/denominadores | Erros centrais | Erros localizados | Omissões essenciais | Pendências |
|---|---|---|---|---|---|---|---|
| 83.33 | N/A | N/A | C1 = 500/6; C2: 46 sustentadas, 1 contradita, 1 não verificável de 48; C3: 48 válidos, 1 problema, 1 não verificável de 50 | 0 | 1 (A1, definição de antígeno) | 0 | A41/V42 |

- **C2 N/A:** há um item não verificável; uma C2 parcial seria 95.83.
- **C3 N/A:** há um vínculo não verificável; uma C3 parcial seria 96.00.

## 7. Situação científica
**CORRIGIR.** Há um erro científico confirmado (A1), que leva K1 a 0; um erro confirmado impede a aprovação independentemente da média. A pendência A41 também precisa ser resolvida. O restante do conteúdo (B, plasmócitos, anticorpos, T auxiliares e citotóxicos, memória, resposta secundária, vacinação e limites da proteção) é sustentado pelas fontes fornecidas.