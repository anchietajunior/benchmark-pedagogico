1. IDENTIFICAÇÃO E INTEGRIDADE
Versão 3.2; código público Q93212bbde03d42aaac6e063e60844bcf; tema B01; rodada 1; passagem JC1. O pacote contém uma única resposta anonimizada, sem autoria explícita nem dados operacionais. O pacote está íntegro.

2. FONTES LIDAS E INDISPONÍVEIS (acesso em 2026-09-29, somente no conteúdo incorporado)
- B01-F3 (Palta, Saroa e Palta, Indian J Anaesth 2014;58(5):515-523): o corpo XML original em inglês foi lido integralmente, incluindo as seções Introduction, Primary haemostasis, Clotting factors, Naturally occurring anticoagulants, Coagulation cascade, Current concept, Thrombotic disorders, Fibrinolytic system e Summary. Também li a paráfrase em português. As imagens e tabelas não estavam disponíveis.
- B01-F2 (MSD Manual, Overview of Hemostasis, set/2025): consulta indireta, apenas por notas de leitura redigidas por IA (seções Platelets, Plasma Coagulation Factors e Regulation of Coagulation).
- B01-F4 (NHLBI, How Does Blood Clot?, 2022-03-24): consulta indireta, por notas de leitura.
- B01-F5 (NHLBI, What Are Blood Clotting Disorders?, 2022-03-24): consulta indireta, por notas de leitura.
- Indisponível: B01-F1 (OpenStax), indicado no gabarito. Como as fontes fornecidas cobrem os seis pontos, essa ausência não impede a conferência. O gabarito não foi usado como evidência.

3. COBERTURA DOS SEIS PONTOS
| K | Nota | Trecho | Fonte | Justificativa |
|K1|100|"A agressão vascular provoca vasoconstrição… expondo colágeno, vWF e fator tecidual… Essa exposição é o evento inicial"|F3 Primary haemostasis, Clotting factors (TF); F4|O texto apresenta a mudança no vaso e explica por que ela inicia a resposta.|
|K2|100|Adesão vWF–GpIb; mudança de forma e degranulação; ADP–GpIIb/IIIa–fibrinogênio; TxA2|F3 Platelet adhesion/secretion/aggregation; F2 Platelets|As três etapas estão corretas e ligadas ao tampão.|
|K3|100|TF/VIIa→IX, X; amplificação V/VIII; protrombinase; trombina→fibrina e XIII|F3 Current concept, Common pathway|A sequência até a trombina e a fibrina está correta.|
|K4|100|"XIII ativado liga covalentemente… tampão fornece a superfície… coagulação fornece a rede"|F3 Stabilization; F4|Explica a estabilização e a integração entre hemostasia primária e secundária.|
|K5|100|Antitrombina, TFPI, proteína C/S; tPA→plasmina degrada fibrina; α2-antiplasmina|F3 Anticoagulants, Fibrinolytic system; F2 Regulation|Reguladores e fibrinólise estão corretos e são distinguidos entre si.|
|K6|100|"A trombose ocorre quando o controle falha… mesmo sem lesão aparente… comprometer órgãos… TVP"|F5; F3 Introduction|A distinção entre hemostasia fisiológica e trombose está presente e correta. O trecho acessório sobre "proporcionais" (A31) fica pendente, mas não compromete o núcleo do ponto.|

4. INVENTÁRIO DE AFIRMAÇÕES
São 45 afirmações. Dessas, 43 estão sustentadas, nenhuma foi contradita e 2 não são verificáveis (A31 e A43). O detalhamento de cada uma está em items. Observações:
- A14 (ADP altera GpIIb/IIIa): a mudança conformacional está sustentada por F3; a ponte de fibrinogênio, por F2 e F3.
- A21 (correção de "TF-VIIIa"): está correta, pois o trecho aparece assim em F3, que em outros pontos traz TF-VIIa, e F2 descreve TF/VIIa.
- A33 ("não é a natureza do coágulo, mas a localização e o controle"): li como interpretação compatível com F5 ("localização e controle da resposta importam").
- A37: a antitrombina neutraliza a trombina e também Xa e outros fatores; descrevê-la como restrição da produção de trombina é uma simplificação aceitável, sem falsidade.

5. VÍNCULOS
São 41 vínculos declarados. Dessas, 39 são válidos e 2 não são verificáveis: V31 (A31–F3) e V37 (A43–F3). Nesses dois casos, F3 existe e sustenta a parte factual (vasoespasmo e exposição do TF após a lesão), mas não os qualificadores "proporcionais" e "limitam a resposta". Por isso registrei os vínculos como não verificáveis, e não como associação falsa.
Lista final de fontes: as quatro referências correspondem ao material fornecido, com consulta indireta declarada para F2, F4 e F5. A seção "Fibrinolytic system" citada para F3 existe no texto incorporado. Nenhuma fonte é inventada e não há referência solta.

6. RESUMO
| C1 | C2 | C3 | Numeradores/denominadores | Erros centrais | Erros localizados | Omissões essenciais | Pendências |
|100,00|N/A (parcial 43/45 = 95,56)|N/A (parcial 39/41 = 95,12)|K: 600/6; A: 43 sustentadas, 0 contraditas, 2 N/V de 45; V: 39 válidos, 0 problemas, 2 N/V de 41|0|0|0|A31/V31 e A43/V37|

7. SITUAÇÃO CIENTÍFICA: PENDENTE
Os seis pontos estão cobertos corretamente e não há erro científico nem bibliográfico confirmado. Duas afirmações, porém, atribuem aos eventos vasculares um papel de proporcionalidade ou de limitação da resposta que as fontes fornecidas não sustentam. Pelo protocolo, APTO exige que todas as afirmações relevantes tenham sido conferidas. Por isso a situação é PENDENTE, até que essas afirmações sejam corrigidas ou sustentadas por fonte adequada.