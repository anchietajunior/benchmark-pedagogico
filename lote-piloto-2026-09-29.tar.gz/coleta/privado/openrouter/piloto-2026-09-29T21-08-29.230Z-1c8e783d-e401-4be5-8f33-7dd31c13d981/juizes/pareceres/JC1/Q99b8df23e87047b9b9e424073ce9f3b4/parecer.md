## 1. Identificação e integridade do pacote
- Protocolo 3.2; código Q99b8df23e87047b9b9e424073ce9f3b4; tema B02; rodada 1; passagem JC1.
- O pacote contém uma única resposta, sem autoria explícita e sem dados operacionais. O pedido, o gabarito e o material bibliográfico estão presentes. Integridade: OK.

## 2. Fontes lidas e indisponíveis
Leitura feita em 2026-09-29, somente do material incorporado ao pacote:
- **B02-F3** (Marshall et al., 2018, AACI 14(Suppl 2):49): li as notas de leitura e o texto original em inglês das seções "The immune system: innate and adaptive immunity" (com Innate immunity, Adaptive immunity, T cells and APCs e B cells), "Antibody-mediated vs. cell-mediated immunity" e "Passive vs. active immunization". As tabelas vieram convertidas em texto; as figuras não foram incorporadas.
- **B02-F4** (Bugya et al., 2021, Vaccines 9(2):174): li as notas de leitura e o texto original das seções 1, 7 (inclusive "Consequences on Vaccination"), 11, 13 e 14. Figuras e tabelas não foram incorporadas.
- **B02-F5** (Clem, 2011, JGID 3(1):73): consulta indireta, apenas pelas notas de leitura; o texto original não foi incorporado.
- **Indisponíveis:** B02-F1 e B02-F2 (Janeway e Alberts), indicadas no gabarito. Por isso a conferência usa somente F3-F5, que cobrem os seis pontos.

## 3. Cobertura dos seis pontos (K)
| K | Nota | Trecho | Fonte e localização | Justificativa |
|---|---|---|---|---|
| K1 | 100 | Definição de antígeno; resposta inata com receptores de reconhecimento de padrões e citocinas; APC com MHC I/II (Conceitos; Passo 1) | F3: Innate immunity; T cells and APCs. F5: notas | Correto e suficiente |
| K2 | 100 | O B reconhece o antígeno nativo, diferencia-se em plasmócito ou em B de memória; funções dos anticorpos (Passo 2) | F3: B cells; Antibody-mediated | Correto |
| K3 | 100 | O CD4+ reconhece MHC II, não mata e coordena por citocinas; o CD8+ reconhece MHC I e induz apoptose (Passo 3) | F3: T cells and APCs | Correto |
| K4 | 100 | Expansão clonal, morte da maioria das efetoras e permanência de células de memória (Passo 4) | F3; F5 | Correto |
| K5 | 100 | Resposta secundária mais rápida e de melhor qualidade; memória distinta do anticorpo circulante (Passos 4 e 5; Confusão 1) | F4, seção 7 | Correto |
| K6 | 100 | Imunização ativa sem doença; limites como anticorpo alto sem proteção garantida, velocidade do patógeno, variantes, idade e ADE (Passo 6) | F4, seções 1, 7, 13 e 14; F5 | Correto |

## 4. Inventário de afirmações (A)
| ID | Trecho resumido | Situação | Nota | Fonte |
|---|---|---|---|---|
| A1 | Definição de antígeno com exemplos | Sustentada | 100 | F3, parágrafo inicial |
| A2 | Inata rápida, inespecífica, sem memória; receptores de padrões; mobiliza APC | Sustentada | 100 | F3: Innate |
| A3 | Adaptativa específica, mais lenta na primeira exposição, com memória | Sustentada | 100 | F3; F5 |
| A4 | Dendríticas fagocitam, processam e exibem peptídeos em MHC | Sustentada | 100 | F3; F5 |
| A5 | MHC I (peptídeo intracelular) → CD8; MHC II (extracelular) → CD4 | Sustentada | 100 | F3: T cells and APCs |
| A6 | TCR; BCR é anticorpo de superfície que reconhece antígeno nativo | Sustentada | 100 | F3: B cells; F4, seção 7 |
| A7 | Plasmócitos secretam anticorpos; memória = células de vida longa | Sustentada | 100 | F3; F4 |
| A8 | Inata produz citocinas que recrutam células e ativam APC | Sustentada | 100 | F3: Innate |
| A9 | Sem apresentação, o T dificilmente reconhece o antígeno | Sustentada | 100 | F3: "T cells require the action of APCs" |
| A10 | B reconhece sem APC e pode atuar como APC | Sustentada | 100 | F3: B cells |
| A11 | B ativado vira plasmócito ou B de memória; citocinas Th ajudam e orientam o tipo de anticorpo | Sustentada | 100 | F3 |
| A12 | Anticorpos neutralizam, opsonizam e ativam complemento | Sustentada | 100 | F3, Tabela 2 e Antibody-mediated |
| A13 | Plasmócitos de vida curta × de vida longa; B de memória é outra população | Sustentada | 100 | F3; F4, seção 7 |
| A14 | CD4 não mata; citocinas dirigem B, macrófagos e CTL | Sustentada | 100 | F3: "directing other cells…"; "many cell types" |
| A15 | CD8 induz apoptose de células infectadas ou tumorais | Sustentada | 100 | F3 |
| A16 | Expansão clonal gera efetoras | Sustentada | 100 | F3; F5 |
| A17 | Maioria das efetoras morre; poucas ficam como memória T e B | Sustentada | 100 | F3 (para T; para B, plasmócitos morrem e B de memória sobrevivem) |
| A18 | B e T de memória respondem e diferenciam-se rapidamente | Sustentada | 100 | F3; F4 |
| A19 | Memória não é anticorpo circulante | Sustentada | 100 | F3: B cells |
| A20 | Na reexposição: mais células; LLPC agem de imediato; memória prolifera em poucos dias | Sustentada | 100 | F4, seção 7 |
| A21 | Secundária mais rápida, melhor afinidade e isotipo, tipicamente IgG | Sustentada | 100 | F4, seção 7; F5 |
| A22 | B de memória reduzem o antígeno mínimo necessário; uso em reforços | Sustentada | 100 | F4, seção 7 |
| A23 | Vacina é imunização ativa sem doença | Sustentada | 100 | F4, seção 1; F5 |
| A24 | Vacina mobiliza inata/APC/MHC/T/B e gera anticorpos e memória | Sustentada | 100 | F4; F5 |
| A25 | Anticorpo elevado não garante proteção | Sustentada | 100 | F4, seção 7 |
| A26 | Proteção depende da velocidade de disseminação do patógeno | Sustentada | 100 | F4, seção 7 |
| A27 | Escape de variantes; idade, estado imune e comorbidades | Sustentada | 100 | F4, seções 7, 13 e 14 |
| A28 | ADE facilita a entrada do microrganismo | Sustentada | 100 | F4, seção 7 |
| A29 | Memória melhora a resposta, mas não dá proteção absoluta | Sustentada | 100 | F4 |
| A30 | Exemplo: etapas da resposta primária à vacina, consolidada em semanas | Sustentada | 100 | F4, seção 7; F3; F5 |
| A31 | Exemplo: anticorpos como primeira barreira; se ultrapassada, memória B/T gera nova onda | Sustentada | 100 | F4, seção 1 |
| A32 | Memória reduz a chance de doença grave | Sustentada | 100 | F4, seção 1: "protect against disease development" |
| A33 | Pode adoecer "se a dose for muito alta" | NÃO VERIFICÁVEL | N/A | Não há dose infectante nas fontes incorporadas |
| A34 | Pode adoecer por disseminação rápida, variante ou imunidade enfraquecida | Sustentada | 100 | F4, seções 7 e 13 |
| A35 | Confusão 1: anticorpo é proteína; memória é célula; anticorpo não mede toda a memória | Sustentada | 100 | F3; F4 (correlatos distintos) |
| A36 | Confusão 2: fatores que condicionam a proteção; ADE | Sustentada | 100 | F4, seção 7 |
| A37 | Pergunta 1: resposta mais rápida por mais células de memória e LLPC | Sustentada | 100 | F4, seção 7 |
| A38 | Pergunta 2: memória pode proteger com poucos anticorpos, sem garantia | Sustentada | 100 | F4, seções 7 e 13 |
| A39 | Síntese 1 | Sustentada | 100 | F3 |
| A40 | Síntese 2 | Sustentada | 100 | F3; F4 |
| A41 | Síntese 3 | Sustentada | 100 | F4; F5 |

## 5. Vínculos bibliográficos (V)
- V1 a V46 são pares afirmação-fonte ligados às citações do texto. Todos são **VÁLIDOS** (100): cada fonte citada existe no pacote e sustenta a afirmação associada, conforme detalhado nos itens.
- **Lista de fontes:** F3, F4 e F5 estão corretas. Na F5, a consulta indireta está declarada. A nota sobre Janeway e Alberts é coerente com o pacote e não é uma referência falsa. Nenhum problema confirmado.

## 6. Resumo dos cálculos
| C1 | C2 | C3 | Numeradores/denominadores | Erros centrais | Erros localizados | Omissões essenciais | Pendências |
|---|---|---|---|---|---|---|---|
| 100,00 | N/A | 100,00 | C1 = 600/6; C2 = 40 sustentadas de 41, com 1 não verificável; C3 = 46/46 | 0 | 0 | 0 | A33 |

## 7. Situação científica: PENDENTE
Todos os pontos K1-K6 estão completos e corretos, e não há erro científico nem bibliográfico confirmado. Porém uma afirmação do limite do exemplo (A33, dose infectante muito alta) não pode ser conferida com as fontes fornecidas. Pelo protocolo, APTO exige que todas as afirmações relevantes estejam conferidas, sem pendência.