## 1. Identificação e integridade do pacote
Protocolo 3.2 | Código público Qe51c3bd51d7846aa8f6048ac0339a392 | Tema B01 | Rodada 1 | Passagem JC1.
O pacote contém uma única resposta anonimizada, sem autoria explícita nem dados operacionais. Ele também traz o pedido, o gabarito e o material bibliográfico. A integridade foi considerada adequada.

## 2. Fontes lidas e indisponíveis (acesso em 2026-09-29, somente material incorporado)
- **B01-F3** (Palta, Saroa e Palta, Indian J Anaesth 2014;58(5):515-523): li o corpo textual original em XML e inglês, com todas as seções, de Introduction a Summary. As imagens e tabelas não foram incorporadas e não foram inspecionadas. Também li a paráfrase em português.
- **B01-F2** (MSD Manual, Overview of Hemostasis, set. 2025): a consulta foi indireta, somente pelas notas de leitura das seções Platelets, Plasma Coagulation Factors e Regulation of Coagulation.
- **B01-F4** (NHLBI, How Does Blood Clot?, 2022-03-24): a consulta foi indireta, somente pelas notas de leitura.
- **B01-F5** (NHLBI, What Are Blood Clotting Disorders?, 2022-03-24): a consulta foi indireta, somente pelas notas de leitura.
- **B01-F1** (OpenStax), indicada no gabarito, não foi fornecida. Isso não gerou pendência, porque F2 a F5 sustentam os seis pontos. As notas indiretas são paráfrases feitas por IA e não foram revisadas por especialista. Essa limitação vale para toda conferência baseada em F2, F4 e F5.

## 3. Pontos K
| K | Nota | Trecho | Fonte | Justificativa |
|---|---|---|---|---|
| K1 | 100 | Vasoconstrição por reflexos, endotelina e TxA2; a ruptura expõe colágeno, vWF e fator tecidual | F3 Primary haemostasis, Clotting factors; F4 | Explica o que muda no vaso e por que isso inicia a resposta. |
| K2 | 100 | Adesão por vWF/GPIb; ativação com pseudópodes, grânulos, ADP e TxA2; agregação por GPIIb/IIIa e fibrinogênio | F3 Platelet adhesion/secretion/aggregation; F2 | As três etapas estão corretas e se conectam ao tampão. |
| K3 | 100 | Iniciação por TF/VIIa, amplificação e propagação; protrombinase; trombina converte fibrinogênio em fibrina | F3 Current concept, Common pathway | O texto é correto e fica no recorte. |
| K4 | 100 | O XIII faz ligações covalentes na fibrina; as fases "não são sequências isoladas" | F3 Stabilization, Aggregation; F4 | Explica a estabilização e a integração entre as fases. |
| K5 | 100 | TFPI, antitrombina, proteína C/S, prostaciclina; tPA→plasmina degrada fibrina; α2-antiplasmina, TAFI | F2 Regulation; F3 Anticoagulants, Fibrinolytic system | Os mecanismos e a fibrinólise estão corretos. |
| K6 | 100 | Gatilho, localização e temporalidade; trombose na circulação mesmo sem lesão aparente; TVP; desequilíbrio | F5; F4; F3 Intro | Distingue corretamente a hemostasia da trombose. |

## 4. Inventário de afirmações (todas conferidas)
| ID | Trecho resumido | Situação | Nota | Fonte |
|---|---|---|---|---|
| A1 | Etimologia e definição de hemostasia | Sustentada | 100 | F3 Intro |
| A2 | Vedar a lesão e manter o sangue fluido | Sustentada | 100 | F3 Summary; F5 |
| A3 | Endotélio íntegro produz NO e prostaciclina | Sustentada | 100 | F2; F3 Primary haem. |
| A4 | Subendotélio com colágeno e vWF, trombogênico | Sustentada | 100 | F3 |
| A5 | Plaquetas anucleadas, derivadas de megacariócitos; grânulos com ADP e Ca | Sustentada | 100 | F3 |
| A6 | Zimogênios e sufixo "a" | Sustentada | 100 | F3 Clotting factors |
| A7 | TF de membrana, não exposto ao sangue, iniciador in vivo | Sustentada | 100 | F3 |
| A8 | Trombina converte fibrinogênio solúvel em fibrina insolúvel | Sustentada | 100 | F3 |
| A9 | Vasoconstrição por reflexo, endotelina e TxA2 reduz a perda | Sustentada | 100 | F3; F4 |
| A10 | A ruptura expõe colágeno, vWF e TF | Sustentada | 100 | F3 |
| A11 | vWF faz ponte entre colágeno e GPIb | Sustentada | 100 | F3 |
| A12 | Mudança de forma, pseudópodes, degranulação; ADP e TxA2 recrutam plaquetas | Sustentada | 100 | F3 |
| A13 | GPIIb/IIIa liga fibrinogênio e une plaquetas vizinhas | Sustentada | 100 | F2; F3 |
| A14 | Tampão temporário (hemostasia primária) | Sustentada | 100 | F3 |
| A15 | Fosfolipídios e cálcio formam a superfície de montagem | Sustentada | 100 | F3 Platelet secretion |
| A16 | Iniciação: TF/VIIa ativa IX e X; pouca trombina; TFPI termina | Sustentada | 100 | F3 Initiation |
| A17 | Amplificação: trombina ativa plaquetas, V e VIII | Sustentada | 100 | F3 Amplification |
| A18 | Propagação: protrombinase Xa/Va/PL/Ca e muita trombina | Sustentada | 100 | F3 Propagation, Common pathway |
| A19 | Lógica de multiplicação e retroalimentação dependente de superfície | Sustentada | 100 | F3 Intro, Amplification, Coagulation cascade |
| A20 | XIII faz ligação covalente da fibrina (hemostasia secundária) | Sustentada | 100 | F3 Stabilization |
| A21 | A rede retém hemácias; a contração aproxima as bordas | Sustentada | 100 | F4 |
| A22 | Integração plaquetas–trombina–fibrina | Sustentada | 100 | F3 |
| A23 | Falta de plaquetas ou fatores compromete a contenção | Sustentada | 100 | F4 |
| A24 | O equilíbrio prostaciclina/TxA2 localiza a agregação | Sustentada | 100 | F3 |
| A25 | TFPI restringe Xa e TF/VIIa | Sustentada | 100 | F2 |
| A26 | Antitrombina, potencializada por moléculas heparina-símiles endoteliais | Sustentada | 100 | F2; F3 Antithrombin |
| A27 | Trombomodulina→proteína C; com S, inativa Va e VIIIa | Sustentada | 100 | F2; F3 Protein C |
| A28 | A mesma trombina freia sobre o endotélio sadio | Sustentada | 100 | F3 Thrombomodulin |
| A29 | tPA→plasmina degrada fibrina | Sustentada | 100 | F2; F3 Fibrinolytic |
| A30 | α2-antiplasmina inibe plasmina; TAFI protege o coágulo | Sustentada | 100 | F3 |
| A31 | O equilíbrio entre formação e remoção mantém a vedação | Sustentada | 100 | F2 |
| A32 | Critérios: gatilho, localizada, temporária | Sustentada | 100 | F4; F5 |
| A33 | Trombose na circulação, mesmo sem lesão; compromete órgãos; TVP | Sustentada | 100 | F5; F3 (patência do lúmen) |
| A34 | Mais atividade pró-coagulante ou menos inibidores desequilibram | Sustentada | 100 | F3 Intro |
| A35 | Etapas do exemplo do corte | Sustentada | 100 | F3; F4; F2 |
| A36 | Interpretação e limite do exemplo | Sustentada | 100 | F2; F3; F5 |
| A37 | Confusão 1: o tampão sozinho é temporário | Sustentada | 100 | F3; F4 |
| A38 | Confusão 2: inibir formação é diferente de degradar fibrina | Sustentada | 100 | F2 |
| A39 | Deficiência de AT ou proteína C aumenta o risco de trombose | Sustentada | 100 | F3 Thrombotic disorders; F2 |
| A40 | Pouca fibrina deixa o tampão frágil | Sustentada | 100 | F3; F4 |
| A41 | Síntese com três itens | Sustentada | 100 | F3; F2; F5 |

Observação sobre A16: a frase "que o TFPI consegue bloquear" tem referente pouco preciso. A fonte diz que o TFPI termina a geração de trombina. O trecho não foi classificado como falso, porque F2 sustenta que o TFPI restringe Xa e TF/VIIa.

## 5. Vínculos
V1 a V37 correspondem aos colchetes declarados pela resposta. Cada vínculo foi avaliado pelo conjunto de fontes indicado. Todos são válidos: V1 A1-F3; V2 A2-F3/F5; V3 A3-F2/F3; V4 A4; V5 A5; V6 A6; V7 A7; V8 A8; V9 A9-F3/F4; V10 A10; V11 A11; V12 A12; V13 A13-F2/F3; V14 A14; V15 A15; V16 A16; V17 A17; V18 A18; V19 (conversão fibrinogênio→fibrina, parágrafo de A19)-F3; V20 A20; V21 A21-F4; V22 A22; V23 A23-F4; V24 A24-F2/F3; V25 A25-F2; V26 A26; V27 A27; V28 A29; V29 A30; V30 A31-F2; V31 A32-F4/F5; V32 A33-F5; V33 A34-F3; V34 A37; V35 A38-F2; V36 A39; V37 A40.
Na lista de fontes, conferi V38 a V41, relativos a F3, F2, F4 e F5. Os quatro itens existem no pacote, com título, data e endereço corretos. As consultas indiretas estão declaradas corretamente para F2, F4 e F5. Para F3, as seções listadas estão presentes no XML fornecido. Não há fonte inventada nem item solto.

## 6. Resumo
| C1 | C2 | C3 | Numeradores/denominadores | Erros centrais | Erros localizados | Omissões essenciais | Pendências |
|---|---|---|---|---|---|---|---|
| 100,00 | 100,00 | 100,00 | C1 600/6; C2 41/41; C3 41/41 | 0 | 0 | 0 | 0 |

## 7. Situação científica
**APTO.** K1 a K6 receberam 100 e todas as afirmações foram sustentadas pelas fontes incorporadas. Nenhum dos alertas de erro central do gabarito foi observado. A resposta não afirma que plaquetas viram fibrina nem que a trombina dissolve fibrina. Também não trata a coagulação total como objetivo. Não há referências falsas nem pendências. A conferência de F2, F4 e F5 dependeu de notas indiretas. APTO não garante verdade absoluta nem substitui revisão especializada.