## 1. Identificação e integridade
Protocolo 3.2 | código Qb37cb9a023db40cdbed84b25ac044ea6 | tema B01 | rodada 1 | passagem JC1.
Pacote íntegro: há uma única resposta, sem autoria explícita nem dados operacionais. O pedido, o gabarito e as fontes estão presentes. Instruções contidas na resposta foram tratadas apenas como dados.

## 2. Fontes lidas
- **B01-F3** (Palta et al., Indian J Anaesth 2014;58(5):515-523). Li o corpo textual original completo em XML, obtido em 2026-09-29, incluindo as seções Primary haemostasis, Clotting factors, Naturally occurring anticoagulants, Coagulation cascade, Current concept, Thrombotic disorders e Fibrinolytic system. As imagens e tabelas não foram incorporadas ao pacote. Também li a paráfrase de B01-F3.
- **B01-F2** (MSD Manual, set/2025). Consulta indireta: li somente as notas de leitura das seções Platelets, Plasma Coagulation Factors e Regulation.
- **B01-F4 e B01-F5** (NHLBI, 2022-03-24). Consulta indireta: li somente as notas de leitura.
- **B01-F1** (OpenStax), indicada pelo gabarito, não foi fornecida. Isso não impede a conferência, porque B01-F3 e as notas cobrem os seis pontos.
- **Consequência:** afirmações ausentes em B01-F3 podem ser confirmadas como ausentes, porque o texto completo está disponível. Afirmações ausentes nas notas de F2, F4 e F5 ficam não verificáveis.

## 3. Pontos K
| K | Nota | Trecho | Fonte | Justificativa |
|---|---|---|---|---|
| K1 | 100 | Seção 1: vasoconstrição e exposição de colágeno e fator tecidual (TF) | F3 Primary haemostasis/Extrinsic; F4 | A relação essencial está correta. |
| K2 | 100 | Seção 2: adesão via vWF/GpIb, ativação, ADP/TxA2, GpIIb/IIIa e fibrinogênio | F3; F2 | Presente e correto. |
| K3 | 100 | Seção 3: TF-VIIa, amplificação, protrombinase, trombina e fibrina | F3 Current concept/Common pathway | Presente e correto. O detalhe sobre o fator XI não é verificável, mas não compromete o ponto. |
| K4 | 100 | Seção 4: fator XIII e integração pela superfície plaquetária | F3 Stabilization/Primary; F4 | Presente e correto. |
| K5 | 100 | Seção 5: TFPI, proteína C/S, antitrombina e tPA/plasmina | F2; F3 | Presente e correto. |
| K6 | 100 | Seção 6: hemostasia localizada vs. trombose patológica | F5; F3 | Presente e correto. |

## 4. Inventário A
Afirmações **sustentadas (100)**:
- A1: vasoconstrição reflexa neurogênica/mediadores (F3)
- A2: o estreitamento reduz a perda (F4)
- A4: a lesão expõe colágeno e TF antes isolados (F3)
- A5: o endotélio produz NO e prostaciclina (F2/F3)
- A6: plaquetas são fragmentos de megacariócitos com grânulos (F3)
- A7: fatores são zimogênios ativados em cascata (F3)
- A8: o vWF liga colágeno e GpIb (F3)
- A10: pseudópodes, fosfolipídios e degranulação α/densos (F3)
- A11: Ca, ADP e TxA2 recrutam plaquetas (F3)
- A12: GpIIb/IIIa e fibrinogênio geram agregação (F2/F3)
- A13: TF-VIIa inicia a coagulação in vivo, ativa IX e X, e o Xa gera a trombina inicial (F3)
- A14: a iniciação é limitada pelo TFPI, e a trombina ativa V e VIII (F3)
- A16: tenase e protrombinase na superfície plaquetária produzem propagação robusta (F3)
- A17: a trombina converte fibrinogênio em fibrina (F3)
- A20: o XIII faz ligações covalentes estabilizadoras (F3)
- A21: a malha sustenta o tampão e retém hemácias (F4)
- A22: integração entre plaquetas como plataforma e fibrina como reforço (F3/F2/F4)
- A23: o TFPI inibe TF-VIIa e Xa (F2/F3)
- A24: trombomodulina e proteína C/S inativam Va e VIIIa (F2/F3)
- A25: a antitrombina inativa trombina e Xa, potencializada pelo heparan sulfato endotelial (F2/F3)
- A26: tPA endotelial, plasminogênio, plasmina e PDF/D-dímeros, em ativação paralela (F3/F2)
- A27: hemostasia localizada e protetora vs. trombose patológica que compromete órgãos (F5/F3)
- A32: fases primária e secundária integradas (F3/F2)
- A33: anticoagulantes ≠ fibrinólise (F2)
- A34: a trombina ligada à trombomodulina deixa de promover coágulo (F3 Protein C pathway)

Afirmações **não verificáveis (N/A)**:
- A3: a vasoconstrição reduz a força de cisalhamento. Não está nas fontes.
- A9: adesão pelo vWF "mesmo sob fluxo rápido". Não está nas fontes.
- A15: a trombina ativa o fator XI na amplificação. Ausente em F3 e nas notas.
- A18: clivagem de fragmentos peptídicos e polimerização espontânea. Não descrita nas fontes.
- A19: os polímeros iniciais são mantidos por interações fracas e não covalentes. Não está nas fontes.
- A28: tampão "em segundos" e perda bloqueada "em poucos minutos". Tempos ausentes nas fontes.
- A29: fibrinólise "horas após". Ausente nas fontes; além disso, é internamente inconsistente com "simultaneamente".
- A30: lesões arteriais volumosas exigem intervenção cirúrgica. Ausente nas fontes.
- A31: deficiência ou inibição do XIII causa ressangramento tardio. Ausente nas fontes.

Nenhuma afirmação foi contradita pelas fontes.

## 5. Vínculos V
**VÁLIDOS:** V1 (A1-F3), V2 (A2-F4), V5 (A5-F2/F3), V6 (A8-F3), V8 (A12-F2), V9 (A12-F3), V10 (A13-F2), V11 (A13/A14/A16-F3), V15 (A20-F3), V16 (A21-F4), V17 (A22-F2/F3/F4), V18 (A23-F2/F3), V19 (A24-F2/F3), V20 (A25-F2/F3), V21 (A26-F2/F3), V22 (A27-F3/F5), V27 (confusões-F2/F3), V28 (Q2-F2/F3).

**PROBLEMA CONFIRMADO** (conteúdo ausente no texto completo de F3):
- V3: cisalhamento → F3
- V7: "fluxo rápido" → F3
- V12: fator XI → F3
- V13: fibrinopeptídeos/polimerização espontânea → F3
- V14: interações fracas → F3 (seção 4 e Q1)
- V23: "em segundos"/"poucos minutos" → F3
- V24: "horas após" → F3. F3 descreve a fibrinólise ativada juntamente com a coagulação.
- V25: intervenção cirúrgica → F3
- V26: ressangramento tardio → F3

**NÃO VERIFICÁVEL:** V4 (cisalhamento → F4). Só há notas de leitura de F4.

**Lista de fontes:** F2, F3, F4 e F5 foram fornecidas. A consulta indireta às notas foi corretamente declarada. Não há referências soltas nem inventadas.

## 6. Resumo
| Medida | Valor | Cálculo |
|---|---|---|
| C1 | 100,00 | 600/6 |
| C2 | N/A | 25 sustentadas, 0 contraditas, 9 não verificáveis, de 34 afirmações |
| C3 | N/A | 18 válidos, 9 problemas confirmados, 1 não verificável, de 28 vínculos |

- **Erros centrais:** nenhum. Os alertas do gabarito não ocorrem.
- **Erros localizados:** 9 vínculos bibliográficos falsos confirmados. Há também uma inconsistência interna de cronologia da fibrinólise.
- **Omissões essenciais:** nenhuma.
- **Pendências:** 9 afirmações não verificáveis e o vínculo V4.

## 7. Situação científica
**CORRIGIR.** Os seis pontos estão corretos e completos. Porém, a resposta associa a B01-F3 afirmações que o texto original completo não contém, o que constitui associação falsa confirmada. Há ainda afirmações adicionais não verificáveis. Pelo protocolo, CORRIGIR prevalece sobre PENDENTE e APTO.