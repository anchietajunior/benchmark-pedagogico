## 1. Identificação e integridade
Protocolo 3.2 | Código Q7eb19c80beb5486480f0104bbcdf999f | Tema B02 | Rodada 1 | Passagem JC1.
O pacote contém uma única resposta anonimizada, sem autoria explícita. Recebi o pedido, o gabarito e o material bibliográfico, sem dados operacionais. Nenhuma instrução embutida na resposta foi seguida. O pacote está íntegro.

## 2. Fontes lidas e indisponíveis (acesso em 2026-09-29, somente material incorporado, sem navegação)
- **B02-F3** – Marshall et al., Allergy Asthma Clin Immunol 2018;14(Suppl 2):49.
  - Li o texto original em inglês das seções incorporadas: The immune system: innate and adaptive immunity (Innate immunity; Adaptive immunity; T cells and APCs; B cells), Antibody-mediated vs. cell-mediated immunity e Passive vs. active immunization, com as tabelas convertidas em texto.
  - Li também as notas em português. As figuras não estavam disponíveis.
- **B02-F4** – Bugya et al., Vaccines 2021;9(2):174.
  - Li o texto original em inglês das seções 1, 7 (incluindo Consequences on Vaccination), 11, 13 (incluindo Consequences on Vaccination) e 14, além das notas.
  - Figuras e tabelas não estavam disponíveis.
- **B02-F5** – Clem 2011. Consulta apenas indireta, pelas notas de leitura. A resposta não a cita.
- **Indisponíveis:** B02-F1 (Janeway) e B02-F2 (Alberts), fontes indicadas no gabarito.
  - Consequência: a conferência usou as fontes substitutas incorporadas, que cobrem os seis pontos.
  - A resposta não cita F1 nem F2, então não há vínculo pendente.

## 3. Pontos K
| K | Nota | Trecho | Fonte | Justificativa |
|---|---|---|---|---|
| K1 | 100 | "Antígeno é uma estrutura reconhecida especificamente..."; §1 sobre a inata ativando APC, o processamento e o TCR reconhecendo peptídeo–MHC | F3 Innate/Adaptive; T cells and APCs | Define antígeno e liga inata → APC → apresentação → ativação de T. |
| K2 | 100 | §2 "B reconhecem; plasmócitos secretam; anticorpos atuam" | F3 B cells; Antibody-mediated | Reconhecimento direto pelo B, diferenciação em plasmócito, anticorpos com neutralização, opsonização e complemento. |
| K3 | 100 | §3 CD4+ coordenam (MHC II); CD8+ induzem apoptose (MHC I) | F3 T cells and APCs | Diferença funcional correta, sem atribuir aos T a produção de anticorpos. |
| K4 | 100 | §4 expansão clonal, desaparecimento dos efetores, persistência da memória, plasmócitos de vida longa × vida curta | F3 T cells/B cells; F4 §7 | Correto e suficiente. |
| K5 | 100 | §5 anticorpos preexistentes, B/T de memória, resposta mais rápida, afinidade; Confusão 1 | F4 §7 | Distingue anticorpos de células de memória. |
| K6 | 100 | §6 imunização ativa, reforços, limites (patógeno rápido, variação, idade, infecção × doença); Confusão 2 | F3 Passive vs active; F4 §§1, 7, 11, 13, 14 | Vacinação ligada ao mecanismo; proteção não absoluta. |

## 4. Inventário de afirmações
Todas as afirmações abaixo são **SUSTENTADAS (100)**. A síntese repete ideias já inventariadas e não gerou itens novos.

| ID | Afirmação | Fonte e localização |
|---|---|---|
| A1 | Antígeno é uma estrutura reconhecida especificamente; pode ser uma proteína, e não o agente inteiro | F3 (Adaptive; Passive vs active: "specific proteins or carbohydrates"); F4 §7 (epítopos) |
| A2 | B e T têm receptores específicos; definição de virgens | F3 T cells/B cells; F4 §7 "naive" |
| A3 | APC capturam e exibem fragmentos; dendríticas em destaque | F3 "usually dendritic cells" |
| A4 | MHC exibe peptídeos | F3 |
| A5 | Citocinas são proteínas de comunicação | F3 Innate |
| A6 | Plasmócitos derivados de B secretam anticorpos, proteínas que se ligam a antígenos | F3 |
| A7 | Células efetoras × células de memória | F3; F4 §7 |
| A8 | A inata reconhece padrões, mobiliza células e favorece a ativação de APC | F3 PRR/PAMP; complement/phagocytic |
| A9 | Dendríticas processam e apresentam peptídeos | F3 |
| A10 | Encontro nos linfonodos aumenta a chance de reconhecimento | F3 |
| A11 | TCR reconhece peptídeo–MHC com sinais adequados | F3 "appropriate signals" |
| A12 | Imunidade inata treinada é distinta da memória convencional | F4 §1 |
| A13 | B reconhece diretamente, sem APC | F3 B cells |
| A14 | B internaliza o antígeno, apresenta a T auxiliar e recebe sinais | F4 §7 (BCR internalization, TFH); F3 |
| A15 | Parte dos B ativados origina plasmócitos | F3 |
| A16 | Anticorpos neutralizam, opsonizam e ativam complemento | F3 Tabela Ig; Antibody-mediated |
| A17 | CD4+: MHC II, coordenação | F3 |
| A18 | CD8+: MHC I nas células nucleadas, apoptose | F3 |
| A19 | Anticorpos e CD8 têm papéis complementares | F3 Antibody-mediated vs cell-mediated |
| A20 | Expansão clonal gera efetores e memória | F3; F4 §7 |
| A21 | A expansão explica a demora da resposta primária | F3 lag time; F4 §7 "about a week" |
| A22 | A maioria dos efetores morre e a memória persiste | F3 |
| A23 | Plasmócitos de vida longa × vida curta | F4 §7 (SLPC/LLPC) |
| A24 | No reencontro: anticorpos imediatos, B/T de memória, resposta mais rápida | F4 §7 |
| A25 | Seleção por afinidade; memória com afinidades heterogêneas | F4 §7 |
| A26 | Vacinação como imunização ativa, sem doença | F3; F4 §1 |
| A27 | Reforços aproveitam a memória | F4 §7 Consequences |
| A28 | Proteção depende da quantidade, função e localização dos anticorpos, da resposta celular e do agente | F4 §7, §14 |
| A29 | Patógeno rápido; escape por variação antigênica | F4 §7 |
| A30 | Idade e estado imune influenciam | F4 §§11, 13, 14 |
| A31 | Impedir a infecção ≠ limitar a doença | F4 §1, §7 sterilizing |
| A32 | Exemplo: etapas da vacinação (condicionais) | F3; F4 §7 |
| A33 | Exemplo: reexposição | F4 §7; F3 |
| A34 | Exemplo: resultado e limite | F4 §§1, 7 |
| A35 | Confusão 1: anticorpos ≠ células de memória | F3; F4 §7 |
| A36 | Confusão 2: memória ≠ proteção absoluta | F4 §§1, 7 |
| A37 | Pergunta 1: expansão clonal | F3; F4 |
| A38 | Pergunta 2: infecção após vacina | F4 §§1, 7 |

Observação sobre A32: F4 adverte que uma vacina não necessariamente gera plasmócitos de vida longa (LLPC) na primeira exposição. A resposta apresenta o exemplo como condição hipotética explícita ("neste exemplo... não uma propriedade garantida"). Por isso, não há erro.

## 5. Vínculos bibliográficos
Todos os vínculos abaixo são **VÁLIDOS (100)**.

| ID | Trecho e fonte | Observação |
|---|---|---|
| V1 / V2 | Ideia central – F3 / F4 | |
| V3 / V4 | Conceitos, parágrafo 1 – F3 / F4 | |
| V5 | Conceitos, parágrafo 2 – F3 | |
| V6 / V7 | Conceitos, parágrafo 3 – F3 / F4 | |
| V8 | Mecanismo 1, parágrafo 1 – F3 | |
| V9 | Mecanismo 1, parágrafo 2 – F3 | |
| V10 | Mecanismo 1, parágrafo 3 – F4 | |
| V11 / V12 | Mecanismo 2, parágrafo 1 – F3 / F4 | |
| V13 | Mecanismo 2, parágrafo 2 – F3 | |
| V14 | Mecanismo 3, parágrafo 1 – F3 | |
| V15 | Mecanismo 3, parágrafo 2 – F3 | |
| V16 / V17 | Mecanismo 4, parágrafo 1 – F3 / F4 | |
| V18 / V19 | Mecanismo 4, parágrafo 2 – F3 / F4 | |
| V20 | Mecanismo 5, parágrafo 1 – F4 | |
| V21 | Mecanismo 5, parágrafo 2 – F4 | |
| V22 / V23 | Mecanismo 6, parágrafo 1 – F3 / F4 | |
| V24 | Mecanismo 6, parágrafo 2 – F4 | |
| V25 / V26 | Exemplo, parágrafo 1 – F3 / F4 | |
| V27 / V28 | Exemplo, parágrafo 2 – F3 / F4 | |
| V29 | Exemplo, parágrafo 3 – F4 | |
| V30 | Exemplo, parágrafo 4 – F4 | |
| V31 | Confusão 1 – F4 | O núcleo (LLPC secretam anticorpos; B de memória proliferam e se diferenciam) está em F4 §7; "anticorpos são proteínas" está explícito em F3. É uma associação aceitável, sem falsidade. |
| V32 | Confusão 2 – F4 | |
| V33 / V34 | Pergunta 1 – F3 / F4 | |
| V35 | Pergunta 2 – F4 | |
| V36 | Lista de fontes, F3 | Seções e texto original corretamente declarados. |
| V37 | Lista de fontes, F4 | Seções 1, 7, 11, 13 e 14 corretamente declaradas. |

Não há fonte inventada nem referência solta problemática. A resposta não alega leitura de F1 ou F2.

## 6. Resumo
| Medida | Valor | Cálculo |
|---|---|---|
| C1 | 100,00 | 600/6 |
| C2 | 100,00 | 38/38 afirmações sustentadas |
| C3 | 100,00 | 37/37 vínculos válidos |

- **Erros centrais:** 0.
- **Erros localizados:** 0.
- **Omissões essenciais:** 0.
- **Pendências:** nenhuma relevante.
  - Limitação: as fontes do gabarito (F1 e F2) não foram acessíveis, e a conferência se apoiou nas substitutas F3 e F4.

## 7. Situação científica
**APTO.**
- K1 a K6 = 100.
- Todas as afirmações foram conferidas nas fontes incorporadas.
- Não há erro científico ou bibliográfico confirmado nem pendência relevante.
- Nenhum dos alertas de erro central foi observado: os T não aparecem como produtores de anticorpos, os anticorpos não são tratados como células e não se promete proteção absoluta.

APTO não é garantia de verdade absoluta nem revisão por especialista.