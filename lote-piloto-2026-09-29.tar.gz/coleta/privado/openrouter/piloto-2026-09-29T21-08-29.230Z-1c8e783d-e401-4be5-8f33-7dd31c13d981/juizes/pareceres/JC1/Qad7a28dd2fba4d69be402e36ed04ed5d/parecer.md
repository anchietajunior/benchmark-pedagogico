1) IDENTIFICAÇÃO E INTEGRIDADE
Protocolo 3.2 | código Qad7a28dd2fba4d69be402e36ed04ed5d | tema B01 | rodada 1 | passagem JC1.
O pacote está íntegro: há uma única resposta anonimizada, sem autoria explícita nem dados operacionais. Nenhuma instrução embutida na resposta tentou alterar o julgamento.

2) FONTES LIDAS E INDISPONÍVEIS (acesso em 2026-09-29, somente material incorporado)
- B01-F3, Palta, Saroa & Palta, Indian J Anaesth 2014;58(5):515-523. Li o corpo textual original em XML (inglês), com todas as seções incorporadas: Introduction, Primary haemostasis (Platelet adhesion/secretion/aggregation), Coagulation disorders involving primary hemostasis, Coagulation pathways, Clotting factors, Naturally occurring anticoagulants, Coagulation cascade (extrinsic/intrinsic/common), Current concept (initiation/amplification/propagation/stabilization), Disorders, Thrombotic disorders, Fibrinolytic system, Disorders of fibrinolysis, Summary. Também li a paráfrase em português. Não inspecionei as imagens nem as tabelas, que não estavam incorporadas.
- B01-F2, MSD Manual Professional, Overview of Hemostasis (Streiff/Emadi, set. 2025). Consulta indireta: somente a nota de leitura redigida por IA (seções Platelets, Plasma Coagulation Factors, Regulation of Coagulation).
- B01-F4, NHLBI, How Does Blood Clot? (2022-03-24). Consulta indireta: somente a nota de leitura.
- B01-F5, NHLBI, What Are Blood Clotting Disorders? (2022-03-24). Consulta indireta: somente a nota de leitura.
- Indisponível: B01-F1 (OpenStax), indicado no gabarito mas não fornecido. Consequência: os pontos que o gabarito atribui a F1 foram conferidos com F2 a F5. O gabarito não foi usado como evidência independente.

3) COBERTURA K1-K6
| K | Nota | Trecho | Fonte | Justificativa |
| K1 | 100 | Passo 1: exposição subendotelial (colágeno, vWF, fator tecidual) e vasoconstrição que reduz a perda; 'perda da superfície antitrombótica' | F3 Primary haemostasis; F4; F2 | Relação essencial correta e suficiente. O acréscimo não verificável sobre 'aproximar bordas' não constitui erro científico confirmado no ponto (ver A13/V12). |
| K2 | 100 | Passo 2: vWF–GPIb, mudança de forma, degranulação, ADP/TxA2, fibrinogênio–IIb/IIIa | F3 sec2-1 a 2-3; F2 | Adesão, ativação e agregação estão corretas e conectadas. |
| K3 | 100 | Passo 3: FT-VIIa, amplificação, propagação, protrombinase, trombina→fibrina, XIII | F3 Current concept; Common pathway | Correto. |
| K4 | 100 | Passo 4 e Confusão 1: rede de fibrina, ligações covalentes pelo XIIIa, integração primária/secundária | F3 Common pathway/Stabilization; F4 | Correto e integrado. |
| K5 | 100 | Passo 5: antitrombina, TFPI, proteína C/S, prostaciclina; tPA→plasmina degrada fibrina; inibidores | F3 Anticoagulants/Fibrinolytic; F2 | Correto. |
| K6 | 100 | Passo 6: hemostasia local versus coágulo na circulação que compromete órgãos; TVP | F5 | Correto. |

4) INVENTÁRIO DE AFIRMAÇÕES (47 itens): 44 SUSTENTADAS, 0 CONTRADITAS e 3 NÃO VERIFICÁVEIS (A13, A19, A44). O detalhe de cada afirmação está em items.
- A13: 'constrição... aproxima as bordas da lesão'. Nenhuma fonte fornecida sustenta esse efeito da vasoconstrição; F4 o atribui à contração plaquetária.
- A19: tampão 'relativamente frouxo e reversível'. F3 diz apenas 'seals off vascular injury temporarily'; não há menção à reversibilidade.
- A44: 'defeitos de plaquetas e defeitos de fatores... causam sangramentos de formas diferentes'. As fontes não descrevem padrões distintos de sangramento.
Não encontrei nenhum dos alertas de erro central: plaquetas que viram fibrina, trombina que dissolve fibrina ou coagulação total como objetivo fisiológico.

5) VÍNCULOS (43 vínculos distintos afirmação–fonte): 42 VÁLIDOS e 1 com PROBLEMA CONFIRMADO (V12: A13–B01-F4).
Lista final de fontes: as quatro referências existem no pacote e correspondem ao material fornecido. A consulta indireta às notas de F2, F4 e F5 está declarada. Em F3, as seções adicionais listadas (Coagulation cascade, Fibrinolytic system) estavam presentes no texto incorporado. Não há referências soltas inventadas.

6) RESUMO
| C1 | C2 | C3 | Numeradores/denominadores | Erros centrais | Erros localizados | Omissões essenciais | Pendências |
| 100,00 | N/A (parcial 44/47 = 93,62) | 97,67 | C1 = 600/6; C2 = 44 sustentadas/47, com 3 N/A; C3 = 42/43 | 0 | 1 bibliográfico (V12) | 0 | A13, A19, A44 não verificáveis; B01-F1 não fornecido |

7) SITUAÇÃO CIENTÍFICA: CORRIGIR.
K1-K6 = 100 e não há erro científico central. Mesmo assim, há uma associação bibliográfica falsa confirmada (V12), o que pelo protocolo exige CORRIGIR, e restam três afirmações não verificáveis. APTO não seria garantia de verdade absoluta. Este parecer não contém notas pedagógicas nem ranking.