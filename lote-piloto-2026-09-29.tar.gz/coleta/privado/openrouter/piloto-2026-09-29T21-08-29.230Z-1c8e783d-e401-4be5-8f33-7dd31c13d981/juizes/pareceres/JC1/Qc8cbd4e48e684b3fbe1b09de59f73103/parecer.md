## 1. Identificação e integridade
Versão 3.2 | código Qc8cbd4e48e684b3fbe1b09de59f73103 | tema B02 | rodada 1 | passagem JC1. O pacote contém uma única resposta anonimizada, sem autoria explícita, sem dados operacionais e sem instruções dirigidas ao juiz. A integridade é compatível com o julgamento.

## 2. Fontes lidas e indisponíveis (acesso em 2026-09-29, somente material incorporado)
- **B02-F3**, Marshall et al., Allergy Asthma Clin Immunol 2018;14(Suppl 2):49. Li o texto original em inglês das seções The immune system: innate and adaptive immunity (Innate immunity, Adaptive immunity, T cells and APCs, B cells), Antibody-mediated vs. cell-mediated immunity e Passive vs. active immunization, além das tabelas convertidas em texto e das notas em português. Não inspecionei figuras.
- **B02-F4**, Bugya et al., Vaccines 2021;9(2):174. Li o texto original das seções 1, 7 (inclusive Consequences on Vaccination), 11, 13 (inclusive Consequences on Vaccination) e 14, além das notas. Figuras e tabelas não foram incorporadas ao pacote.
- **B02-F5**, Clem, J Glob Infect Dis 2011;3(1):73. A consulta foi somente indireta, pelas notas de leitura redigidas por IA; o texto original não foi incorporado.
- **Indisponíveis:** B02-F1 (Janeway) e B02-F2 (Alberts), que o gabarito indica. A consequência é que a conferência depende das fontes substitutas F3-F5. Essas fontes bastam para os seis pontos. O gabarito não foi usado como evidência.

## 3. Pontos K
| K | Nota | Trecho/ausência | Fonte e localização | Justificativa |
|---|---|---|---|---|
| K1 | 100 | Define antígeno; a imunidade inata e as APC (células dendríticas, receptores de reconhecimento de padrões, fagocitose, peptídeo em MHC II) iniciam a resposta adaptativa | F3, Innate immunity; T cells and APCs | A relação essencial está correta. O detalhe da rota linfática ficou não verificável (A11), mas não afeta o núcleo do ponto. |
| K2 | 100 | Linfócito B reconhece o antígeno nativo; plasmócitos secretam anticorpos; neutralização, opsonização e complemento | F3, B cells; Antibody-mediated; F4, seção 7 | Correto e suficiente. |
| K3 | 100 | CD4+ reconhecem MHC II, não matam e agem por citocinas; CD8+ reconhecem MHC I e induzem apoptose | F3, T cells and APCs | Correto e suficiente. |
| K4 | 0 | "Esse processo multiplica clones idênticos" | F4, seção 7 (hipermutação somática produz clones de afinidades diferentes) | Há erro confirmado no ponto. O restante (expansão, morte da maioria das células efetoras, persistência das células de memória) está correto. |
| K5 | 100 | Na resposta secundária há mais células específicas, limiar menor, IgG de maior afinidade e células T efetoras em poucos dias | F4, seção 7; F3; F5 (notas) | Correto. A distinção entre anticorpos e células de memória aparece na Confusão 1. |
| K6 | 0 | "gerando plasmócitos de vida longa e células de memória" (como efeito geral); "A presença de células de memória garante rapidez de resposta" | F4, seção 7 Consequences on Vaccination; seções 11 e 13 | A seção de limites (variação antigênica, cinética do patógeno, idade) está correta, mas há duas generalizações contraditas pela fonte. |

C1 = (100+100+100+0+100+0)/6 = 400/6 = **66,67**.

## 4. Inventário de afirmações
Classificação: S = sustentada; C = contradita; NV = não verificável.

| ID | Trecho resumido | Situação | Nota | Fonte e localização |
|---|---|---|---|---|
| A1 | O sistema imune protege por defesas coordenadas | S | 100 | F3, abertura |
| A2 | Antígeno é uma estrutura estranha reconhecida por receptores de linfócitos | S | 100 | F3 (simplificação que omite antígenos próprios) |
| A3 | APC (células dendríticas, macrófagos) capturam, processam e exibem antígeno a T | S | 100 | F3 |
| A4 | MHC I em células nucleadas com peptídeos intracelulares; MHC II em APC com peptídeos extracelulares | S | 100 | F3 |
| A5 | B reconhecem o antígeno nativo por receptores de superfície | S | 100 | F3, B cells |
| A6 | Plasmócitos derivam de B ativados e secretam muitos anticorpos | S | 100 | F3 |
| A7 | Anticorpos são proteínas que neutralizam ou marcam o antígeno | S | 100 | F3, tabela Ig |
| A8 | T amadurecem no timo e reconhecem peptídeo-MHC pelo TCR | S | 100 | F3 |
| A9 | Inata age primeiro; células dendríticas usam receptores de padrões e fagocitam | S | 100 | F3 |
| A10 | Digestão em peptídeos acoplados a MHC II | S | 100 | F3 |
| A11 | A APC migra pelos vasos linfáticos até os linfonodos | NV | N/A | F3 cita apenas o acúmulo de T e APC nos linfonodos |
| A12 | B diferenciam-se com sinais de T auxiliares | S | 100 | F3; F5 |
| A13 | Formam-se plasmócitos de vida curta ou longa | S | 100 | F4, seção 7 |
| A14 | Primeiro IgM, depois IgG | S | 100 | F5 (notas); F3, tabela |
| A15 | Neutralização, opsonização e complemento | S | 100 | F3 |
| A16 | CD4+: MHC II, não citotóxicos, citocinas que ajudam B e macrófagos | S | 100 | F3 |
| A17 | CD8+: MHC I e apoptose da célula-alvo | S | 100 | F3 |
| A18 | Seleção, sinais de sobrevida e expansão clonal | S | 100 | F4, seção 7; F5 |
| A19 | "multiplica clones idênticos" (B e T) | C | 0 | F4, seção 7 |
| A20 | A maioria vira efetora de vida curta e morre após a depuração | S | 100 | F3; F4 |
| A21 | Uma fração persiste como B e T de memória, mais LLPC na medula | S | 100 | F3; F4, seções 7 e 13 |
| A22 | Mais células de memória e limiar de ativação menor | S | 100 | F4, seção 7 |
| A23 | B de memória geram plasmócitos com anticorpos de maior afinidade e IgG | S | 100 | F4; F3; F5 |
| A24 | T de memória geram efetoras em poucos dias | S | 100 | F4, seção 7 |
| A25 | A latência cai e o patógeno pode ser contido antes da doença | S | 100 | F3; F4, Introdução |
| A26 | A vacina é imunização ativa com microrganismos inativados, atenuados ou frações | S | 100 | F3, Passive vs. active |
| A27 | Adjuvantes "para recrutar a imunidade inata" | NV | N/A | F3 diz somente que melhoram a resposta |
| A28 | A vacinação gera LLPC e memória (como efeito geral) | C | 0 | F4, seção 7 Consequences |
| A29 | Patógenos mutáveis escapam da memória | S | 100 | F4, seção 7 |
| A30 | Patógenos rápidos superam o tempo da memória B | S | 100 | F4, seção 7 |
| A31 | Imunossenescência reduz diversidade e eficácia | S | 100 | F4, seções 11 e 13 |
| A32 | Exemplo, etapas 1-3 (apresentação, ajuda T, IgM→IgG, memória) | S | 100 | F3; F4; F5 |
| A33 | Exemplo, etapa 4 e resultado (IgG pré-existente mais memória contêm a infecção) | S | 100 | F3; F4 (cenário hipotético coerente) |
| A34 | "memória garante rapidez de resposta" | C | 0 | F4, seções 11 e 13 |
| A35 | Mudanças de epítopo podem fazer a memória falhar | S | 100 | F4, seção 7 |
| A36 | Confusão 1: anticorpos são proteínas de meia-vida finita; memória são células que persistem e se dividem | S | 100 | F3; F5; F4 |
| A37 | Confusão 2: CD4+ não são citotóxicos; CD8+ destroem células | S | 100 | F3 |
| A38 | Pergunta 1: B depende de CD4+ (ativados via MHC II) para proliferar e trocar de classe | S | 100 | F3; F4, seção 7 (CD40/AID) |
| A39 | Pergunta 2: idoso tem involução tímica, menor diversidade, falhas no centro germinativo, menos LLPC e memória e títulos menores | S | 100 | F4, seção 13 |
| A40 | Síntese (reconhecimento, expansão e memória, vacina sem dano e com limites) | S | 100 | F3; F4; F5 |

## 5. Vínculos bibliográficos
| ID | Afirmação → referência | Resultado | Nota |
|---|---|---|---|
| V1 | A1 → F3 | Válido | 100 |
| V2 | Ideia central (memória e vacinação) → F4 | Válido | 100 |
| V3 | A2 → F3 | Válido | 100 |
| V4 | A3, A4 → F3 | Válido | 100 |
| V5 | A5, A7, A8 → F3 | Válido | 100 |
| V6 | A6 → F3, F4 | Válido | 100 |
| V7 | A9, A10 → F3 | Válido | 100 |
| V8 | A11 → F3 | NV (F3 não descreve a rota da APC) | N/A |
| V9 | A12 → F3, F5 | Válido | 100 |
| V10 | A13 → F4 | Válido | 100 |
| V11 | A14 → F3, F5 | Válido | 100 |
| V12 | A18 → F3, F4, F5 | Válido | 100 |
| V13 | A19 → F3 | NV (F3 não trata da identidade dos clones B) | N/A |
| V14 | A20, A21 → F3, F4 | Válido | 100 |
| V15 | A22 → F4 | Válido | 100 |
| V16 | A23 → F3, F4, F5 | Válido | 100 |
| V17 | A26 → F3 | Válido | 100 |
| V18 | A27 → F3 | NV (F3 não descreve o mecanismo do adjuvante) | N/A |
| V19 | A28 → F4 | Válido para a associação entre vacina, memória e ausência de dano; a generalização errada está registrada em A28 | 100 |
| V20 | A29-A31 → F4 | Válido | 100 |
| V21 | A34/A35 → F4 (ausência de imunidade absoluta) | Válido quanto à parte "não absoluta"; o erro está registrado em A34 | 100 |
| V22 | A36 → F3, F4, F5 | Válido | 100 |
| V23 | A37 → F3 | Válido | 100 |
| V24 | A38 → F3, F4, F5 | Válido | 100 |
| V25 | A39 → F4 | Válido | 100 |
| V26 | Síntese → F3, F4, F5 | Válido | 100 |
| V27 | Lista de fontes (F3 e F4 como original + notas; F5 como consulta indireta; DOIs) | Válido | 100 |
| V28 | A16, A17 → F3 | Válido | 100 |
| V29 | A15 → F3 | Válido | 100 |
| V30 | A25 → F3, F4 | Válido | 100 |
| V31 | Exemplo A32/A33 → F3, F4, F5 | Válido | 100 |

**Lista de fontes:** não há fonte inventada. A extensão do acesso está declarada corretamente, inclusive a consulta indireta de F5.

## 6. Resumo
| C1 | C2 | C3 | Numeradores/denominadores | Erros centrais | Erros localizados | Omissões essenciais | Pendências |
|---|---|---|---|---|---|---|---|
| 66,67 | N/A | N/A | C1 = 400/6. C2: 35 sustentadas, 3 contraditas e 2 NV de 40 (seria 87,50 se todas estivessem decididas). C3: 28 válidos e 3 NV de 31 (seria 90,32 condicional). | Nenhum (a resposta não atribui anticorpos a T, não trata anticorpos como células e não promete imunidade absoluta) | 3: A19, A28, A34 | Nenhuma | A11, A27, V8, V13, V18 |

## 7. Situação científica
**CORRIGIR.** Há três erros localizados confirmados pelo texto original de B02-F4, e eles zeram K4 e K6 pela regra do protocolo:
- "clones idênticos" na expansão clonal de B, embora a fonte descreva hipermutação somática;
- generalização de que a vacina gera plasmócitos de vida longa;
- "a memória garante rapidez de resposta", embora a fonte descreva memória limitada em idosos.

As pendências não verificáveis ficam registradas, mas não alteram a prioridade CORRIGIR. Esta avaliação não é garantia de verdade absoluta nem revisão por especialista.