# Consolidação do lote

Situação do processo automático: CONCLUÍDO_COM_DESCARTES; 12 respostas completas; 0 respostas descartadas; 8 avaliações descartadas, incluindo etapas não iniciadas.
Somente respostas completas e pareceres finais validados participam das notas. CORRIGIR é uma decisão científica final e mantém pedagogia bloqueada. Descartes e medidas ausentes ficam N/A nos registros; o ranking HTML apresenta modelos sem avaliação pedagógica completa com 0 e ERRO. Revisão humana não realizada.


- DESCARTADO S02/B01/JC1: A35: no exemplo, a afirmação de que o sangramento diminui 'em minutos' não pode ser verificada nas fontes incorporadas, que não informam a escala de tempo do tampão plaquetário.; A36/V27: no exemplo, a afirmação de que tPA e plasmina dissolvem a fibrina 'dias depois' não pode ser verificada. B01-F4 (notas) diz apenas que o coágulo é removido 'posteriormente', e B01-F3 descreve a fibrinólise ativada em paralelo à coagulação, sem escala temporal.; Isso deixa C2 e C3 como N/A. Não foi confirmado nenhum erro científico ou bibliográfico; a resposta fica PENDENTE, não CORRIGIR.
- DESCARTADO S05/B02/JC2: A46/V45: o exemplo diz que uma vacina hipotética de proteína inativada ativa T citotóxicos, que geram células efetoras e de memória. As fontes incorporadas não sustentam isso. B02-F3 liga o MHC de classe I a peptídeos endógenos e o MHC de classe II a peptídeos exógenos, e o pacote não trata de apresentação cruzada. As notas de B02-F5 excluíram de propósito os trechos que associam tipos de patógeno a vias de apresentação. Com isso, a afirmação não pode ser verificada; também não há falsidade confirmada. Isso deixa C2 e C3 como N/A e impede APTO até haver fonte ou revisão especializada.
- DESCARTADO S02/B02/JC1: A40/V34: em 'Confira seu entendimento', a pergunta 2 diz que a vacina proteica hipotética gerou linfócitos T de memória citotóxicos. As fontes não sustentam isso. B02-F3 descreve a apresentação por MHC I somente para peptídeos endógenos, e o exemplo da própria resposta descreve apenas apresentação em MHC II. Não há, no pacote, mecanismo que permita conferir a geração de memória CD8+ a partir de proteína exógena. Isso exige verificação especializada, mas não é um erro confirmado.; A33: 'células inatas detectam o adjuvante' não está nas fontes. B02-F3 diz somente que adjuvantes melhoram a resposta, e B02-F4 menciona o efeito de depósito. A afirmação não pôde ser verificada.; Como há afirmações não verificáveis, C2 e C3 ficam N/A e a situação é PENDENTE. Nenhum erro foi confirmado.
- DESCARTADO S02/B02/JC2: A41/V40: a resposta comentada 2 diz que a vacina proteica do exemplo gerou T citotóxicos (CD8+) de memória. As fontes fornecidas ligam o MHC I a peptídeos intracelulares e não descrevem como uma proteína vinda de fora ativaria células CD8+ (apresentação cruzada). Sem essa base, a afirmação não pode ser conferida.; A32/V34: o exemplo diz que células inatas detectam o adjuvante. As fontes só dizem que adjuvantes melhoram a resposta ao antígeno e que a imunidade inata faz a detecção inicial; não dizem que o adjuvante é detectado.; Não foi possível ler as fontes-base do gabarito (B02-F1 e B02-F2). A conferência usou somente B02-F3 e B02-F4 (notas e texto original) e B02-F5 (apenas notas).
- DESCARTADO S04/B02/JC1: A33: o limite do exemplo afirma que a pessoa pode adoecer 'se a dose for muito alta' (dose infectante que supera a memória). Nenhuma fonte incorporada trata da dose infectante como limite da proteção; B02-F4 cita dose apenas quanto à quantidade de antígeno da vacina ou da infecção primária e à formação de células de vida longa. Pendência de fonte, não erro confirmado.; Não há erro científico nem bibliográfico confirmado. K1-K6 = 100. C2 fica N/A enquanto A33 não for verificado.
- DESCARTADO S04/B02/JC2: A33: a afirmação de que uma dose muito alta do agente pode levar ao adoecimento mesmo com memória não pode ser conferida nas fontes fornecidas (B02-F3, B02-F4, B02-F5).; A39/V39: a afirmação de que a proteção depende da 'quantidade de antígeno' (resposta comentada da pergunta 2, atribuída a B02-F4) não pode ser conferida. B02-F4 fala apenas da redução do limiar mínimo de antígeno pelas células B de memória e do número limitado de antígenos na vacina.; Por causa dessas duas pendências, C2 e C3 ficam N/A. Nenhum erro científico ou bibliográfico foi confirmado.
- DESCARTADO S04/B01/JC1: A31/V31: a afirmação de que vasoconstrição e exposição do fator tecidual são 'respostas proporcionais a essa lesão' [B01-F3] não pode ser conferida no material fornecido. B01-F3 sustenta que ambas ocorrem após a lesão, mas não trata de proporcionalidade.; A43/V37: na Síntese, a afirmação de que exposição subendotelial e vasoconstrição 'abrem e limitam a resposta ao mesmo tempo' [B01-F3] não pode ser conferida. O material sustenta que a vasoconstrição reduz a perda de sangue (B01-F3, B01-F4), mas não que um evento vascular limite a resposta hemostática.; Por causa desses dois itens não verificáveis, C2 e C3 ficam N/A, e a aprovação exige que as duas afirmações sejam corrigidas ou que se forneçam fontes que as sustentem. Não houve erro científico confirmado.
- DESCARTADO S04/B01/JC2: A30/V31: na seção 6, a afirmação de que vasoconstrição e exposição do fator tecidual são 'respostas proporcionais a essa lesão' [B01-F3] traz um qualificador (proporcionalidade) que não aparece no texto integral de B01-F3 nem nas outras notas. Não há contradição, mas a afirmação é não verificável; C2 e C3 ficam N/A.; B01-F1 (OpenStax), citada no gabarito, não foi fornecida. O conteúdo dos pontos foi conferido pelas fontes B01-F2 a F5.

- N/A S02/B01/TELEMETRIA: Medição incompleta; custos ou outros valores ausentes ficam N/A e são excluídos das respectivas comparações.
- N/A S05/B01/TELEMETRIA: Medição incompleta; custos ou outros valores ausentes ficam N/A e são excluídos das respectivas comparações.
- N/A S05/B02/TELEMETRIA: Medição incompleta; custos ou outros valores ausentes ficam N/A e são excluídos das respectivas comparações.
- N/A S06/B01/TELEMETRIA: Medição incompleta; custos ou outros valores ausentes ficam N/A e são excluídos das respectivas comparações.
- N/A S03/B01/TELEMETRIA: Medição incompleta; custos ou outros valores ausentes ficam N/A e são excluídos das respectivas comparações.
- N/A S01/B02/TELEMETRIA: Medição incompleta; custos ou outros valores ausentes ficam N/A e são excluídos das respectivas comparações.
- N/A S03/B02/TELEMETRIA: Medição incompleta; custos ou outros valores ausentes ficam N/A e são excluídos das respectivas comparações.
- N/A S06/B02/TELEMETRIA: Medição incompleta; custos ou outros valores ausentes ficam N/A e são excluídos das respectivas comparações.
- N/A S02/B02/TELEMETRIA: Medição incompleta; custos ou outros valores ausentes ficam N/A e são excluídos das respectivas comparações.
- N/A S04/B02/TELEMETRIA: Medição incompleta; custos ou outros valores ausentes ficam N/A e são excluídos das respectivas comparações.
- N/A S04/B01/TELEMETRIA: Medição incompleta; custos ou outros valores ausentes ficam N/A e são excluídos das respectivas comparações.
- N/A S01/B01/TELEMETRIA: Medição incompleta; custos ou outros valores ausentes ficam N/A e são excluídos das respectivas comparações.

Protocolo 3.2; fase PILOTO; 12 execuções planejadas preservadas.
Consolidação programática v1; os pareceres são do Claude e permanecem provisórios até revisão humana.
57 chamadas de julgamento e 1 consolidação(ões) registradas; 0 pendências administrativas ou de avaliação.
4 APTO primários; custo conhecido de geração: N/A - nenhuma cobrança confirmada; cobertura 0/12.
Custo por APTO primário: N/A - custo incompleto. Inclui todas as gerações do lote, inclusive falhas.
Julgamentos: orçamento separado em orcamento-julgamentos.csv; custo monetário não observado. Pesquisa e pairwise não realizados por este comando.

| Execução | Sistema | Tema | Rodada | JC1 | JP1 | P | T1 | T2 | E1 | E2 | E3 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| E25922611554175891518 | S02 | B01 | 1 | DESCARTADO | BLOQUEADO | N/A | 100 | N/A | N/A | N/A | N/A |
| E68880818928863924961 | S05 | B01 | 1 | CORRIGIR | BLOQUEADO | N/A | 100 | N/A | N/A | N/A | N/A |
| E80752978413979810356 | S05 | B02 | 1 | CORRIGIR | BLOQUEADO | N/A | 100 | N/A | N/A | N/A | N/A |
| E07644098396951605804 | S06 | B01 | 1 | CORRIGIR | BLOQUEADO | N/A | 100 | N/A | N/A | N/A | N/A |
| E86162589542085224347 | S03 | B01 | 1 | APTO | CONCLUÍDO | 95 | 100 | N/A | N/A | N/A | N/A |
| E96290365979597406061 | S01 | B02 | 1 | APTO | CONCLUÍDO | 85 | 100 | N/A | N/A | N/A | N/A |
| E12450941380389559652 | S03 | B02 | 1 | APTO | CONCLUÍDO | 85 | 100 | N/A | N/A | N/A | N/A |
| E47419489525169154278 | S06 | B02 | 1 | CORRIGIR | BLOQUEADO | N/A | 100 | N/A | N/A | N/A | N/A |
| E43188925521530890203 | S02 | B02 | 1 | DESCARTADO | BLOQUEADO | N/A | 100 | N/A | N/A | N/A | N/A |
| E50351026877923322685 | S04 | B02 | 1 | DESCARTADO | BLOQUEADO | N/A | 100 | N/A | N/A | N/A | N/A |
| E49292865337802493735 | S04 | B01 | 1 | DESCARTADO | BLOQUEADO | N/A | 100 | N/A | N/A | N/A | N/A |
| E32822649626684547951 | S01 | B01 | 1 | APTO | CONCLUÍDO | 95 | 100 | N/A | N/A | N/A | N/A |

As tabelas completas preservam os itens e motivos de N/A; agregados.csv mostra a cobertura e a dispersão dos resultados elegíveis por sistema e tema.
global-por-rodada.csv exige os temas do estudo (B01 e B02) com APTO e P completos. Um lote com um só tema não produz média global.
JC2/JP2 são estabilidade, nunca substitutos de JC1/JP1. Inventários A/V não foram alinhados semanticamente para concordância.
Desacordos de JC e alertas de JP exigem revisão especializada. Não há medição de compreensão ou aprendizagem humana.
A detecção de identidade é conservadora e não garante anonimato estilístico. F5 e fontes exigem revisão humana.
Os juízes recebem somente material congelado, sem navegação. Notas de leitura não equivalem a acesso integral às obras.
Nenhuma ausência foi convertida em zero. Os CSV usam IDs; resultados.html identifica os modelos por autorização do pesquisador.
