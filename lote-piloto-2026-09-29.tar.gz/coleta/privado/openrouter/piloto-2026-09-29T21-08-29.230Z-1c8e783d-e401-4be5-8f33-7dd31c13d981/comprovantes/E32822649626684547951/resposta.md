# Hemostasia: como uma pequena lesão vascular é vedada e por que a resposta permanece localizada

## Ideia central

Quando um pequeno vaso se rompe, o sangue escapa para os tecidos ou para fora do corpo. A **hemostasia** (do grego *haeme*, sangue, e *stasis*, parar) é o conjunto de respostas que interrompe esse sangramento [B01-F3].

O desafio é duplo. O organismo precisa vedar a lesão rapidamente e, ao mesmo tempo, manter o sangue fluido no restante da circulação [B01-F3; B01-F5]. Nesta aula, o objetivo é entender como vaso, plaquetas e proteínas plasmáticas cooperam e por que essa cooperação precisa de freios.

## Conceitos necessários

- **Endotélio**: camada de células que reveste o vaso por dentro. Quando está íntegro, dificulta a coagulação: produz óxido nítrico e prostaciclina, que desfavorecem a agregação de plaquetas [B01-F2; B01-F3].
- **Subendotélio**: tecido situado abaixo do endotélio. Contém colágeno e fator von Willebrand (vWF), uma proteína adesiva. É altamente trombogênico, ou seja, favorece a formação de coágulo [B01-F3].
- **Plaquetas**: fragmentos celulares sem núcleo, originados dos megacariócitos. Seus grânulos armazenam mediadores como ADP e cálcio [B01-F3].
- **Fatores de coagulação**: em sua maioria, formas inativas de enzimas, chamadas zimogênios, que circulam no plasma. A forma ativada recebe a letra "a"; por exemplo, o fator VII ativado é o VIIa [B01-F3].
- **Fator tecidual**: glicoproteína de membrana presente na parede vascular, fora do contato com o sangue enquanto o vaso está íntegro. É o principal iniciador da coagulação no organismo [B01-F3].
- **Trombina e fibrina**: a trombina é a enzima central da coagulação. Ela converte o fibrinogênio, uma proteína solúvel do plasma, em fibrina, que forma filamentos insolúveis [B01-F3].

## Mecanismo passo a passo

### 1. A lesão muda o vaso e dispara a resposta

A lesão provoca vasoconstrição, mediada por reflexos nervosos e por mediadores locais, como a endotelina e o tromboxano A2. O estreitamento do vaso reduz a perda de sangue [B01-F3; B01-F4].

A mudança decisiva, porém, é outra: a ruptura do endotélio expõe ao sangue o colágeno, o vWF e o fator tecidual [B01-F3]. Uma superfície que antes dificultava a coagulação passa a ativá-la. A resposta começa, portanto, porque componentes antes separados entram em contato.

### 2. Plaquetas formam o tampão inicial

**Adesão**: o vWF funciona como ponte entre o colágeno exposto e o receptor GPIb da plaqueta [B01-F3].

**Ativação**: depois de aderidas, as plaquetas mudam de forma. Elas emitem pseudópodes, que aumentam sua superfície, e liberam o conteúdo de seus grânulos. O ADP e o tromboxano A2 recrutam e ativam outras plaquetas [B01-F3].

**Agregação**: o ADP altera a forma do receptor GPIIb/IIIa, que passa a ligar fibrinogênio. Como o fibrinogênio se liga a receptores de plaquetas vizinhas, ele as conecta umas às outras [B01-F2; B01-F3].

O resultado é o **tampão plaquetário**, que veda a lesão apenas temporariamente (hemostasia primária) [B01-F3]. As plaquetas ativadas também expõem fosfolipídios que, com o cálcio, formam a superfície onde os fatores de coagulação serão montados [B01-F3]. É por essa superfície que o ponto 2 se conecta ao ponto 3.

### 3. Fatores ativados geram trombina e fibrina

O modelo atual descreve a coagulação sobre superfícies celulares, em fases [B01-F3]:

- **Iniciação**: o fator tecidual liga o VIIa, e esse complexo ativa os fatores IX e X. O Xa gera uma pequena quantidade de trombina, que o inibidor da via do fator tecidual (TFPI) consegue bloquear [B01-F3].
- **Amplificação**: essa trombina inicial ativa plaquetas e os cofatores V e VIII, o que acelera as reações seguintes [B01-F3].
- **Propagação**: os complexos enzimáticos se acumulam sobre as plaquetas. Um deles é a protrombinase, formada por Xa, Va, fosfolipídios e cálcio. Esses complexos produzem trombina em grande quantidade [B01-F3].

A lógica é de multiplicação. Cada enzima ativa muitas moléculas da etapa seguinte, e a própria trombina reforça sua produção. Um sinal pequeno se torna robusto, mas apenas onde existe superfície adequada. A trombina então converte fibrinogênio em fibrina [B01-F3].

### 4. A fibrina estabiliza o tampão e integra as duas fases

A trombina ativa o fator XIII, que cria ligações covalentes entre os polímeros de fibrina incorporados ao tampão. O resultado é uma rede que confere resistência ao conjunto (hemostasia secundária) [B01-F3]. Essa rede também retém hemácias, e a contração das plaquetas aproxima as bordas da lesão [B01-F4].

As duas fases não são sequências isoladas. As plaquetas fornecem a superfície para gerar trombina, e a trombina ativa mais plaquetas e produz a fibrina que reforça o tampão [B01-F3]. Por isso, a falta de plaquetas ou de fatores de coagulação compromete a contenção do sangramento [B01-F4].

### 5. Freios da coagulação e remoção da fibrina

Vários mecanismos limitam a resposta ao local da lesão:

- **Endotélio íntegro vizinho**: libera óxido nítrico e prostaciclina. O equilíbrio entre prostaciclina e tromboxano A2 restringe a agregação ao ponto lesionado [B01-F2; B01-F3].
- **TFPI**: restringe o Xa e o complexo fator tecidual/VIIa, ou seja, freia a iniciação [B01-F2].
- **Antitrombina**: neutraliza a trombina, o Xa e outras enzimas. Sua ação é potencializada por moléculas semelhantes à heparina na superfície endotelial [B01-F2; B01-F3].
- **Via da proteína C**: a trombina que se liga à trombomodulina do endotélio ativa a proteína C. Com a proteína S, a proteína C ativada inativa Va e VIIIa, reduzindo a amplificação [B01-F2; B01-F3]. Assim, a mesma trombina que coagula na lesão ajuda a frear a coagulação sobre o endotélio sadio.

A **fibrinólise** remove a fibrina já formada. Ativadores como o tPA convertem plasminogênio em plasmina, e a plasmina degrada a fibrina [B01-F2; B01-F3]. Esse processo também é controlado: a α2-antiplasmina inibe a plasmina, e o TAFI, ativado pela trombina, protege o coágulo recém-formado [B01-F3]. O equilíbrio entre formar e remover fibrina mantém a vedação durante o reparo [B01-F2].

### 6. Hemostasia fisiológica versus trombose

Três critérios distinguem a hemostasia fisiológica: ela tem um gatilho (a lesão), permanece localizada e é temporária, pois o coágulo é removido depois [B01-F4; B01-F5].

A **trombose** é a formação de coágulo dentro da circulação que pode ocorrer mesmo sem lesão aparente. Ela pode obstruir o vaso e comprometer órgãos; a trombose venosa profunda é um exemplo [B01-F5]. Os componentes envolvidos são os mesmos. O que muda é o equilíbrio: a atividade pró-coagulante aumenta ou os inibidores naturais diminuem [B01-F3].

## Exemplo explicado

**Situação inicial**: um pequeno corte na pele rompe vasos de pequeno calibre, e o sangue começa a escapar.

**Etapas**: os vasos se contraem e o sangramento diminui. O colágeno exposto, via vWF, prende plaquetas, que se ativam e recrutam outras. O fator tecidual exposto inicia a geração de trombina sobre essas plaquetas. A trombina forma fibrina, e o fator XIII a estabiliza. Enquanto isso, o endotélio intacto ao redor, com a antitrombina e a proteína C, impede que o processo avance além do corte. Durante o reparo, a plasmina degrada a fibrina.

**Resultado interpretado**: o sangramento cessa porque vaso, plaquetas e proteínas agiram em conjunto. Ele cessa apenas no ponto lesionado porque os freios atuam onde o endotélio está preservado.

**Limite**: trata-se de um esquema didático. Ele não descreve a variação entre pessoas nem permite avaliar a coagulação de ninguém.

## Confusões a evitar

1. **"O tampão plaquetário sozinho resolve o sangramento."** Ele veda apenas temporariamente. A estabilidade depende da fibrina ligada pelo fator XIII, e as duas fases dependem uma da outra [B01-F3; B01-F4].
2. **"Anticoagulantes naturais dissolvem o coágulo."** Inibidores como a antitrombina reduzem a formação de novo coágulo. A degradação da fibrina já existente é feita pela plasmina, na fibrinólise. São mecanismos diferentes [B01-F2].

## Confira seu entendimento

1. **Por que a deficiência de antitrombina ou de proteína C se associa a maior risco de trombose?**

   Resposta comentada: esses componentes freiam a trombina e seus cofatores (Va e VIIIa). Com menos freio, a amplificação da coagulação persiste mais facilmente, inclusive fora da lesão, e o equilíbrio se desloca para a formação de coágulo [B01-F2; B01-F3]. Trata-se de aumento de risco, não de certeza.

2. **No pequeno corte, se as plaquetas aderissem normalmente, mas pouca fibrina fosse formada, o que se esperaria?**

   Resposta comentada: o tampão inicial se formaria, mas sem a rede de fibrina estabilizada ele permaneceria frágil. A contenção do sangramento ficaria comprometida [B01-F3; B01-F4]. O raciocínio mostra por que a hemostasia primária precisa da secundária.

## Síntese

- A lesão expõe colágeno, vWF e fator tecidual, e esse contato ativa ao mesmo tempo as plaquetas e a coagulação.
- As plaquetas formam um tampão temporário e oferecem superfície para gerar trombina; a fibrina, estabilizada pelo fator XIII, torna a vedação resistente.
- Inibidores naturais restringem a resposta ao local e a fibrinólise remove a fibrina; quando esse controle falha, surge a trombose, que obstrui vasos em vez de proteger.

## Fontes consultadas

- [B01-F3] Palta, S.; Saroa, R.; Palta, A. *Overview of the coagulation system*. Indian Journal of Anaesthesia, 2014;58(5):515-523. Corpo textual original em inglês (XML), sem inspeção das imagens nem das obras citadas pelo artigo. Seções utilizadas: Primary haemostasis, Clotting factors, Naturally occurring anticoagulants, Coagulation cascade, Current concept of coagulation, Thrombotic disorders, Fibrinolytic system. https://doi.org/10.4103/0019-5049.144643; texto em https://www.ebi.ac.uk/europepmc/webservices/rest/PMC4260295/fullTextXML
- [B01-F2] MSD Manual, versão profissional. *Overview of Hemostasis* (Streiff; rev. Emadi; set. 2025). Seções Platelets, Plasma Coagulation Factors, Regulation of Coagulation. Consulta indireta, por notas de leitura. https://www.msdmanuals.com/professional/hematology/hemostasis/overview-of-hemostasis
- [B01-F4] NHLBI/NIH. *How Does Blood Clot?* (atualização 2022-03-24). Texto explicativo. Consulta indireta, por notas de leitura. https://www.nhlbi.nih.gov/health/clotting-disorders/how-blood-clots
- [B01-F5] NHLBI/NIH. *What Are Blood Clotting Disorders?* (atualização 2022-03-24). Apresentação do tema. Consulta indireta, por notas de leitura. https://www.nhlbi.nih.gov/health/clotting-disorders