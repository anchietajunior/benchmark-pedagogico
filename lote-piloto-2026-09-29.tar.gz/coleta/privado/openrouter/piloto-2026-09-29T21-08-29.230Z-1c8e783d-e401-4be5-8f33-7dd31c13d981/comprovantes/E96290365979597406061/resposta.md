# Resposta imune adaptativa: do reconhecimento do antígeno à memória imunológica

## Ideia central

Na primeira exposição a um agente infeccioso, as defesas específicas demoram a se organizar. Por isso existe um intervalo entre a exposição e a resposta máxima [B02-F3]. A memória imunológica permite que uma exposição posterior ao mesmo antígeno produza uma resposta mais rápida e eficiente [B02-F3].

Esta aula mostra como linfócitos B e T reconhecem um antígeno, se multiplicam e deixam células de memória. Também mostra por que a vacinação aproveita esse processo sem garantir proteção absoluta.

## Conceitos necessários

**Antígeno** é uma estrutura estranha que um receptor de linfócito reconhece de modo específico. Pode pertencer a micróbios, vírus, toxinas ou células tumorais [B02-F3].

**Imunidade inata** age imediatamente ou em poucas horas. Ela não é específica para um antígeno e não guarda memória convencional [B02-F3]. Suas células usam receptores de reconhecimento de padrões, que detectam estruturas comuns a muitos patógenos [B02-F3].

**Imunidade adaptativa** é específica para cada antígeno. Na primeira exposição, ela é mais lenta que a inata [B02-F3].

**Célula apresentadora de antígeno (APC)** é uma célula que digere o antígeno e exibe fragmentos dele, chamados **peptídeos**. Esses peptídeos ficam presos a moléculas do **complexo principal de histocompatibilidade (MHC)**. As células dendríticas são as principais APC, mas macrófagos e linfócitos B também podem apresentar antígenos [B02-F3].

**Linfócitos T** amadurecem no timo. Cada linfócito T tem um único tipo de receptor, o **TCR** [B02-F3].

**Linfócitos B** reconhecem o antígeno por um anticorpo fixado em sua membrana, que funciona como receptor [B02-F3].

**Anticorpo** é uma proteína secretada. **Plasmócito** é o linfócito B diferenciado que produz grandes quantidades dessa proteína [B02-F3].

## Mecanismo passo a passo

### 1. Antígeno, resposta inata e apresentação

A resposta inata detecta o invasor primeiro e libera citocinas, que são pequenas proteínas de comunicação entre células. Essa etapa também mobiliza e ativa as APC [B02-F3].

A célula dendrítica engloba o agente, processa suas proteínas e exibe peptídeos no MHC [B02-F3; B02-F5, consulta indireta pelas notas]. O tipo de MHC depende da origem do peptídeo:

- o **MHC de classe I** existe em todas as células nucleadas e mostra peptídeos de origem intracelular;
- o **MHC de classe II** existe em algumas células imunes e mostra peptídeos de origem extracelular [B02-F3].

Encontrar o linfócito T certo é um problema de probabilidade. Linfócitos T circulam pelo sangue e pela linfa e se acumulam com APC nos linfonodos. Isso aumenta a chance de o TCR correto encontrar o complexo formado por peptídeo e MHC [B02-F3].

Portanto, a resposta inata não é uma etapa separada da adaptativa. É ela que prepara o encontro que ativa os linfócitos [B02-F3].

### 2. Linfócitos B, plasmócitos e anticorpos

O linfócito B reconhece o antígeno em sua forma nativa, sem precisar de APC [B02-F3]. Quando ativado, ele prolifera e segue um de dois caminhos:

- vira **plasmócito**, que secreta anticorpos;
- vira **célula B de memória** [B02-F3].

Os anticorpos se ligam ao patógeno e o marcam para destruição. Essa destruição ocorre pelo complemento, por fagocitose facilitada (opsonização) e por células efetoras [B02-F3].

Os anticorpos contêm a multiplicação viral na fase aguda da infecção. Porém, em geral, não eliminam um vírus quando a infecção já se estabeleceu [B02-F3].

### 3. T auxiliares versus T citotóxicos

Os **T auxiliares (CD4+)** reconhecem peptídeos no MHC de classe II. Eles não matam células infectadas. Sua função é liberar citocinas que dirigem outras células [B02-F3]. Por exemplo, ajudam o linfócito B a se multiplicar e orientam o tipo de anticorpo produzido [B02-F3]. A ativação de B com ajuda de T auxiliares gera memória mais eficaz [B02-F5, consulta indireta].

Os **T citotóxicos (CD8+)** reconhecem peptídeos no MHC de classe I. Eles induzem apoptose, isto é, morte celular programada, em células infectadas ou tumorais [B02-F3].

A lógica dessa divisão é a seguinte: o CD8+ enxerga o que está dentro de uma célula e elimina essa célula. O CD4+ coordena a resposta.

### 4. Expansão clonal e memória

Chama-se **clone** o conjunto de linfócitos que descendem de uma mesma célula e compartilham o mesmo receptor. Só os clones que reconhecem o antígeno são ativados. Eles então se multiplicam intensamente, processo chamado **expansão clonal**, e geram células efetoras [B02-F3; B02-F5, consulta indireta].

Quando a infecção é resolvida, a maioria das células efetoras T morre. Poucas permanecem como células de memória [B02-F3].

Entre os plasmócitos, há duas populações:

- os de vida curta, que atuam na resposta inicial;
- os de vida longa, que mantêm a produção de anticorpos [B02-F4].

A fonte B02-F3 descreve os plasmócitos apenas como células de vida relativamente curta. A B02-F4 detalha essa distinção entre vida curta e vida longa.

O tempo também difere. A resposta primária elimina a infecção em cerca de uma semana. Já a formação das células de vida longa se completa em semanas [B02-F4].

### 5. Novo contato com o mesmo antígeno

Na **resposta secundária**, já existem mais células específicas prontas para agir [B02-F4]. Os anticorpos dos plasmócitos de vida longa atuam de imediato. Os linfócitos B e T de memória proliferam em poucos dias [B02-F4].

A resposta secundária repete as etapas da primária, porém com mais velocidade e melhor qualidade. Os anticorpos produzidos têm maior afinidade, ou seja, ligam-se ao antígeno com mais força [B02-F4]. Além disso, as células B de memória reduzem a quantidade mínima de antígeno necessária para iniciar uma resposta [B02-F4].

### 6. Vacinação e seus limites

A vacina imita o estímulo que desenvolve a imunidade, sem produzir a doença ativa [B02-F5, consulta indireta]. É uma forma de **imunização ativa**: o próprio organismo gera a resposta, muitas vezes com auxílio de adjuvantes [B02-F3].

A imunização passiva é diferente. Ela transfere anticorpos prontos, e a proteção termina quando esses anticorpos são degradados [B02-F5, consulta indireta].

O ideal é que uma vacina produza dois níveis de defesa:

- anticorpos que bloqueiam o acesso do patógeno;
- células de memória que protegem contra a doença caso o patógeno ultrapasse essa primeira barreira [B02-F4].

Esse ideal tem limites, descritos na B02-F4:

- níveis altos de anticorpos não garantem proteção automaticamente;
- contra patógenos de disseminação rápida, conta sobretudo o anticorpo que já está presente;
- patógenos que mudam, como o vírus influenza, podem escapar da memória formada contra versões anteriores;
- a memória enfraquece com a idade. Após uma vacina contra influenza, títulos protetores foram obtidos em 10 a 30% dos idosos, contra 50 a 75% dos mais jovens.

## Exemplo explicado

**Situação inicial.** Uma pessoa hipotética recebe uma vacina contra um vírus fictício, o "vírus V". A vacina contém antígenos do vírus, mas não causa a doença.

**Etapas após a vacina.**

1. A resposta inata ativa as APC.
2. As APC apresentam peptídeos a linfócitos T auxiliares no MHC de classe II.
3. Linfócitos B específicos reconhecem o antígeno e, com ajuda desses T auxiliares, expandem-se.
4. Os B ativados formam plasmócitos e células B de memória.

Semanas depois, a pessoa tem anticorpos circulantes e células de memória.

Uma ressalva é necessária: se essa vacina também gerou T citotóxicos de memória depende do tipo de vacina, tema fora deste recorte.

**Contato posterior.** Meses depois, a pessoa entra em contato com o vírus V.

- Os anticorpos já presentes podem bloquear parte das partículas virais.
- As células B de memória proliferam em poucos dias e geram novos plasmócitos.
- Se algumas células forem infectadas, elas exibirão peptídeos virais no MHC de classe I. Linfócitos CD8+ poderão então eliminá-las [B02-F3; B02-F4].

**Interpretação.** A resposta foi mais rápida porque a vacina aumentou o número de clones específicos antes do contato.

**Limite da conclusão.** Não se pode concluir que a pessoa está protegida em qualquer circunstância. O resultado depende de três fatores: a velocidade de disseminação do vírus, possíveis mudanças nos antígenos virais e a idade e o estado imune da pessoa [B02-F4].

## Confusões a evitar

1. **"Ter anticorpos é o mesmo que ter memória."** Essa ideia está errada. Anticorpos são proteínas secretadas por plasmócitos. Células de memória são células vivas que mantêm seus receptores e voltam a proliferar quando reencontram o antígeno [B02-F3]. Por isso, uma queda nos anticorpos não prova, sozinha, a ausência de células de memória. Também por isso a imunização passiva, que fornece apenas anticorpos, é temporária [B02-F5, consulta indireta].

2. **"Memória imunológica garante proteção absoluta."** Essa ideia também está errada. A memória acelera a resposta, mas não elimina o tempo necessário para que as células proliferem. Contra um patógeno rápido, esse tempo pode não bastar. Além disso, variantes podem escapar da memória, e títulos elevados de anticorpos não garantem proteção [B02-F4].

## Confira seu entendimento

1. **Por que a ajuda de um T auxiliar melhora a resposta de um linfócito B?**

   Resposta comentada: O T auxiliar reconhece peptídeos no MHC de classe II e libera citocinas. Essas citocinas ajudam o linfócito B a se multiplicar e orientam o tipo de anticorpo produzido [B02-F3]. A cadeia causal é: mais proliferação e melhor diferenciação do linfócito B levam a mais plasmócitos e a uma memória mais eficaz [B02-F5, consulta indireta]. O T auxiliar não elimina o patógeno diretamente. Ele potencializa a ação de outras células.

2. **No exemplo, suponha que os anticorpos tenham caído muito antes do contato com o vírus V. A pessoa pode ainda se beneficiar da vacina?**

   Resposta comentada: Pode, mas isso depende do vírus. As células B de memória ainda podem proliferar em poucos dias e gerar novos plasmócitos [B02-F4]. Se o vírus V se disseminar lentamente, haverá tempo para essa resposta acontecer. Se ele se disseminar rapidamente, a proteção dependeria sobretudo do anticorpo que já estivesse presente [B02-F4]. A conclusão, portanto, é condicional, não automática.

## Síntese

- A resposta inata ativa as APC, que apresentam peptídeos no MHC. Linfócitos T e B específicos são selecionados e passam por expansão clonal.
- Linfócitos B originam plasmócitos, que secretam anticorpos, e células B de memória. Os T auxiliares coordenam a resposta, e os T citotóxicos eliminam células infectadas. Após a infecção, a maioria das células efetoras morre, e a memória permanece.
- A vacinação cria anticorpos e memória sem causar a doença. A proteção resultante depende do patógeno, das variantes e do hospedeiro, e por isso não é absoluta.

## Fontes consultadas

- **[B02-F3]** Marshall, J. S. et al. *An introduction to immunology and immunopathology*. Allergy, Asthma & Clinical Immunology, 2018;14(Suppl 2):49.
  - Texto original em inglês das seções: "The immune system: innate and adaptive immunity" (Innate immunity; Adaptive immunity; T cells and APCs; B cells); "Antibody-mediated vs. cell-mediated immunity"; "Passive vs. active immunization". Também foram consultadas as notas de leitura fornecidas. As figuras não foram inspecionadas.
  - https://doi.org/10.1186/s13223-018-0278-1 ; https://www.ebi.ac.uk/europepmc/webservices/rest/PMC6156898/fullTextXML
- **[B02-F4]** Bugya, Z. et al. *Multiple Levels of Immunological Memory and Their Association with Vaccination*. Vaccines, 2021;9(2):174.
  - Texto original em inglês das seções 1, 7, 11, 13 e 14, além das notas de leitura fornecidas. As figuras e tabelas não foram inspecionadas.
  - https://doi.org/10.3390/vaccines9020174 ; https://www.ebi.ac.uk/europepmc/webservices/rest/PMC7922266/fullTextXML
- **[B02-F5]** Clem, A. S. *Fundamentals of vaccine immunology*. Journal of Global Infectious Diseases, 2011;3(1):73.
  - Consulta indireta, apenas pelas notas de leitura (paráfrases) das seções "Components of the immune system", "Types of immunization", "Stimulation of immunity by vaccines" e "Summary". O texto original não foi lido.
  - https://doi.org/10.4103/0974-777X.77299 ; https://www.ebi.ac.uk/europepmc/webservices/rest/PMC3068582/fullTextXML