# Como um pequeno corte para de sangrar sem entupir o vaso

## Ideia central
O problema é simples e arriscado ao mesmo tempo: quando um vaso pequeno se rompe, o sangue precisa ser contido rapidamente, mas o tampão que fecha o vazamento não pode se espalhar e bloquear a circulação normal [B01-F5 – consulta indireta via notas de leitura]. O objetivo desta aula é explicar como vaso, plaquetas e proteínas da coagulação cooperam para vedar a lesão e como o organismo limita essa resposta ao local necessário. Ao final, você deverá entender por que o tampão inicial de plaquetas é frágil e precisa de reforço, e por que formar coágulo fora de controle seria tão perigoso quanto sangrar.

## Conceitos necessários
Endotélio é a camada de células que reveste o interior do vaso. Quando íntegro, ele mantém o sangue fluido porque produz substâncias que desfavorecem a agregação plaquetária, como óxido nítrico e prostaciclina [B01-F2 – consulta indireta via notas de leitura]. Abaixo dele fica a camada subendotelial, que contém colágeno e outras proteínas adesivas. Em condições normais, o sangue não toca essa camada.

Plaquetas são fragmentos celulares sem núcleo, derivados de megacariócitos, com papel central na vedação inicial [B01-F3]. Elas possuem grânulos que liberam mediadores e receptores de superfície que permitem grudar no local lesionado e umas nas outras.

Fator von Willebrand é uma glicoproteína adesiva presente no plasma e no subendotélio que funciona como ponte entre o colágeno exposto e a plaqueta [B01-F3]. Fibrinogênio é uma proteína solúvel produzida pelo fígado e precursora da fibrina, que define a resistência do coágulo [B01-F3]. Ele também conecta plaquetas vizinhas durante a agregação [B01-F2 – consulta indireta via notas de leitura].

Fator tecidual é uma glicoproteína presa à membrana, presente no tecido ao redor do vaso e em fibroblastos, que não tem contato com o sangue até a parede se romper. Ele é o iniciador principal da coagulação no organismo [B01-F3]. Protrombina é uma proteína plasmática que pode ser convertida na enzima trombina. Trombina converte fibrinogênio em fibrina e ativa o fator XIII, que cria ligações estabilizadoras entre filamentos de fibrina [B01-F3].

## Mecanismo passo a passo
### 1. O vaso lesionado muda e inicia a resposta
A lesão rompe o endotélio e expõe componentes subendoteliais antes separados do sangue, como colágeno e fator von Willebrand [B01-F3 – paráfrase em português sob mesma licença, a partir do texto original]. Ao mesmo tempo ocorre vasoconstrição, isto é, estreitamento do vaso por mecanismos reflexos e mediadores locais como endotelina e tromboxano A2 derivado de plaquetas [B01-F3]. Essa constrição reduz a perda sanguínea e aproxima as bordas da lesão [B01-F4 – consulta indireta via notas de leitura]. Portanto, o sinal inicial não é apenas o buraco: é a perda da superfície antitrombótica e o aparecimento de uma superfície que prende plaquetas e inicia a coagulação.

### 2. Plaquetas formam o tampão inicial
A hemostasia primária é a formação do tampão plaquetário a partir da interação entre plaquetas, parede vascular e proteínas adesivas [B01-F3]. Primeiro ocorre adesão: o fator von Willebrand liga o colágeno ao receptor GPIb da plaqueta, prendendo-a no local [B01-F3]. Plaquetas normalmente não aderem ao endotélio íntegro, de modo que essa ligação só se torna importante após a lesão.

Depois vem ativação. A plaqueta aderida muda de forma, emite pseudópodes e aumenta sua superfície, além de liberar o conteúdo de seus grânulos [B01-F3]. O cálcio liberado se liga a fosfolipídios que aparecem com a ativação e cria uma superfície para reunir fatores da coagulação [B01-F3]. Mediadores como ADP e tromboxano A2 recrutam outras plaquetas e ampliam o agregado [B01-F3 – paráfrase em português sob mesma licença, a partir do texto original].

Na agregação, o fibrinogênio conecta receptores IIb/IIIa de plaquetas vizinhas, permitindo que elas grudem umas nas outras [B01-F2 – consulta indireta via notas de leitura]. Forma-se assim um tampão que veda temporariamente a lesão, mas ainda é relativamente frouxo e reversível.

### 3. A coagulação produz trombina e fibrina
O tampão inicial oferece superfície para complexos de coagulação [B01-F3 – paráfrase em português sob mesma licença, a partir do texto original]. A exposição do fator tecidual inicia a coagulação fisiológica; as vias clássicas descritas em laboratório não representam dois circuitos independentes no organismo [B01-F2 – consulta indireta via notas de leitura].

No modelo atual, a iniciação ocorre quando fator tecidual liga fator VIIa e ativa os fatores IX e X. Essa quantidade inicial de trombina é pequena e pode ser contida por inibidores [B01-F3]. Em seguida há amplificação: a trombina ativa os fatores V e VIII, que servem como cofatores e aceleram novas reações [B01-F3]. Na propagação, os complexos tenase e protrombinase reunidos sobre a superfície plaquetária geram grande quantidade de trombina [B01-F3].

O passo decisivo é a formação da protrombinase, composta por fator Xa, fator Va, fosfolipídios de plaquetas e tecidos e cálcio, que converte protrombina em trombina [B01-F3]. A trombina então cliva o fibrinogênio solúvel em fibrina insolúvel e ativa o fator XIII [B01-F3].

### 4. A fibrina estabiliza e integra as duas hemostasias
Os filamentos de fibrina formam uma rede que sustenta o tampão e também pode reter hemácias [B01-F4 – consulta indireta via notas de leitura]. O fator XIII ativado cria ligações covalentes entre polímeros de fibrina incorporados ao tampão plaquetário, gerando um tampão secundário definitivo e mais resistente [B01-F3]. A contração das plaquetas aproxima as bordas e facilita o reparo [B01-F4 – consulta indireta via notas de leitura].

Por isso hemostasia primária e secundária são processos integrados, e não circuitos independentes [B01-F3 – paráfrase em português sob mesma licença, a partir do texto original]. Sem plaquetas ativadas faltaria superfície e sinalização para gerar trombina no local certo; sem fibrina, o agregado plaquetário se desfaria sob a pressão do fluxo. A falta de plaquetas ou de fatores compromete a contenção do sangramento, mostrando que a mesma lesão exige cooperação de vaso, células e proteínas [B01-F4 – consulta indireta via notas de leitura].

### 5. Freios locais e remoção posterior
A coagulação precisa ser contida porque o sangue continua passando ao lado do tampão. O equilíbrio entre tromboxano A2, que estimula agregação, e prostaciclina, que a inibe, ajuda a manter a agregação localizada e preservar o interior do vaso [B01-F3]. O endotélio saudável vizinho continua produzindo sinais antiagregantes.

Além disso existem anticoagulantes naturais que restringem a resposta. A antitrombina liga e inativa trombina e fatores como Xa, IXa, XIa e XIIa [B01-F3]. O inibidor da via do fator tecidual restringe o complexo fator tecidual/VIIa e o fator Xa [B01-F2 – consulta indireta via notas de leitura; B01-F3]. Na via da proteína C, a trombina ligada à trombomodulina do endotélio ativa a proteína C, que com a proteína S inativa os fatores Va e VIIIa e reduz a amplificação [B01-F3; B01-F2 – consulta indireta via notas de leitura].

Depois que o tecido começa a se reparar, a fibrinólise remove a fibrina. Ativadores como tPA convertem plasminogênio em plasmina, que degrada a fibrina em produtos de degradação [B01-F2 – consulta indireta via notas de leitura; B01-F3]. Esse sistema é ativado junto com a coagulação e serve para limitar o tamanho do coágulo [B01-F3]. Sua ação é controlada por inibidores como inibidor de ativador de plasminogênio, alfa-2 antiplasmina e inibidor da fibrinólise ativado por trombina, que protege o coágulo recém-formado [B01-F3]. Formação e remoção precisam de equilíbrio para manter temporariamente a vedação durante o reparo [B01-F2 – consulta indireta via notas de leitura].

### 6. Quando a proteção vira trombose
A hemostasia fisiológica contém o sangramento após lesão e permanece restrita ao local [B01-F5 – consulta indireta via notas de leitura]. A trombose é diferente porque há coágulo dentro da circulação em local, momento ou tamanho inadequados, podendo comprometer órgãos; a trombose venosa profunda é um exemplo [B01-F5 – consulta indireta via notas de leitura]. Alterações do controle podem causar tanto sangramento excessivo quanto formação de coágulos mesmo sem lesão aparente [B01-F5 – consulta indireta via notas de leitura]. Assim, a função protetora não torna todo coágulo benéfico: localização e controle importam [B01-F5 – consulta indireta via notas de leitura].

## Exemplo explicado
Imagine um pequeno corte na pele que atinge um vaso de pequeno calibre. Situação inicial: endotélio rompido, colágeno e fator tecidual expostos, sangue fluindo e vaso ainda aberto.

Etapas: primeiro o vaso se contrai, diminuindo o fluxo local. Plaquetas aderem por meio do fator von Willebrand, ativam-se, liberam ADP e produzem tromboxano A2, recrutando vizinhas. O fibrinogênio liga receptores IIb/IIIa e forma o tampão plaquetário. Quase ao mesmo tempo, fator tecidual inicia a geração de trombina sobre a superfície dessas plaquetas, com amplificação e propagação. A trombina gera fibrina e ativa o fator XIII, que entrelaça e estabiliza o tampão. Reguladores vizinhos impedem que o processo avance pelo vaso.

Resultado interpretado: o sangramento cessa porque a vedação mecânica inicial foi transformada em uma rede estável, e o vaso permanece parcialmente aberto ao redor. Limite da conclusão: este exemplo didático explica uma lesão pequena e localizada. Ele não permite prever o que ocorrerá em lesões extensas, deficiências hereditárias, uso de anticoagulantes ou risco individual de trombose, que dependem de avaliação clínica e laboratorial fora deste recorte.

## Confusões a evitar
1. Confundir tampão plaquetário com coágulo estável. O tampão resulta de adesão e agregação e veda temporariamente, mas é frágil diante do fluxo. O coágulo estável exige a rede de fibrina entrelaçada pelo fator XIII. A distinção é necessária porque explica por que defeitos de plaquetas e defeitos de fatores de coagulação causam sangramentos de formas diferentes, embora cooperem no mesmo objetivo.
2. Confundir impedir a produção de coágulo com dissolver fibrina já formada. Anticoagulantes naturais como antitrombina e via da proteína C reduzem a geração de trombina e fibrina, enquanto a fibrinólise por plasmina degrada a fibrina existente. A distinção importa porque são momentos diferentes: um controla o quanto se forma, o outro controla quanto tempo o material permanece durante o reparo [B01-F2 – consulta indireta via notas de leitura; B01-F3].

## Confira seu entendimento
1. Por que a exposição do subendotélio após uma lesão pequena tende a iniciar tanto o tampão plaquetário quanto a coagulação, em vez de apenas um deles?
Resposta comentada: Porque o mesmo evento expõe duas chaves diferentes. O colágeno e o fator von Willebrand prendem plaquetas e disparam adesão e ativação, enquanto o fator tecidual inicia a geração de trombina. O raciocínio causal é que vaso, plaquetas e proteínas dividem o mesmo ponto de partida anatômico, e a superfície plaquetária ativada acelera a coagulação, de modo que os dois braços se reforçam no local.
2. No exemplo do pequeno corte, o que aconteceria se houvesse agregação plaquetária normal, mas falha na geração de trombina e fibrina?
Resposta comentada: O tampão se formaria, porém permaneceria instável e poderia se soltar ou permitir ressangramento, porque faltaria a rede de fibrina estabilizada pelo fator XIII. A aplicação mostra a integração: a hemostasia primária veda provisoriamente, mas somente a hemostasia secundária consolida a vedação até o reparo.

## Síntese
- A lesão vascular combina vasoconstrição e exposição de colágeno, fator von Willebrand e fator tecidual, criando o ponto de partida comum para plaquetas e coagulação.
- Plaquetas aderem, ativam-se e agregam-se por fibrinogênio para formar o tampão inicial, cuja superfície permite gerar trombina, fibrina e estabilização pelo fator XIII.
- Anticoagulantes naturais, sinais endoteliais e fibrinólise mantêm o coágulo localizado e depois o removem, separando hemostasia útil de trombose prejudicial.

## Fontes consultadas
- [B01-F3] Palta, S.; Saroa, R.; Palta, A. Overview of the coagulation system. Indian Journal of Anaesthesia, 2014;58(5):515-523. Seções consultadas: Primary haemostasis, Common pathway, Current concept of coagulation, Naturally occurring anticoagulants in the body, Coagulation cascade, Fibrinolytic system. Texto original em inglês consultado diretamente via https://www.ebi.ac.uk/europepmc/webservices/rest/PMC4260295/fullTextXML . Paráfrase em português citada quando indicada, sob licença CC BY-NC-SA 3.0.
- [B01-F2 – consulta indireta via notas de leitura redigidas por IA] MSD Manual, versão profissional. Overview of Hemostasis. Michael B. Streiff; revisão por Ashkan Emadi; setembro de 2025. Seções consultadas: Platelets, Plasma Coagulation Factors, Regulation of Coagulation. Endereço fornecido: https://www.msdmanuals.com/professional/hematology/hemostasis/overview-of-hemostasis . Texto integral não fornecido; consulta limitada às paráfrases do pacote.
- [B01-F4 – consulta indireta via notas de leitura redigidas por IA] NHLBI/NIH. How Does Blood Clot? Atualização: 2022-03-24. Escopo: texto explicativo. Endereço fornecido: https://www.nhlbi.nih.gov/health/clotting-disorders/how-blood-clots . Texto integral não fornecido; consulta limitada às paráfrases do pacote.
- [B01-F5 – consulta indireta via notas de leitura redigidas por IA] NHLBI/NIH. What Are Blood Clotting Disorders? Atualização: 2022-03-24. Escopo: apresentação do tema. Endereço fornecido: https://www.nhlbi.nih.gov/health/clotting-disorders . Texto integral não fornecido; consulta limitada às paráfrases do pacote.
