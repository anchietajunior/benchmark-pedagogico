# Como o organismo contém uma pequena hemorragia e delimita a resposta

## Ideia central

Uma lesão pequena rompe a continuidade da parede de um vaso e abre passagem para o sangue. O problema fisiológico é duplo: interromper a perda sanguínea rapidamente e, ao mesmo tempo, impedir que a resposta se propague para além do ponto lesado. A hemostasia é definida como a parada do sangramento, resultado de interações entre vaso, plaquetas, proteínas da coagulação e o sistema fibrinolítico [B01-F3]. O objetivo desta aula é explicar como esses componentes cooperam para formar e depois remover um coágulo localizado.

## Conceitos necessários

O endotélio é a camada de células que reveste internamente o vaso; quando íntegro, exibe propriedades antitrombóticas [B01-F3]. O subendotélio, camada logo abaixo, é pró-trombótico e contém colágeno e fator de von Willebrand (vWF), uma glicoproteína que liga colágeno a receptores plaquetários [B01-F3].

Plaquetas são fragmentos celulares sem núcleo, derivados de megakaryocytes, que formam o tampão inicial e oferecem superfície para os complexos de coagulação [B01-F3]. Fatores de coagulação são, em sua maioria, zimogênios: proteínas circulantes inativas, produzidas no fígado, que ganham a letra "a" quando ativadas [B01-F3]. A trombina é a enzima central dessa etapa, e o fibrinogênio é seu substrato solúvel, convertido em fibrina insolúvel [B01-F3].

## Mecanismo passo a passo

### 1. O que muda no vaso lesionado

A agressão vascular provoca vasoconstrição por reflexo neurogênico e por mediadores locais liberados, como endotelina e tromboxano A2 plaquetário [B01-F3]. O estreitamento reduz a perda de sangue [B01-F4]. Ao mesmo tempo, o endotélio deixa de separar o sangue de componentes subendoteliais, expondo colágeno, vWF e fator tecidual [B01-F3]. Essa exposição é o evento inicial: sem ela, as plaquetas não encontram superfície à qual aderir, e o fator tecidual permanece fora do alcance do plasma.

### 2. Adesão, ativação e agregação das plaquetas

A adesão depende de o vWF funcionar como ponte entre o colágeno subendotelial e o receptor plaquetário GpIb [B01-F3]. Plaquetas aderidas mudam de forma, formando pseudópodes que aumentam sua superfície, e sofrem degranulação [B01-F3]. Desse processo saem ADP e cálcio, entre outros mediadores; o cálcio se liga a fosfolipídios expostos na superfície plaquetária e cria o ambiente para montar os complexos de coagulação [B01-F3].

A agregação é o passo seguinte: o ADP altera a conformação do receptor GpIIb/IIIa, permitindo que o fibrinogênio conecte plaquetas vizinhas [B01-F2]. O tromboxano A2, produzido por plaquetas ativadas, amplia esse recrutamento, e o conjunto forma o tampão que oclui temporariamente a lesão [B01-F3]. A prostaciclina endotelial inibe a agregação, de modo que o equilíbrio entre tromboxano A2 e prostaciclina restringe a agregação ao local e preserva a luz do vaso [B01-F3].

### 3. Da ativação dos fatores à trombina e à fibrina

O fator tecidual exposto se liga ao fator VIIa e ativa os fatores IX e X; o pequeno Xa formado gera pouca trombina, quantidade que seria insuficiente e que o inibidor da via do fator tecidual pode interromper [B01-F3]. Na amplificação, a trombina já formada ativa os fatores V e VIII, que funcionam como cofatores [B01-F3]. Na propagação, Xa, Va, fosfolipídios e cálcio formam o complexo protrombinase sobre superfícies celulares, convertendo protrombina em trombina em quantidade robusta [B01-F3]. A trombina então cliva o fibrinogênio em fibrina e ativa o fator XIII [B01-F3]. Observação de correção: em um trecho do material fornecido aparece "TF-VIIIa"; o restante do mesmo texto e as notas indicam o complexo fator tecidual/VIIa [B01-F3].

### 4. Por que a fibrina estabiliza o tampão

O fator XIII ativado liga covalentemente os polímeros de fibrina, dando força e estabilidade à rede incorporada ao tampão plaquetário [B01-F3]. A fibrina, portanto, não substitui as plaquetas: ela sustenta o agregado, e pode ainda reter hemácias [B01-F4]. Isso explica por que hemostasia primária e secundária são processos integrados — o tampão plaquetário fornece a superfície onde a coagulação acontece, e a coagulação fornece a rede que impede que esse tampão se desfaça [B01-F3].

### 5. Como a resposta é limitada

A antitrombina inibe a trombina e outras enzimas ativadas, restringindo a coagulação [B01-F3]. O TFPI limita o complexo fator tecidual/VIIa e o fator Xa [B01-F2]. A trombina ligada à trombomodulina ativa a proteína C, que com a proteína S inativa os fatores Va e VIIIa, reduzindo a amplificação [B01-F2]. Em paralelo, a fibrinólise degrada a fibrina: ativadores como o tPA convertem plasminogênio em plasmina, e sua atividade é contida pela alfa-2-antiplasmina e por inibidores do ativador [B01-F2], [B01-F3]. Formação e remoção precisam ficar em equilíbrio para manter a vedação apenas durante o reparo [B01-F2].

### 6. Hemostasia fisiológica versus trombose

A formação fisiológica de coágulo contém o sangramento após uma lesão [B01-F5], e a vasoconstrição e a exposição do fator tecidual são respostas proporcionais a essa lesão [B01-F3]. A trombose ocorre quando o controle falha: os coágulos se formam mesmo sem lesão aparente ou se propagam dentro da circulação, podendo comprometer órgãos, como na trombose venosa profunda [B01-F5]. A diferença, então, não é a natureza do coágulo, mas a localização e o controle da resposta.

## Exemplo explicado

Situação inicial: um corte superficial rompe o endotélio de um pequeno vaso, expondo colágeno e vWF. Etapas: o vaso se estreita; plaquetas aderem pelo eixo vWF–GpIb, mudam de forma e liberam ADP; o ADP altera GpIIb/IIIa e o fibrinogênio conecta plaquetas vizinhas, formando o tampão; o fator tecidual inicia a coagulação, e a trombina gerada converte fibrinogênio em fibrina e ativa o fator XIII. Resultado interpretado: a rede de fibrina, covalentemente ligada, transforma um agregado frágil em vedação estável, enquanto a antitrombina, o TFPI e a via da proteína C limitam a reação, e a plasmina remove depois o material excedente. Limite da conclusão: esse encadeamento descreve o princípio geral; não indica dose, diagnóstico nem conduta, e a extensão real depende de fatores individuais não avaliados aqui.

## Confusões a evitar

1. **Tratar plaquetas e coagulação como circuitos independentes.** No organismo, o tampão plaquetário é a superfície onde os complexos de coagulação se montam, e a fibrina devolve estabilidade a esse tampão [B01-F3]. São etapas encadeadas, não alternativas.
2. **Confundir impedir a formação do coágulo com degradar a fibrina já formada.** Antitrombina, TFPI e proteína C restringem a produção de trombina; a fibrinólise remove a fibrina depositada [B01-F2]. São mecanismos distintos, e essa distinção explica por que uma resposta pode ser excessiva mesmo com a fibrinólise funcionando.

## Confira seu entendimento

1. Por que a ativação plaquetária é condição para que a coagulação seja eficiente?
Resposta comentada: porque a propagação depende de complexos como tenase e protrombinase montados sobre fosfolipídios expostos na superfície plaquetária [B01-F3]. Sem ativação, essa superfície não existe; sem ela, a produção de trombina fica pequena, a fibrina não se forma em quantidade suficiente e o tampão permanece instável.
2. No exemplo do corte superficial, o que aconteceria se as plaquetas aderissem, mas não agregassem?
Resposta comentada: a adesão ligaria plaquetas ao colágeno, mas sem a mudança conformacional de GpIIb/IIIa o fibrinogênio não conectaria plaquetas vizinhas [B01-F2]. O tampão não se consolidaria, a superfície para a coagulação seria reduzida e a contenção do sangramento ficaria comprometida, pois a barreira depende da cooperação entre as duas etapas.

## Síntese

- A lesão expõe subendotélio e fator tecidual, e a vasoconstrição reduz o fluxo: esses dois eventos abrem e limitam a resposta ao mesmo tempo [B01-F3].
- Plaquetas aderem, ativam-se e agregam, formando o tampão que também serve de superfície para gerar trombina e fibrina [B01-F3], [B01-F2].
- O coágulo só é útil enquanto provisório e localizado: inibidores restringem a coagulação, a fibrinólise remove a fibrina e a perda desse controle caracteriza a trombose [B01-F2], [B01-F5].

## Fontes consultadas

- [B01-F3] Palta, S.; Saroa, R.; Palta, A. *Overview of the coagulation system*. Indian Journal of Anaesthesia, 2014;58(5):515-523. Seções "Primary haemostasis", "Common pathway", "Current concept of coagulation", "Naturally occurring anticoagulants in the body", "Fibrinolytic system" — texto original em inglês fornecido, com paráfrase em português. DOI: https://doi.org/10.4103/0019-5049.144643
- [B01-F2] Streiff, M. B.; Emadi, A. (revisão). *Overview of Hemostasis*. MSD Manual, versão profissional, setembro de 2025. Seções "Platelets", "Plasma Coagulation Factors", "Regulation of Coagulation" — consulta indireta, por notas de leitura. https://www.msdmanuals.com/professional/hematology/hemostasis/overview-of-hemostasis
- [B01-F4] NHLBI/NIH. *How Does Blood Clot?* Atualização 2022-03-24 — consulta indireta, por notas de leitura. https://www.nhlbi.nih.gov/health/clotting-disorders/how-blood-clots
- [B01-F5] NHLBI/NIH. *What Are Blood Clotting Disorders?* Atualização 2022-03-24 — consulta indireta, por notas de leitura. https://www.nhlbi.nih.gov/health/clotting-disorders

As notas B01-F2, B01-F4 e B01-F5 são paráfrases redigidas por IA, sem revisão humana especializada; não foram consultadas as obras originais correspondentes. As imagens, tabelas e figuras citadas nos materiais não foram inspecionadas.