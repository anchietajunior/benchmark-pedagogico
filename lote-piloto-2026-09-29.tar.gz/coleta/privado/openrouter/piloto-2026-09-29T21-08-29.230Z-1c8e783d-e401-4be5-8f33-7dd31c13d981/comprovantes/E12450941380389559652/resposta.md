# Resposta imune adaptativa: reconhecimento, memória e vacinação

## Ideia central

A resposta imune adaptativa reconhece alvos específicos, mobiliza mecanismos para combatê-los e pode deixar células capazes de responder em encontros futuros. Estudaremos como linfócitos B e T cooperam nesse processo e como a vacinação busca antecipá-lo. A ideia principal é distinguir **reconhecimento, resposta efetora e memória**, sem confundir memória com proteção absoluta. [B02-F3; B02-F4]

## Conceitos necessários

**Antígeno** é uma estrutura reconhecida especificamente pelo sistema imune; pode ser, por exemplo, uma proteína de um vírus, não necessariamente o agente inteiro. Os **linfócitos B e T** são células da resposta adaptativa com receptores que reconhecem determinados alvos. Linfócitos **virgens** ainda não participaram de uma resposta ao antígeno correspondente. [B02-F3; B02-F4]

**Células apresentadoras de antígeno**, ou APC, capturam material e exibem fragmentos para reconhecimento pelos T. Destacam-se as células dendríticas. O **complexo principal de histocompatibilidade**, ou MHC, reúne proteínas que expõem esses fragmentos, chamados **peptídeos**, na superfície celular. **Citocinas** são proteínas de comunicação que regulam a atividade de outras células. [B02-F3]

**Plasmócitos** são células derivadas de B especializadas em secretar **anticorpos**, proteínas que se ligam a antígenos. **Células efetoras** executam funções de combate; **células de memória** persistem e podem participar de respostas posteriores. Essas funções não são equivalentes. [B02-F3; B02-F4]

## Mecanismo passo a passo

### 1. Da detecção inicial à apresentação

A imunidade inata responde rapidamente, reconhecendo padrões compartilhados por agentes infecciosos e mobilizando células e sinais inflamatórios. Isso favorece a ativação das APC, conectando a defesa inicial à resposta adaptativa. Células dendríticas capturam material, processam proteínas e apresentam peptídeos aos T. Nos linfonodos, o encontro entre APC e linfócitos aumenta a chance de reconhecimento específico. [B02-F3]

O receptor do T, chamado **TCR**, reconhece o conjunto peptídeo–MHC. Esse reconhecimento, acompanhado dos sinais adequados de ativação, permite a resposta do linfócito correspondente. Não se trata de ativar todos os T indiscriminadamente. [B02-F3]

Aqui, estudamos a memória específica dos linfócitos. Isso não exige afirmar que a imunidade inata nunca se modifica: B02-F4 descreve a imunidade inata treinada, diferente da memória adaptativa convencional. [B02-F4]

### 2. B reconhecem; plasmócitos secretam; anticorpos atuam

O B reconhece diretamente o antígeno por anticorpos presentes em sua superfície. Diferentemente do T, não depende de outra célula apresentar peptídeo–MHC para esse reconhecimento inicial. Em respostas a proteínas com ajuda de T, o B também internaliza o antígeno e apresenta peptídeos a T auxiliares, recebendo sinais que favorecem sua proliferação e diferenciação. [B02-F3; B02-F4]

Parte dos B ativados origina plasmócitos. Os anticorpos secretados podem bloquear a ação de toxinas ou vírus e facilitar a captura de agentes por células que os englobam. Também podem acionar o complemento, conjunto de proteínas que participa da eliminação de microrganismos. Portanto, reconhecer o alvo orienta mecanismos de combate, mas não significa destruí-lo sozinho. [B02-F3]

### 3. T auxiliares coordenam; T citotóxicos eliminam células-alvo

Os **T auxiliares, identificados como CD4+**, reconhecem peptídeos apresentados em MHC de classe II, presente em determinadas células imunes. Sua função central é coordenar: seus sinais ajudam B e outras células a desenvolver respostas apropriadas. [B02-F3]

Os **T citotóxicos, identificados como CD8+**, reconhecem peptídeos em MHC de classe I, presente nas células nucleadas. Quando efetores, podem induzir **apoptose**, uma forma programada de morte, em células infectadas que exibem o alvo correspondente. Assim, anticorpos podem atuar sobre vírus fora das células, enquanto T citotóxicos ajudam a eliminar células já infectadas. São funções complementares. [B02-F3]

### 4. Expansão clonal e persistência

A **expansão clonal** é a multiplicação dos linfócitos específicos ativados, aumentando o número de células capazes de responder ao alvo. Seus descendentes originam efetores e populações de memória. Isso explica parte da demora da resposta inicial: reconhecer não basta; é necessário ampliar e especializar a população celular. [B02-F3; B02-F4]

Após o controle do estímulo, grande parte dos efetores desaparece, mas B e T de memória podem persistir. Também existem plasmócitos de vida longa, que mantêm a produção de anticorpos. Portanto, a descrição de plasmócitos de vida curta em B02-F3 não deve ser generalizada a todos: B02-F4 distingue explicitamente as duas populações. [B02-F3; B02-F4]

### 5. Novo contato e resposta de memória

No reencontro com o antígeno, anticorpos já presentes podem agir imediatamente. Paralelamente, há mais linfócitos específicos preparados para responder: B de memória proliferam e originam novos plasmócitos; T de memória retomam funções efetoras. A resposta tende, assim, a ser mais rápida e eficiente. [B02-F4]

A qualidade também pode melhorar. Durante respostas B com ajuda de T, são selecionadas células cujos receptores apresentam maior **afinidade**, isto é, maior força de ligação ao alvo. Isso pode resultar em anticorpos que reconhecem melhor o antígeno, embora nem todas as células de memória tenham afinidade igual. [B02-F4]

### 6. Vacinação e limites da proteção

A vacinação busca provocar imunização ativa: o próprio organismo responde ao estímulo antigênico e estabelece mecanismos de defesa sem precisar enfrentar a doença correspondente. Reforços podem aproveitar células de memória já formadas para ampliar a resposta. [B02-F3; B02-F4]

Entretanto, proteção depende da quantidade, função e localização dos anticorpos, da resposta celular e das características do agente. Um patógeno de disseminação rápida pode avançar antes da produção de novos anticorpos; alterações antigênicas podem reduzir o reconhecimento. Idade e estado imune também influenciam. Impedir a infecção e limitar a doença são resultados distintos. [B02-F4]

## Exemplo explicado

Considere uma pessoa sem exposição anterior a um vírus hipotético. Ela recebe uma vacina que, neste exemplo, consegue induzir respostas B e T contra antígenos virais. Essa é uma condição didática, não uma propriedade garantida de qualquer vacina. [B02-F3; B02-F4]

Inicialmente, APC apresentam peptídeos e ativam T específicos; B reconhecem antígenos e recebem ajuda de T auxiliares. A expansão gera efetores, plasmócitos e células de memória. Plasmócitos de vida longa passam a sustentar parte dos anticorpos disponíveis. [B02-F3; B02-F4]

Meses depois, ocorre contato com o vírus correspondente. Anticorpos presentes podem bloquear parte dos vírus; se algumas células forem infectadas, T citotóxicos específicos podem combatê-las, enquanto células de memória ampliam a resposta. [B02-F4]

O resultado possível é controle mais rápido e menor desenvolvimento de doença, mesmo sem impedir toda infecção. O exemplo demonstra um mecanismo plausível, não permite calcular proteção individual nem garantir o mesmo resultado diante de variantes antigênicas. [B02-F4]

## Confusões a evitar

1. **“Anticorpos são células de memória.”** Anticorpos são proteínas; não proliferam. B de memória são células que podem gerar novos plasmócitos. Plasmócitos de vida longa, por sua vez, mantêm a secreção de anticorpos. [B02-F4]

2. **“Ter memória garante proteção absoluta.”** A resposta precisa reconhecer o agente e agir a tempo. Memória pode limitar a doença sem bloquear a entrada ou a multiplicação inicial do patógeno. [B02-F4]

## Confira seu entendimento

1. **Por que a expansão clonal favorece uma resposta específica?**

   **Resposta comentada:** Ela aumenta justamente os linfócitos ativados pelo alvo correspondente. Assim, amplia a quantidade de efetores capazes de combatê-lo e contribui para formar memória. [B02-F3; B02-F4]

2. **No exemplo, haveria contradição se ocorresse infecção após a vacina?**

   **Resposta comentada:** Não. Os anticorpos poderiam não bloquear todos os vírus, mas células de memória ainda poderiam acelerar o controle posterior. Infecção não significa, automaticamente, ausência de benefício imunológico. [B02-F4]

## Síntese

- A imunidade inata favorece a apresentação; B e T reconhecem antígenos de maneiras diferentes.
- Expansão e diferenciação geram efetores, células de memória e plasmócitos com diferentes durações.
- A vacinação prepara respostas futuras, mas proteção depende da interação entre defesa, agente e organismo.

## Fontes consultadas

- **[B02-F3]** Marshall, J. S. et al. *An introduction to immunology and immunopathology*. Consulta ao texto original incorporado ao material fornecido: “The immune system: innate and adaptive immunity”, incluindo “Innate immunity”, “Adaptive immunity”, “T cells and APCs” e “B cells”; “Antibody-mediated vs. cell-mediated immunity”; “Passive vs. active immunization”. 2018. https://doi.org/10.1186/s13223-018-0278-1
- **[B02-F4]** Bugya, Z. et al. *Multiple Levels of Immunological Memory and Their Association with Vaccination*. Consulta ao texto original incorporado ao material fornecido: seções 1, 7, 11, 13 e 14, incluindo subseções disponibilizadas sobre vacinação. 2021. https://doi.org/10.3390/vaccines9020174