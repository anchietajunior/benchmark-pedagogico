# Hemostasia e Coagulação: Da Resposta Vascular à Resolução do Coágulo

## Ideia central
O organismo precisa conter rapidamente a perda de sangue diante de lesões vasculares sem interromper o fluxo sanguíneo sistêmico [B01-F3, B01-F4]. A hemostasia é o conjunto coordenado de respostas biológicas que cria um tampão mecânico provisório no ponto exato da ruptura, ancora uma malha proteica resistente sobre ele e restringe ativamente esse coágulo à área danificada para garantir a permeabilidade vascular [B01-F2, B01-F3].

## Conceitos necessários
* **Endotélio vascular:** Camada celular que reveste o interior dos vasos; quando intacta, produz substâncias como óxido nítrico e prostaciclina, que mantêm a superfície não trombogênica [B01-F2, B01-F3].
* **Matriz subendotelial:** Camada subjacente rica em colágeno e fator tecidual (TF), mantida isolada do contato com o sangue em vasos íntegros [B01-F3].
* **Plaquetas:** Fragmentos celulares derivados de megacariócitos com grânulos citoplasmáticos e receptores de superfície, responsáveis pelo selamento mecânico primário [B01-F3].
* **Fatores de coagulação:** Zimogênios (enzimas precursoras inativas) plasmáticos que, ativados sequencialmente, amplificam a resposta química até gerar trombina [B01-F3].
* **Trombina:** Enzima central que cliva o fibrinogênio solúvel em monômeros de fibrina insolúvel e potencializa diversas alças de retroalimentação [B01-F2, B01-F3].
* **Fibrinólise:** Processo enzimático pelo qual a plasmina cliva a fibrina, permitindo a dissolução gradual do coágulo durante o reparo tecidual [B01-F2, B01-F3].

## Mecanismo passo a passo

### 1. Resposta vascular e início do processo
A ruptura física da parede vascular causa vasoconstrição imediata reflexa mediada por mecanismos neurogênicos e substâncias locais [B01-F3, B01-F4]. Esse estreitamento arteriolar diminui transitoriamente o fluxo local, reduzindo o extravasamento e a força mecânica de cisalhamento [B01-F3, B01-F4]. Concomitantemente, o dano rompe a barreira endotelial protetora, expondo colágeno subendotelial e fator tecidual (TF), antes isolados dos elementos sanguíneos [B01-F3]. O contato direto do sangue com esse microambiente trombogênico dispara tanto a fixação das plaquetas quanto a ativação proteica da cascata [B01-F2, B01-F3].

### 2. Formação do tampão plaquetário
O fator von Willebrand (vWF) liga-se ao colágeno exposto e ancora o receptor plaquetário GpIb, garantindo a **adesão** inicial mesmo sob fluxo sanguíneo rápido [B01-F3]. Uma vez aderidas, as plaquetas sofrem **ativação**: reorganizam seu citoesqueleto emitindo pseudópodes, expõem fosfolipídios aniônicos de membrana e degranulam grânulos alfa e densos [B01-F3]. 

A secreção libera cálcio, adenosina difosfato (ADP) e estimula a síntese de tromboxano A2 (TxA2) [B01-F3]. Esses mediadores recrutam e ativam plaquetas vizinhas adicionais [B01-F3]. A ativação induz mudança conformacional nos receptores de integrina GpIIb/IIIa, permitindo que moléculas bivalentes de fibrinogênio plasmático se interliguem entre plaquetas adjacentes, gerando a **agregação** plaquetária e formando o tampão hemostático primário [B01-F2, B01-F3].

### 3. Cascata de coagulação: produção de trombina e fibrina
O fator tecidual (TF) exposto liga-se ao fator VIIa presente no plasma, constituindo o complexo iniciador da coagulação *in vivo* [B01-F2, B01-F3]. Esse complexo ativa pequenas quantidades dos fatores X e IX [B01-F3]. O fator Xa converte vestígios de protrombina em trombina inicial [B01-F3]. 

Como os inibidores fisiológicos limitam precocemente essa primeira reação, ocorre uma fase de amplificação: essa pequena carga de trombina liga-se às plaquetas ativadas e ativa os cofatores V e VIII, bem como o fator XI [B01-F3]. Na superfície fosfolipídica das plaquetas, agrupam-se os complexos tenase (IXa-VIIIa) e protrombinase (Xa-Va, cálcio e fosfolipídios) [B01-F3]. Isso desencadeia uma propagação massiva que gera uma explosão de trombina [B01-F3]. A trombina cliva fragmentos peptídicos do fibrinogênio, gerando monômeros de fibrina que se polimerizam espontaneamente [B01-F3].

### 4. Estabilização e integração funcional
Os polímeros de fibrina iniciais mantêm-se por interações fracas [B01-F3]. A própria trombina ativa o fator XIII (fator estabilizador de fibrina), uma enzima que estabelece ligações cruzadas covalentes entre os filamentos de fibrina [B01-F3]. Essa malha insolúvel enreda o tampão plaquetário e as hemácias, consolidando o coágulo secundário [B01-F3, B01-F4]. 

A hemostasia primária e a secundária não ocorrem de forma separada: a membrana fosfolipídica das plaquetas ativadas serve de plataforma física indispensável para a montagem dos complexos enzimáticos da coagulação [B01-F3]. Em contrapartida, a fibrina gerada pelas proteínas plasmáticas ancora mecanicamente as plaquetas, impedindo que o tampão seja desfeito pelo fluxo sanguíneo [B01-F2, B01-F3, B01-F4].

### 5. Mecanismos reguladores e fibrinólise
Para que o coágulo não oclua o vaso ou se espalhe sistemicamente, três eixos anticoagulantes atuam em paralelo:
* O inibidor da via do fator tecidual (TFPI) inativa o complexo TF-VIIa e o fator Xa [B01-F2, B01-F3].
* A trombomodulina, presente no endotélio íntegro vizinho, sequestra trombina livre; esse complexo ativa a Proteína C, que, com o cofator Proteína S, inativa proteoliticamente os cofatores Va e VIIIa, cessando a amplificação [B01-F2, B01-F3].
* A antitrombina neutraliza diretamente enzimas ativas circulantes, principalmente trombina e fator Xa [B01-F2, B01-F3].

Simultaneamente ao estancamento, o endotélio adjacente secreta o ativador do plasminogênio tecidual (tPA) [B01-F2, B01-F3]. O tPA converte o plasminogênio retido no coágulo em plasmina ativa, enzima que cliva as redes de fibrina em produtos solúveis de degradação da fibrina (incluindo D-dímeros), desfazendo o arcabouço à medida que o tecido cicatriza [B01-F2, B01-F3].

### 6. Hemostasia fisiológica versus trombose
A hemostasia fisiológica é uma resposta localizada, autolimitada e protetora frente a uma injúria, visando selar a descontinuidade parietal e restabelecer a integridade tecidual sem impedir o fluxo vascular [B01-F3, B01-F5]. Já a trombose constitui um fenômeno patológico no qual há formação ou extensão desregulada de massa intravascular sólida (trombo), mesmo na ausência de extravasamento ativo, provocada por desequilíbrio entre estímulos pró-coagulantes e inibidores naturais [B01-F3, B01-F5]. A trombose obstrui o lúmen vascular e compromete criticamente a perfusão de órgãos vitais [B01-F5].

## Exemplo explicado
Considere uma punção capilar superficial na ponta de um dedo.

* **Situação inicial:** A agulha rompe uma pequena vênula dérmica, gerando sangramento puntiforme e expondo colágeno e TF ao sangue.
* **Etapas:** O vaso sofre vasoconstrição imediata [B01-F3, B01-F4]. Plaquetas aderem ao subendotélio por meio do vWF e degranulam ADP e TxA2, formando em segundos um tampão plaquetário frouxo [B01-F3]. Sobre a superfície dessas plaquetas ativadas, o complexo protrombinase produz trombina, que polimeriza fibrinogênio em fibrina insolúvel e ativa o fator XIII [B01-F3]. O tampão torna-se rígido e cessa o sangramento visível [B01-F3, B01-F4]. Enquanto isso, a antitrombina e a Proteína C ativada nas margens endoteliais sadias impedem que a reação avance para o lúmen livre [B01-F2, B01-F3]. Horas após, o tPA endotelial ativa a plasmina, remodelando a fibrina conforme o endotélio se regenera [B01-F2, B01-F3].
* **Resultado interpretado:** A perda sanguínea externa foi bloqueada em poucos minutos e a circulação do tecido vizinho manteve-se desimpedida [B01-F3, B01-F4].
* **Limite da conclusão:** O sucesso observado descreve lesões microvasculares puntiformes sob pressão hidrostática moderada; injúrias arteriais volumosas ou cavitárias demandam intervenção hemostática cirúrgica mecânica adicional [B01-F3].

## Confusões a evitar

1. **Julgar que hemostasia primária e secundária ocorrem como eventos cronológicos isolados:** Não se trata de uma sequência onde a agregação plaquetária termina integralmente para que os fatores plasmáticos iniciem sua ação; a exposição ao fator tecidual ocorre no mesmo instante do contato plaquetário com o colágeno, e a ativação das enzimas da coagulação depende diretamente dos fosfolipídios expostos na membrana plaquetária para amplificar a geração de trombina [B01-F2, B01-F3].
2. **Confundir a ação dos anticoagulantes fisiológicos com a fibrinólise:** Os inibidores fisiológicos (como antitrombina, TFPI e complexo Proteína C/S) impedem a geração continuada de trombina e a formação de nova fibrina; eles não destroem a fibrina previamente depositada [B01-F2, B01-F3]. A clivagem e dissolução da malha de fibrina estruturada competem exclusivamente ao sistema fibrinolítico mediado pela plasmina [B01-F2, B01-F3].

## Confira seu entendimento

1. **Por que uma falha congênita ou inibição medicamentosa do fator XIII leva a ressangramentos tardios, mesmo que a formação do tampão plaquetário e a produção inicial de fibrina estejam normais?**
*Resposta comentada:* A conversão de fibrinogênio em monômeros de fibrina pela trombina forma uma trama inicial unida apenas por interações fracas e não covalentes [B01-F3]. É o fator XIIIa que catalisa a formação de ligações cruzadas covalentes entre os polímeros de fibrina, conferindo rigidez mecânica e estabilidade química contra o estresse do pulso sanguíneo [B01-F3]. Na sua ausência, o coágulo frouxo inicial sela a ferida por pouco tempo, mas é facilmente fragmentado e carreado pelo fluxo circulatório antes da cicatrização completa, precipitando o ressangramento tardio [B01-F3].

2. **No exemplo da pequena punção superficial, qual mecanismo garante que as moléculas de trombina geradas no sítio lesado não continuem convertendo fibrinogênio em fibrina ao longo de todo o leito vascular adjacente?**
*Resposta comentada:* Nas bordas intactas da lesão, as células endoteliais não danificadas expressam ativamente trombomodulina e heparansulfato [B01-F2, B01-F3]. A trombina que escapa do foco é capturada pela trombomodulina, perdendo a capacidade de clivar fibrinogênio e passando a ativar a Proteína C, que inativa os cofatores Va e VIIIa [B01-F2, B01-F3]. Ao mesmo tempo, a antitrombina potencializada inativa as frações enzimáticas livres de trombina e fator Xa [B01-F2, B01-F3]. Esse isolamento bioquímico confina rigorosamente a catálise pró-coagulante ao microambiente da ferida [B01-F2, B01-F3].

## Síntese
* A hemostasia inicial integra vasoconstrição com adesão, secreção e agregação de plaquetas através de receptores de membrana acoplados a ligantes da matriz extravascular [B01-F3].
* A coagulação secundária gera trombina na superfície plaquetária ativada, clivando fibrinogênio em fibrina, que é covalentemente estabilizada pelo fator XIII para conferir resistência mecânica duradoura ao tampão [B01-F3].
* O balanço anticoagulante (TFPI, Proteína C/S e antitrombina) e a degradação enzimática pela plasmina limitam fisicamente o coágulo e garantem a reconstituição da permeabilidade vascular [B01-F2, B01-F3].

## Fontes consultadas
* [B01-F2] MSD Manual, versão profissional. *Overview of Hemostasis*, 2025. Consulta indireta com base em notas de leitura do material didático fornecido.
* [B01-F3] Palta, S.; Saroa, R.; Palta, A. *Overview of the coagulation system*. Indian Journal of Anaesthesia, 2014;58(5):515-523. Disponível em: https://www.ebi.ac.uk/europepmc/webservices/rest/PMC4260295/fullTextXML. Consulta direta ao texto original fornecido.
* [B01-F4] NHLBI/NIH. *How Does Blood Clot?*, 2022. Disponível em: https://www.nhlbi.nih.gov/health/clotting-disorders/how-blood-clots. Consulta indireta com base em notas de leitura do material didático fornecido.
* [B01-F5] NHLBI/NIH. *What Are Blood Clotting Disorders?*, 2022. Disponível em: https://www.nhlbi.nih.gov/health/clotting-disorders. Consulta indireta com base em notas de leitura do material didático fornecido.