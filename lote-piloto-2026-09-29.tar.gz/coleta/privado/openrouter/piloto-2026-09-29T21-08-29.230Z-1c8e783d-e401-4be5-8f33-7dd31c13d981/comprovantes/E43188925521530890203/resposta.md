# Resposta imune adaptativa e memória imunológica

## Ideia central

O corpo enfrenta agentes que nunca viu antes e, ainda assim, consegue "lembrar" deles. A primeira defesa, a imunidade inata, é rápida, mas não distingue um patógeno de outro nem guarda registro do encontro. A imunidade adaptativa é específica e mais lenta na primeira vez, porém deixa células de memória que tornam a resposta seguinte mais rápida e eficiente [B02-F3]. O objetivo desta aula é entender como linfócitos B e T reconhecem um antígeno, como se forma a memória e por que a vacinação aproveita esse processo sem que isso signifique proteção absoluta.

## Conceitos necessários

**Antígeno** é qualquer molécula, geralmente proteína ou carboidrato de um microrganismo, que pode ser reconhecida pelo sistema imune [B02-F3].

**Célula apresentadora de antígeno (APC)** é uma célula, como a dendrítica ou o macrófago, que engole o agente, o digere em fragmentos (peptídeos) e os exibe na superfície ligados a moléculas do **MHC** (complexo principal de histocompatibilidade). MHC de classe I existe em todas as células nucleadas e mostra peptídeos produzidos dentro da célula; MHC de classe II existe em células imunes, como dendríticas, macrófagos e B, e mostra peptídeos capturados do meio externo [B02-F3].

**Linfócitos T** amadurecem no timo e portam um único tipo de receptor (TCR) por célula; só reconhecem peptídeos apresentados em MHC [B02-F3]. **Linfócitos B** portam anticorpos de superfície que funcionam como receptor e reconhecem o antígeno íntegro, sem precisar de APC [B02-F3].

**Anticorpos** são proteínas secretadas por **plasmócitos**, células derivadas de B ativados. **Células de memória** são linfócitos B ou T que sobrevivem após a infecção e continuam aptos a responder [B02-F3].

## Mecanismo passo a passo

### 1. Do reconhecimento inato à apresentação de antígenos

Quando um agente ultrapassa pele e mucosas, células inatas o detectam por receptores de reconhecimento de padrões, que identificam estruturas comuns a muitos patógenos, como componentes de parede bacteriana [B02-F3]. Essa detecção dispara inflamação e mobiliza APCs. As células dendríticas fagocitam o agente, processam seus antígenos e migram para os linfonodos exibindo peptídeos em MHC [B02-F3]. É aqui que inato e adaptativo se conectam: sem a apresentação, o linfócito T específico não consegue reconhecer o antígeno. Como os T circulam pelo sangue e pela linfa e se acumulam nos linfonodos junto das APCs, a chance de o raro T correspondente encontrar "seu" peptídeo aumenta [B02-F3].

### 2. Linfócitos B, plasmócitos e anticorpos

O B reconhece diretamente o antígeno nativo pelo receptor de superfície. Ativado e auxiliado por citocinas de T auxiliares, prolifera e se diferencia em plasmócitos, que secretam grandes quantidades de anticorpos, ou em células B de memória [B02-F3]. Os anticorpos se ligam à superfície do patógeno e o marcam para destruição: ativam o complemento, facilitam a fagocitose (opsonização) e direcionam células efetoras [B02-F3]. Como consequência, anticorpos contêm a multiplicação de vírus na fase aguda, mas, uma vez estabelecida a infecção dentro das células, em geral não a eliminam; isso cabe à imunidade celular [B02-F3]. A ajuda dos T auxiliares torna a resposta B melhor e a memória mais eficaz do que a obtida por antígenos que dispensam T [B02-F5].

### 3. T auxiliares versus T citotóxicos

Os **T citotóxicos (CD8+)** reconhecem peptídeos em MHC de classe I. Como quase toda célula nucleada tem MHC I, uma célula infectada por vírus expõe fragmentos virais e é destruída pelo T citotóxico, que induz apoptose, a morte celular programada [B02-F3]. Os **T auxiliares (CD4+)** reconhecem peptídeos em MHC de classe II, exibidos por APCs. Eles não matam nem fagocitam; liberam citocinas que orientam outras células, incluindo B, macrófagos e as próprias APCs [B02-F3]. Em resumo: o citotóxico executa; o auxiliar coordena.

### 4. Expansão clonal e formação de memória

No início, existem poucos linfócitos capazes de reconhecer determinado antígeno. Ao serem ativados, esses poucos clones se multiplicam intensamente, um processo de vários dias chamado **expansão clonal**, gerando células efetoras que combatem a infecção atual [B02-F5]. Resolvida a infecção, a maioria das efetoras morre e é removida por fagócitos, mas algumas permanecem como células de memória, tanto T citotóxicas quanto T auxiliares [B02-F3]. Entre os B, formam-se plasmócitos de vida curta, que somem após a eliminação do agente, plasmócitos de vida longa, que mantêm a produção de anticorpos, e células B de memória, uma população distinta que aguarda o antígeno reaparecer [B02-F4]. A resposta primária elimina a infecção em cerca de uma semana, enquanto as células de vida longa se completam em semanas [B02-F4].

### 5. O reencontro com o antígeno

Na resposta secundária, há mais células específicas prontas, e o processo se repete com mais velocidade e melhor qualidade [B02-F4]. Anticorpos já presentes, produzidos por plasmócitos de vida longa, agem imediatamente; B e T de memória proliferam em poucos dias, e os anticorpos gerados têm maior afinidade e isotipo mais adequado, com predomínio de IgG em vez da IgM inicial [B02-F4; B02-F5]. Além disso, células B de memória precisam de menos antígeno para iniciar a resposta [B02-F4]. A consequência é que o patógeno pode ser contido antes de causar doença.

### 6. Vacinação e os limites da proteção

A vacina imita o estímulo de uma infecção sem produzir a doença ativa [B02-F5]. Ela fornece antígenos, frequentemente com adjuvantes que melhoram a resposta, para que a imunidade inata os detecte, as APCs os apresentem e a expansão clonal gere células efetoras e de memória [B02-F3; B02-F5]. Idealmente, induz vários níveis de memória: anticorpos que bloqueiam o acesso do patógeno e células B e T de memória caso ele ultrapasse essa barreira [B02-F4].

Os limites são concretos. Níveis elevados de anticorpos não garantem automaticamente proteção [B02-F4]. Contra patógenos de disseminação rápida, importa o anticorpo já presente, pois as células de memória não teriam tempo de proliferar [B02-F4]. Patógenos que mudam depressa podem escapar da memória formada contra versões anteriores [B02-F4]. E a idade pesa: recém-nascidos têm poucas células de memória, e a eficácia da memória tende a cair a partir dos 65 a 70 anos, reduzindo o sucesso vacinal [B02-F4].

## Exemplo explicado

**Situação inicial:** um adulto jovem recebe uma vacina hipotética contendo proteínas de um vírus respiratório com adjuvante. Ele nunca teve contato com esse vírus.

**Etapas:** no local da aplicação, células inatas detectam o adjuvante e o antígeno; dendríticas captam as proteínas e as apresentam em MHC II nos linfonodos. T auxiliares específicos são ativados; B específicos reconhecem a proteína íntegra, recebem ajuda dos T auxiliares e se expandem, gerando plasmócitos e B de memória. Em semanas, existem anticorpos circulantes, plasmócitos de vida longa e células B e T de memória [B02-F3; B02-F4].

**Contato posterior:** meses depois, a pessoa inala o vírus. Anticorpos já presentes se ligam às partículas e reduzem a entrada nas células; B de memória viram rapidamente plasmócitos; T de memória se tornam efetores em poucos dias. Se algumas células forem infectadas, T citotóxicos as eliminam via MHC I.

**Interpretação:** a infecção é contida mais rápido e com menos dano do que na primeira exposição.

**Limite:** se o vírus circulante tiver mudado suas proteínas, ou se a pessoa fosse idosa com resposta primária fraca, a memória poderia ser insuficiente. O exemplo ilustra o mecanismo, não prediz o resultado em um indivíduo específico.

## Confusões a evitar

1. **Anticorpo é o mesmo que memória.** Não: o anticorpo é uma proteína secretada por plasmócitos, com duração limitada; a célula de memória é um linfócito que permanece vivo e pode gerar nova resposta. Anticorpos podem cair sem que a memória celular desapareça [B02-F3; B02-F4].

2. **Ter memória ou anticorpos garante proteção.** Não: a proteção depende de quantidade, localização e afinidade dos anticorpos, da velocidade do patógeno, de sua variação e do estado imune do indivíduo [B02-F4].

## Confira seu entendimento

1. **Por que a resposta secundária é mais rápida que a primária?**
   Resposta comentada: porque, após a expansão clonal da primeira resposta, sobram muitas células específicas de memória, e não poucos linfócitos virgens. Elas precisam de menos antígeno, proliferam em dias e já produzem anticorpos de maior afinidade; além disso, plasmócitos de vida longa mantêm anticorpos prontos [B02-F4].

2. **No exemplo, por que a vacina com proteínas do vírus ainda permitiu ação de T citotóxicos na infecção posterior?**
   Resposta comentada: T citotóxicos reconhecem peptídeos em MHC I de células infectadas. Na infecção real, o vírus se replica dentro das células, que passam a exibir esses peptídeos; T de memória gerados pela vacina se diferenciam em efetores e induzem apoptose das células infectadas [B02-F3].

## Síntese

- A imunidade inata detecta o agente e, via APCs e MHC, ativa linfócitos T e B específicos, que se expandem clonalmente.
- Plasmócitos secretam anticorpos; T citotóxicos destroem células infectadas; T auxiliares coordenam; sobrevivem células de memória de ambos os tipos.
- A vacinação induz esses mecanismos sem doença, mas proteção depende do patógeno, da idade e da qualidade da resposta, não apenas da presença de anticorpos.

## Fontes consultadas

- [B02-F3] Marshall, J. S. et al. *An introduction to immunology and immunopathology.* Allergy, Asthma & Clinical Immunology, 2018;14(Suppl 2):49. Seções: The immune system: innate and adaptive immunity; Antibody-mediated vs. cell-mediated immunity; Passive vs. active immunization. Consulta às notas de leitura e ao texto original em inglês incorporado ao pacote. https://doi.org/10.1186/s13223-018-0278-1
- [B02-F4] Bugya, Z. et al. *Multiple Levels of Immunological Memory and Their Association with Vaccination.* Vaccines, 2021;9(2):174. Seções: 1, 7, 11, 13, 14. Consulta às notas de leitura e ao texto original em inglês incorporado ao pacote. https://doi.org/10.3390/vaccines9020174
- [B02-F5] Clem, A. S. *Fundamentals of vaccine immunology.* Journal of Global Infectious Diseases, 2011;3(1):73. Seções: Components of the immune system; Types of immunization; Stimulation of immunity by vaccines; Summary. Consulta indireta, somente pelas notas de leitura fornecidas. https://doi.org/10.4103/0974-777X.77299

As obras-base Janeway (Immunobiology) e Alberts (Molecular Biology of the Cell) não foram consultadas nesta preparação.