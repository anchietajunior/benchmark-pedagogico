# Resposta imune adaptativa e memória imunológica

## Ideia central
O problema central é entender como o sistema imune adaptativo reconhece um antígeno específico, organiza uma resposta efetora contra ele e, ao mesmo tempo, forma memória para responder melhor em um contato futuro. O objetivo é compreender os papéis dos linfócitos B e T, a diferença entre anticorpos e células de memória e a relação desse processo com a vacinação.

## Conceitos necessários
**Antígeno** é uma estrutura estranha capaz de ser reconhecida pelo sistema imune, como componentes de microrganismos, vírus, toxinas ou células tumorais [B02-F3]. A **imunidade inata** age rápido, não é específica e não tem memória; ela detecta padrões comuns por receptores de reconhecimento de padrões e mobiliza células apresentadoras de antígeno (APC) [B02-F3]. A **imunidade adaptativa** é antígeno-específica, mais lenta na primeira exposição e tem memória [B02-F3].

As **APC**, especialmente células dendríticas, fagocitam o antígeno, processam-no e exibem peptídeos em moléculas de **MHC**. MHC de classe I apresenta peptídeos intracelulares a linfócitos T CD8+; MHC de classe II apresenta peptídeos extracelulares a linfócitos T CD4+ [B02-F3]. O **TCR** é o receptor do linfócito T; o **BCR** é o anticorpo de superfície do linfócito B, que reconhece antígeno nativo diretamente [B02-F3]. **Plasmócitos** são células que secretam anticorpos; **células de memória** são células de vida longa que permanecem prontas para responder [B02-F3; B02-F4].

## Mecanismo passo a passo

### 1. Antígeno, resposta inata e apresentação
Quando um agente entra no organismo, a imunidade inata detecta padrões moleculares e produz citocinas que recrutam células e ativam APC [B02-F3]. Células dendríticas fagocitam o agente, digerem suas proteínas e apresentam peptídeos ligados ao MHC. Esse passo conecta a inata à adaptativa: sem apresentação, os linfócitos T específicos dificilmente encontram o antígeno no contexto correto [B02-F3; B02-F5].

### 2. Linfócitos B, plasmócitos e anticorpos
O linfócito B reconhece o antígeno nativo por seu BCR, sem precisar de APC, embora também possa atuar como APC [B02-F3]. Ativado, ele prolifera e se diferencia em plasmócitos secretores de anticorpos ou em células B de memória. Citocinas de T auxiliares ajudam o B a se multiplicar e orientam o tipo de anticorpo [B02-F3]. Os anticorpos se ligam ao antígeno, neutralizam toxinas ou vírus, facilitam fagocitose por opsonização e ativam complemento [B02-F3]. A fonte B02-F4 distingue plasmócitos de vida curta, da resposta inicial, e plasmócitos de vida longa, que mantêm anticorpos; a B02-F3 enfatiza que muitos plasmócitos são relativamente curto-lived. Já as células B de memória são outra população, que sobrevive e responde rapidamente na reexposição [B02-F3; B02-F4].

### 3. T auxiliares e T citotóxicos
Os **T auxiliares CD4+** reconhecem peptídeo em MHC de classe II. Eles não matam células infectadas nem eliminam patógenos diretamente; liberam citocinas que dirigem outras células, como B, macrófagos e T citotóxicos [B02-F3]. Os **T citotóxicos CD8+** reconhecem peptídeo em MHC de classe I e induzem apoptose de células infectadas ou tumorais [B02-F3]. Assim, CD4+ organiza a resposta; CD8+ executa a destruição de células-alvo.

### 4. Expansão clonal e células de memória
Linfócitos específicos que encontraram seu antígeno sofrem expansão clonal: proliferam e geram células efetoras [B02-F3; B02-F5]. Resolvida a infecção, a maioria das efetoras morre; poucas permanecem como células de memória T e B [B02-F3]. Células B de memória mantêm receptores e podem responder rapidamente; T de memória também podem se diferenciar rapidamente em efetoras [B02-F3; B02-F4]. Portanto, memória não é o mesmo que anticorpo circulante: é uma população celular persistente.

### 5. Novo contato com o mesmo antígeno
Na reexposição, há mais células específicas prontas. Anticorpos de alta afinidade produzidos por plasmócitos de vida longa podem agir de imediato; células B e T de memória proliferam em poucos dias [B02-F4]. A resposta secundária repete a primária com mais velocidade e melhor qualidade, com anticorpos de maior afinidade e isotipo mais adequado, tipicamente IgG [B02-F4; B02-F5]. Células B de memória também reduzem a quantidade mínima de antígeno necessária para iniciar resposta, vantagem usada em reforços vacinais [B02-F4].

### 6. Vacinação e limites da proteção
A vacinação é uma forma de **imunização ativa**: busca gerar resposta e memória sem causar a doença [B02-F4; B02-F5]. Ela imita o estímulo inicial, mobiliza inata, APC, MHC, T e B, e idealmente produz anticorpos e células de memória [B02-F4; B02-F5]. Porém, níveis elevados de anticorpos não garantem proteção automaticamente [B02-F4]. A proteção depende do patógeno: contra disseminação rápida, conta sobretudo o anticorpo já presente; contra disseminação lenta, células B de memória têm tempo de proliferar [B02-F4]. Patógenos variáveis podem escapar da memória, e idade, estado imune e comorbidades alteram a resposta [B02-F4]. Anticorpos que se ligam sem inativar podem até facilitar entrada do microbe em células, fenômeno chamado ADE [B02-F4]. Logo, memória imunológica melhora a resposta, mas não é proteção absoluta.

## Exemplo explicado
Imagine uma pessoa que recebe uma vacina hipotética contra o “agente Y”. Situação inicial: ela nunca teve contato com Y. Após a vacinação, a inata detecta componentes da vacina, APC processam antígenos e os apresentam em MHC. Linfócitos T CD4+ ajudam linfócitos B específicos; alguns B viram plasmócitos que produzem anticorpos, outros viram células B de memória; T CD8+ também podem gerar memória. Semanas depois, a resposta primária se consolida.

Meses depois, a pessoa entra em contato com Y. Se houver anticorpos suficientes, eles podem neutralizar o agente logo no início. Se o agente ultrapassar essa barreira, células B e T de memória proliferam e geram nova onda de efetoras. O resultado esperado é uma resposta mais rápida e intensa que na primeira vez. Interpretação: a memória contribui para reduzir a chance de doença grave. Limite: se a dose for muito alta, o patógeno se espalhar muito rápido, for uma variante que escapa dos anticorpos ou se a pessoa tiver resposta imune enfraquecida, ainda pode adoecer. O exemplo é didático e não define dose, diagnóstico ou conduta individual.

## Confusões a evitar
1. **“Anticorpo é a mesma coisa que célula de memória.”** Não. Anticorpos são proteínas secretadas por plasmócitos; células de memória são células de vida longa que continuam capazes de responder. Medir anticorpos não mede toda a memória celular [B02-F3; B02-F4].
2. **“Ter memória significa proteção absoluta.”** Não. A proteção depende da quantidade e qualidade dos anticorpos, da velocidade de disseminação do patógeno, de variantes, da idade e do estado imune. Anticorpos podem não neutralizar e até facilitar entrada por ADE [B02-F4].

## Confira seu entendimento
1. **Por que a resposta secundária costuma ser mais rápida que a primária?**
**Resposta comentada:** porque já existem mais linfócitos específicos de memória e, muitas vezes, plasmócitos de vida longa produzindo anticorpos de maior afinidade. Assim, a etapa de encontro, seleção e expansão clonal é encurtada, e a resposta efetora aparece em menos tempo [B02-F4].

2. **No exemplo da vacinação, se a pessoa tem poucos anticorpos detectáveis, ela ainda pode ter alguma proteção?**
**Resposta comentada:** sim, potencialmente, porque células B e T de memória podem ser reativadas e produzir resposta rápida. Contudo, isso não garante proteção: depende da velocidade do patógeno, da quantidade de antígeno e da capacidade funcional dessas células [B02-F4].

## Síntese
- A resposta adaptativa reconhece antígenos específicos com BCR e TCR, com ajuda de APC e MHC, e gera efetoras e memória [B02-F3].
- Linfócitos B produzem anticorpos via plasmócitos; linfócitos T CD4+ coordenam e T CD8+ matam células infectadas; a memória é mantida por células B e T de memória [B02-F3; B02-F4].
- Vacinas ativam esses mecanismos, mas a proteção é relativa: depende do patógeno, do tempo, da variabilidade e do estado imune do indivíduo [B02-F4; B02-F5].

## Fontes consultadas
- [B02-F3] Marshall, J. S.; Warrington, R.; Watson, W.; Kim, H. L. *An introduction to immunology and immunopathology*. Allergy, Asthma & Clinical Immunology, 2018;14(Suppl 2):49. Seções consultadas: The immune system: innate and adaptive immunity; Antibody-mediated vs. cell-mediated immunity; Passive vs. active immunization. Texto original em inglês fornecido; paráfrase/notas de leitura também disponíveis. DOI: https://doi.org/10.1186/s13223-018-0278-1.
- [B02-F4] Bugya, Z.; Prechl, J.; Szénási, T.; Nemes, É.; Bácsi, A.; Koncz, G. *Multiple Levels of Immunological Memory and Their Association with Vaccination*. Vaccines, 2021;9(2):174. Seções consultadas: Introduction; T Dependent B Cell Memory, Intrafollicular B Cell Activation; Age-Dependence of Immunological Memory; Immunity in the Elderly; Conclusions. Texto original em inglês fornecido; paráfrase/notas de leitura também disponíveis. DOI: https://doi.org/10.3390/vaccines9020174.
- [B02-F5] Clem, A. S. *Fundamentals of vaccine immunology*. Journal of Global Infectious Diseases, 2011;3(1):73. Seções consultadas: Components of the immune system; Types of immunization; Stimulation of immunity by vaccines; Summary. Consulta indireta por notas de leitura; o texto original não foi incorporado a este pacote. DOI: https://doi.org/10.4103/0974-777X.77299.
- O pacote informa que as obras-base Janeway (Immunobiology) e Alberts (Molecular Biology of the Cell) não foram consultadas nesta preparação; portanto, não foram usadas como fonte direta.