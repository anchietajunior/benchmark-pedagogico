# Hemostasia e coagulação: como uma pequena lesão vascular é vedada e controlada

## Ideia central

Quando um pequeno vaso se rompe, o sangue precisa parar de sair, mas o restante da circulação deve continuar fluida. A hemostasia resolve esse problema em duas frentes integradas: um tampão de plaquetas rápido, porém frágil, e uma rede de fibrina que o reforça. Em paralelo, inibidores naturais e a fibrinólise mantêm a resposta restrita ao local da lesão e a desfazem após o reparo [B01-F3]. O objetivo aqui é entender essa cooperação entre vaso, plaquetas e proteínas plasmáticas.

## Conceitos necessários

**Endotélio**: camada de células que reveste o interior do vaso; quando íntegro, é antitrombótico, pois produz óxido nítrico e prostaciclina, que desfavorecem a agregação plaquetária [B01-F2, notas].

**Subendotélio**: tecido sob o endotélio, rico em colágeno, fator von Willebrand (vWF) e fator tecidual (TF), normalmente separado do sangue [B01-F3].

**Plaquetas**: fragmentos celulares sem núcleo que carregam grânulos com ADP, cálcio, fibrinogênio e fator V, entre outros [B01-F3].

**Fatores de coagulação**: proteínas plasmáticas, em geral zimogênios (enzimas inativas), ativadas em sequência; a forma ativa recebe o sufixo "a" [B01-F3].

**Trombina**: enzima central que converte fibrinogênio (solúvel) em fibrina (insolúvel) [B01-F3].

**Fibrinólise**: dissolução enzimática da fibrina pela plasmina [B01-F2, notas; B01-F3].

## Mecanismo passo a passo

### 1. A lesão muda o vaso

A ruptura provoca vasoconstrição arteriolar, mediada por reflexo neurogênico e por mediadores locais como endotelina e tromboxano A2 (TxA2); o estreitamento reduz a perda de sangue [B01-F3; B01-F4, notas]. Mais importante, a lesão expõe ao sangue o subendotélio trombogênico. Colágeno e vWF passam a servir de ancoragem para plaquetas, e o TF, antes escondido na parede vascular, encontra o fator VII plasmático [B01-F3]. É essa exposição de componentes normalmente isolados que dispara a resposta.

### 2. Adesão, ativação e agregação

Na **adesão**, o vWF forma uma ponte entre o colágeno exposto e o receptor GpIb da plaqueta [B01-F3]. Aderida, a plaqueta se **ativa**: muda de forma, emite pseudópodes e libera o conteúdo dos grânulos. O ADP e o TxA2 liberados recrutam e ativam plaquetas vizinhas, e o cálcio se liga a fosfolipídios expostos na membrana, criando uma superfície para os fatores de coagulação [B01-F3]. Na **agregação**, o ADP altera a conformação do receptor GpIIb/IIIa, que passa a ligar fibrinogênio; como cada molécula de fibrinogênio conecta duas plaquetas, forma-se o tampão plaquetário, que veda temporariamente a lesão [B01-F2, notas; B01-F3].

### 3. Da ativação dos fatores à trombina e à fibrina

O modelo atual descreve a coagulação em fases sobre superfícies celulares [B01-F3]. Na **iniciação**, o complexo TF–VIIa ativa os fatores IX e X; o Xa gera uma pequena quantidade de trombina. Na **amplificação**, essa trombina ativa os fatores V e VIII, que são cofatores: aceleram, respectivamente, a produção de trombina pelo Xa e a produção de Xa pelo IXa. Na **propagação**, os complexos tenase (IXa–VIIIa) e protrombinase (Xa–Va, fosfolipídios e cálcio) montados sobre a plaqueta convertem protrombina em trombina em grande quantidade [B01-F3]. A trombina, então, cliva o fibrinogênio em fibrina insolúvel. Por isso as vias "intrínseca" e "extrínseca" não são circuitos independentes no organismo: a via do TF inicia, e a via intrínseca amplifica [B01-F2, notas; B01-F3].

### 4. Estabilização e integração

Os monômeros de fibrina polimerizam entre as plaquetas agregadas. A trombina ativa também o fator XIII, que cria ligações covalentes cruzadas entre os polímeros, dando resistência mecânica à rede [B01-F3]. A rede sustenta o tampão e pode reter hemácias; a contração das plaquetas aproxima as bordas da ferida, facilitando o reparo [B01-F4, notas]. A integração é bidirecional: as plaquetas fornecem a superfície e os fosfolipídios sem os quais a trombina não se forma em escala, e a trombina, além de gerar fibrina, ativa mais plaquetas [B01-F3]. Hemostasia primária e secundária são, portanto, etapas de um mesmo processo.

### 5. Limitação e fibrinólise

Vários mecanismos mantêm a coagulação local. O TFPI inibe o complexo TF–VIIa e o Xa, encerrando a iniciação. A **antitrombina**, ativada por heparan sulfato do endotélio, neutraliza trombina, Xa e outras enzimas [B01-F2, notas; B01-F3]. A trombina que escapa do local e encontra endotélio íntegro liga-se à **trombomodulina** e ativa a **proteína C**, que, com a proteína S, inativa Va e VIIIa, interrompendo a amplificação [B01-F2, notas; B01-F3]. Além disso, a prostaciclina endotelial contrabalança o TxA2, restringindo a agregação [B01-F3]. Na **fibrinólise**, o tPA liberado pelo endotélio converte plasminogênio ligado à fibrina em plasmina, que degrada a rede em produtos de degradação; PAI, α2-antiplasmina e TAFI evitam que essa dissolução seja prematura ou generalizada [B01-F2, notas; B01-F3].

### 6. Hemostasia versus trombose

A hemostasia é uma resposta a uma lesão, localizada e transitória: o coágulo se forma no defeito, é limitado por inibidores e é removido após o reparo [B01-F3; B01-F5, notas]. A **trombose** ocorre quando coágulos se formam dentro de um vaso sem lesão evidente ou de forma desproporcional, podendo obstruir o fluxo e comprometer órgãos, como na trombose venosa profunda [B01-F5, notas]. O desequilíbrio surge quando a atividade pró-coagulante aumenta ou os inibidores naturais diminuem, como nas deficiências de antitrombina, proteína C ou S [B01-F3]. Portanto, localização e controle é o que separa a mesma bioquímica em função protetora ou dano.

## Exemplo explicado

**Situação inicial**: um corte superficial rompe uma arteríola da pele. O sangue passa a escapar e entra em contato com colágeno, vWF e TF do subendotélio.

**Etapas**: a arteríola contrai; plaquetas aderem via vWF–GpIb, ativam-se e liberam ADP e TxA2, recrutando vizinhas; o fibrinogênio as une pelo GpIIb/IIIa e o sangramento diminui em minutos. Simultaneamente, o TF–VIIa inicia a geração de trombina, amplificada sobre as plaquetas ativadas; a trombina forma fibrina, e o XIIIa a reticula, criando um coágulo firme. Nas bordas, endotélio íntegro ativa proteína C e antitrombina, impedindo a extensão. Dias depois, tPA e plasmina dissolvem a fibrina enquanto o tecido cicatriza [B01-F3; B01-F4, notas].

**Interpretação**: um tampão só de plaquetas resistiria mal ao fluxo; a fibrina o transforma em vedação estável, e os inibidores garantem que ela fique só ali.

**Limite**: este é um cenário didático de lesão pequena; lesões extensas, deficiências de plaquetas ou de fatores alteram o resultado [B01-F4, notas], e nada aqui constitui diagnóstico.

## Confusões a evitar

1. **"Existem duas cascatas paralelas e independentes, intrínseca e extrínseca."** Essa divisão descreve testes laboratoriais in vitro. No organismo, o TF inicia a coagulação e a via intrínseca amplifica a trombina gerada; por isso deficiências de VIII ou IX causam hemofilia, embora a "outra via" esteja intacta [B01-F3].

2. **"Anticoagulantes naturais e fibrinólise são a mesma coisa."** Antitrombina, TFPI e proteína C impedem a *produção* de nova fibrina; a plasmina *degrada* fibrina já formada. São mecanismos distintos, com alvos e momentos diferentes [B01-F2, notas].

## Confira seu entendimento

1. **Por que a trombina inicialmente gerada pelo TF–VIIa não basta e como ela própria resolve essa limitação?**

Resposta comentada: a iniciação produz pouca trombina e é rapidamente contida pelo TFPI. Essa trombina, porém, ativa os fatores V e VIII, cofatores que aceleram a protrombinase e a tenase sobre as plaquetas, e ativa mais plaquetas. Trata-se de retroalimentação positiva: o produto amplifica sua própria formação, permitindo a fase de propagação e fibrina suficiente [B01-F3].

2. **No exemplo do corte, o que impediria que o coágulo avançasse pela arteríola além da ferida?**

Resposta comentada: fora da lesão, o endotélio está íntegro. Ali a trombina encontra trombomodulina, que a converte em ativadora de proteína C; com a proteína S, esta inativa Va e VIIIa, cortando a amplificação. O heparan sulfato endotelial ativa a antitrombina, e a prostaciclina inibe a agregação. Assim, o mesmo mediador que constrói o coágulo no local passa a limitá-lo onde não há dano [B01-F2, notas; B01-F3].

## Síntese

- A lesão expõe colágeno, vWF e TF, disparando simultaneamente o tampão plaquetário e a geração de trombina, que se reforçam mutuamente sobre a superfície das plaquetas.
- A fibrina reticulada pelo XIIIa estabiliza um tampão que, sozinho, seria frágil; por isso hemostasia primária e secundária são inseparáveis.
- TFPI, antitrombina e proteína C limitam a coagulação ao local, e a fibrinólise remove a fibrina depois; sem esses controles, a resposta protetora vira trombose.

## Fontes consultadas

- [B01-F3] Palta, S.; Saroa, R.; Palta, A. *Overview of the coagulation system*. Indian Journal of Anaesthesia, 2014;58(5):515-523. Texto original em XML fornecido no pacote (seções Primary haemostasis, Clotting factors, Naturally occurring anticoagulants, Coagulation cascade, Current concept of coagulation, Thrombotic disorders, Fibrinolytic system), além de notas de leitura. https://doi.org/10.4103/0019-5049.144643
- [B01-F2] MSD Manual, versão profissional. *Overview of Hemostasis*. Seções Platelets, Plasma Coagulation Factors, Regulation of Coagulation. Consulta indireta, por notas de leitura. https://www.msdmanuals.com/professional/hematology/hemostasis/overview-of-hemostasis
- [B01-F4] NHLBI/NIH. *How Does Blood Clot?* Texto explicativo. Consulta indireta, por notas de leitura. https://www.nhlbi.nih.gov/health/clotting-disorders/how-blood-clots
- [B01-F5] NHLBI/NIH. *What Are Blood Clotting Disorders?* Apresentação do tema. Consulta indireta, por notas de leitura. https://www.nhlbi.nih.gov/health/clotting-disorders