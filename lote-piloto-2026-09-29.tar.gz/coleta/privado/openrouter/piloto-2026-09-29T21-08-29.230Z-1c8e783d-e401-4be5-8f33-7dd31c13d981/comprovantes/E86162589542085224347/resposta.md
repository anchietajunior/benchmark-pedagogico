# Hemostasia: conter o sangramento sem bloquear a circulação

## Ideia central

Uma pequena lesão vascular exige duas respostas coordenadas: fechar a abertura por onde o sangue escapa e impedir que esse fechamento se espalhe pela circulação. **Hemostasia** é a contenção fisiológica do sangramento, resultado da cooperação entre parede vascular, plaquetas e proteínas da coagulação. Seu objetivo não é solidificar todo o sangue, mas produzir uma vedação localizada e temporária. [B01-F3]

## Conceitos necessários

O **endotélio** é a camada celular que reveste internamente os vasos. Quando íntegro, separa o sangue de componentes que favorecem a coagulação e ajuda a impedir a adesão plaquetária. Sob ele há **colágeno**, proteína estrutural que, quando exposta, participa do recrutamento de plaquetas. [B01-F3]

As **plaquetas** são fragmentos celulares que formam o tampão inicial e oferecem superfície para reações da coagulação. O **fator von Willebrand**, proteína adesiva, ajuda a prendê-las à área lesionada. [B01-F3]

Os **fatores de coagulação** incluem precursores de enzimas e proteínas auxiliares que organizam sua atividade. A letra “a” indica a forma ativada de um fator. A **trombina** é uma enzima formada a partir da protrombina; ela transforma o **fibrinogênio**, proteína solúvel, em **fibrina**, que forma uma rede de sustentação. [B01-F3]

## Mecanismo passo a passo

### 1. A lesão muda a superfície e o calibre vascular

A lesão desencadeia **vasoconstrição**, isto é, estreitamento local do vaso, reduzindo a perda sanguínea. Ao romper a barreira endotelial, também expõe colágeno e permite contato do sangue com o **fator tecidual**, proteína de membrana que inicia a coagulação. Assim, a mesma abertura que permite o sangramento revela superfícies capazes de iniciar sua contenção. [B01-F3; B01-F4, notas de leitura]

### 2. As plaquetas aderem, ativam-se e agregam-se

Na **adesão**, a plaqueta prende-se à região lesionada. O fator von Willebrand funciona como ligação entre o colágeno e o receptor plaquetário GPIb, uma proteína de superfície que o reconhece. [B01-F3]

Na **ativação**, as plaquetas mudam de forma e liberam sinais, como ADP, além de produzirem tromboxano A2. Esses mediadores estimulam outras plaquetas, ampliando o recrutamento. A ativação também modifica o receptor IIb/IIIa, permitindo sua ligação ao fibrinogênio. [B01-F3]

Na **agregação**, moléculas de fibrinogênio conectam receptores IIb/IIIa de plaquetas vizinhas. Forma-se, portanto, um agregado preso à lesão: o tampão plaquetário. Ele oferece vedação inicial, mas ainda precisa de reforço para manter sua estabilidade. [B01-F2, notas de leitura]

### 3. A coagulação produz trombina e fibrina

O fator tecidual associa-se ao VIIa, formando um complexo que ativa os fatores IX e X. Isso inicia uma produção pequena de trombina. A trombina inicial ativa plaquetas e fatores auxiliares, como V e VIII, ampliando as condições para sua própria produção. [B01-F3, seção *Current concept of coagulation*]

Na superfície das plaquetas ativadas, IXa e seu auxiliar VIIIa favorecem a formação de mais Xa. O Xa, associado ao auxiliar Va, ao cálcio e aos **fosfolipídios**, componentes da membrana, constitui o complexo **protrombinase**. Esse conjunto converte protrombina em trombina com eficiência. A organização sobre superfícies celulares concentra e acelera as reações. [B01-F3]

A trombina então corta moléculas de fibrinogênio, originando unidades que se associam em fibras de fibrina. A consequência é transformar uma proteína solúvel em uma rede incorporada ao tampão. [B01-F3]

### 4. A fibrina estabiliza uma resposta integrada

A trombina também ativa o fator XIII, que estabelece ligações químicas entre as fibras de fibrina. Essas ligações reforçam a rede e tornam o conjunto plaquetas–fibrina mais resistente que o agregado inicial. [B01-F3]

A formação do tampão plaquetário é chamada **hemostasia primária**; a geração de fibrina, **hemostasia secundária**. São divisões didáticas, não processos independentes: plaquetas sustentam complexos produtores de trombina, e trombina ativa plaquetas e produz seu reforço de fibrina. As etapas se sobrepõem e se potencializam. [B01-F3]

### 5. Reguladores restringem a formação e controlam a remoção

O endotélio íntegro ao redor libera óxido nítrico e prostaciclina, que desfavorecem a ativação e a agregação plaquetária. Paralelamente, a **antitrombina**, proteína anticoagulante, neutraliza trombina e Xa, entre outras enzimas. O **TFPI**, inibidor da via do fator tecidual, restringe Xa e o complexo fator tecidual/VIIa. Esses mecanismos dificultam a expansão da resposta. [B01-F2, notas de leitura]

A **trombomodulina**, proteína da superfície endotelial, liga trombina e favorece a ativação da proteína C. Com auxílio da proteína S, a proteína C ativada inativa Va e VIIIa. Retirar esses auxiliares reduz a amplificação da produção de trombina. [B01-F2, notas de leitura]

A **fibrinólise** é a degradação da fibrina. O **tPA**, ativador tecidual do plasminogênio, converte o precursor plasminogênio em **plasmina**, enzima que corta a fibrina. Esse sistema participa da limitação e da remoção da rede, não apenas de uma limpeza iniciada depois de tudo terminar. Inibidores, como a alfa-2-antiplasmina, restringem sua atividade: a vedação precisa permanecer enquanto necessária ao reparo. [B01-F3; B01-F2, notas de leitura]

### 6. Hemostasia não é sinônimo de trombose

Na hemostasia fisiológica, a resposta contém uma perda sanguínea e permanece proporcional à necessidade. **Trombose** é a formação patológica de um coágulo dentro da circulação, capaz de prejudicar o fluxo e comprometer órgãos. Pode ocorrer sem lesão aparente, mas a ausência de lesão não é seu único critério: localização, extensão e controle também importam. [B01-F5, notas de leitura]

## Exemplo explicado

Imagine uma pequena lesão em um vaso da pele. Inicialmente, o sangue escapa porque a parede perdeu continuidade. O estreitamento vascular reduz essa perda enquanto plaquetas aderem ao colágeno exposto, ativam outras plaquetas e formam um agregado. [B01-F3; B01-F4, notas de leitura]

Ao mesmo tempo, o fator tecidual inicia a coagulação. As superfícies plaquetárias favorecem a produção de trombina, e a fibrina reforça o tampão. O resultado esperado é uma vedação estável, suficiente para conter o sangramento durante o reparo. Os reguladores restringem sua expansão, e a fibrinólise participa da remoção da fibrina. [B01-F3]

A interpretação é funcional: plaquetas fornecem fechamento inicial e superfície reacional; fibrina fornece sustentação. O limite do exemplo é que observar o sangramento parar não comprova que todos os componentes estejam normais nem permite diagnosticar alterações específicas.

## Confusões a evitar

1. **“Fibrinogênio e fibrina fazem a mesma coisa.”** O fibrinogênio solúvel conecta plaquetas durante a agregação; sua transformação pela trombina produz fibrina, que organiza a rede estabilizadora. São funções relacionadas, mas diferentes. [B01-F2, notas de leitura; B01-F3]

2. **“Anticoagulação e fibrinólise dissolvem o coágulo.”** Anticoagulantes naturais reduzem reações produtoras de trombina; a fibrinólise degrada fibrina já formada. Frear a produção não equivale a remover a estrutura existente. [B01-F2, notas de leitura]

## Confira seu entendimento

1. **Por que a ativação plaquetária favorece a produção de fibrina?**

   **Resposta comentada:** Ela oferece superfície para organizar complexos da coagulação. Esses complexos aumentam a geração de trombina, que transforma fibrinogênio em fibrina. Assim, a plaqueta participa tanto do tampão quanto de seu reforço. [B01-F3]

2. **No exemplo, qual seria o problema de o coágulo continuar crescendo além da lesão?**

   **Resposta comentada:** O fechamento deixaria de atender apenas à contenção do sangramento e poderia obstruir a circulação. Isso explica por que mecanismos anticoagulantes e endotélio íntegro são necessários mesmo quando a coagulação começou com uma função protetora. [B01-F2; B01-F5, notas de leitura]

## Síntese

- A lesão expõe sinais que coordenam vasoconstrição, adesão plaquetária e início da coagulação.
- Plaquetas favorecem a produção de trombina; fibrina estabiliza o tampão, integrando hemostasia primária e secundária.
- Regulação e fibrinólise equilibram vedação, remoção e preservação do fluxo sanguíneo.

## Fontes consultadas

- **[B01-F3]** Palta, S.; Saroa, R.; Palta, A. *Overview of the coagulation system*. 2014;58(5):515–523. Consulta ao texto original incorporado, especialmente “Primary haemostasis”, “Common pathway”, “Current concept of coagulation”, “Naturally occurring anticoagulants in the body” e “Fibrinolytic system”. https://doi.org/10.4103/0019-5049.144643
- **[B01-F2]** MSD Manual. *Overview of Hemostasis*. Consulta indireta pelas notas de leitura fornecidas, referentes a “Platelets”, “Plasma Coagulation Factors” e “Regulation of Coagulation”. https://www.msdmanuals.com/professional/hematology/hemostasis/overview-of-hemostasis
- **[B01-F4]** NHLBI/NIH. *How Does Blood Clot?* Consulta indireta pelas notas fornecidas sobre o texto explicativo, atualizado em 24/03/2022. https://www.nhlbi.nih.gov/health/clotting-disorders/how-blood-clots
- **[B01-F5]** NHLBI/NIH. *What Are Blood Clotting Disorders?* Consulta indireta pelas notas fornecidas sobre a apresentação do tema, atualizada em 24/03/2022. https://www.nhlbi.nih.gov/health/clotting-disorders