# Resposta imune adaptativa e memória imunológica

## Ideia central

O sistema imune protege o organismo contra agentes patogênicos por meio de defesas coordenadas [B02-F3]. O objetivo deste estudo é compreender como a resposta adaptativa reconhece especificamente um antígeno, mobiliza linfócitos B e T e estabelece memória imunológica duradoura capaz de mitigar infecções futuras, fundamentando o princípio biológico da vacinação [B02-F3, B02-F4].

## Conceitos necessários

- **Antígeno:** Qualquer estrutura molecular estranha ("não própria") capaz de ser reconhecida pelos receptores dos linfócitos da resposta adaptativa [B02-F3].
- **Células apresentadoras de antígenos (APCs):** Células da imunidade inata, como células dendríticas e macrófagos, especializadas em capturar, processar e exibir fragmentos antigênicos aos linfócitos T [B02-F3].
- **Complexo principal de histocompatibilidade (MHC):** Moléculas de superfície celular que exibem peptídeos antigênicos. O MHC de classe I está presente em todas as células nucleadas e expõe peptídeos intracelulares; o MHC de classe II ocorre em APCs e exibe peptídeos extracelulares fagocitados [B02-F3].
- **Linfócitos B:** Células que reconhecem antígenos em sua forma nativa por meio de seus receptores de superfície (BCR) [B02-F3].
- **Plasmócitos:** Células derivadas da diferenciação de linfócitos B ativados, responsáveis por sintetizar e secretar grandes volumes de anticorpos na circulação e tecidos [B02-F3, B02-F4].
- **Anticorpos (imunoglobulinas):** Proteínas circulantes solúveis que se ligam especificamente ao antígeno para neutralizá-lo ou marcá-lo para destruição [B02-F3].
- **Linfócitos T:** Células amadurecidas no timo que reconhecem peptídeos ligados a moléculas de MHC por meio do receptor de células T (TCR) [B02-F3].

## Mecanismo passo a passo

### 1. Reconhecimento inicial e apresentação de antígenos
Ao invadir o tecido, o patógeno é primeiramente confrontado pela imunidade inata [B02-F3]. APCs residentes, especialmente células dendríticas, detectam padrões moleculares comuns por meio de receptores de reconhecimento e fagocitam o patógeno [B02-F3]. No interior da APC, as proteínas do agente são digeridas enzimaticamente em pequenos fragmentos peptídicos [B02-F3]. Esses peptídeos são acoplados a moléculas de MHC de classe II e transportados à membrana celular [B02-F3]. Em seguida, a APC migra pelos vasos linfáticos até os linfonodos regionais, ambiente onde linfócitos virgens circulam, permitindo o encontro físico e a apresentação antigênica necessária para iniciar a resposta adaptativa [B02-F3].

### 2. Papel dos linfócitos B, plasmócitos e anticorpos
Os linfócitos B ligam-se a antígenos intactos e solúveis por meio de seus anticorpos de membrana [B02-F3]. Ao receberem sinais auxiliares de linfócitos T ativados, essas células B iniciam sua diferenciação [B02-F3, B02-F5]. Uma parcela transforma-se em plasmócitos de vida curta ou longa, verdadeiras fábricas celulares de anticorpos solúveis [B02-F3, B02-F4]. Inicialmente, os plasmócitos secretam imunoglobulina M (IgM) e, com estímulo adequado, passam a secretar imunoglobulina G (IgG) [B02-F3, B02-F5]. Esses anticorpos ligam-se aos alvos extracelulares, bloqueando sua entrada em células do hospedeiro (neutralização) e cobrindo sua superfície para facilitar a ingestão por fagócitos (opsonização) ou ativar o sistema complemento [B02-F3].

### 3. Diferenciação funcional dos linfócitos T
Os linfócitos T dividem-se em duas linhagens principais com papéis funcionais distintos [B02-F3]:
- **Linfócitos T auxiliares (CD4+):** Reconhecem antígenos acoplados a moléculas de MHC de classe II em APCs [B02-F3]. Não destroem células infectadas diretamente nem fagocitam partículas; atuam como reguladores centrais mediante secreção de citocinas que estimulam a multiplicação de linfócitos B, orientam a classe dos anticorpos e potencializam macrófagos [B02-F3].
- **Linfócitos T citotóxicos (CD8+):** Reconhecem peptídeos acoplados ao MHC de classe I em células infectadas [B02-F3]. Quando ativados, liberam substâncias que induzem a apoptose (morte celular programada) da célula-alvo, eliminando reservatórios intracelulares de patógenos, como vírus [B02-F3].

### 4. Expansão clonal e formação de memória
Quando um linfócito B ou T específico reconhece seu antígeno cognato, ele é selecionado e recebe sinais de sobrevida, iniciando sucessivas divisões mitóticas, fenômeno denominado expansão clonal [B02-F3, B02-F4, B02-F5]. Esse processo multiplica clones idênticos capazes de responder àquele agente [B02-F3]. A maior parte desses clones diferencia-se em células efetoras de vida curta, encarregadas de erradicar a infecção imediata [B02-F3, B02-F4]. Após a depuração antigênica, a maioria das células efetoras morre por apoptose [B02-F3]. Contudo, uma fração persiste no organismo como células de memória de vida longa (linfócitos B de memória e linfócitos T CD4+ e CD8+ de memória), além de plasmócitos de vida longa na medula óssea [B02-F3, B02-F4].

### 5. Resposta secundária de memória
Em um novo contato com o mesmo antígeno, o sistema imune não parte do estado basal [B02-F4]. Células de memória específicas estão em maior número e possuem limiar de ativação inferior ao de linfócitos virgens [B02-F4]. Ao detectarem o antígeno, os linfócitos B de memória proliferam rapidamente e diferenciam-se em plasmócitos que produzem anticorpos com maior afinidade, com rápida ascensão de IgG [B02-F3, B02-F4, B02-F5]. Simultaneamente, linfócitos T de memória geram novas células efetoras em poucos dias [B02-F4]. O tempo de latência diminui consideravelmente em relação à resposta primária, permitindo neutralizar o patógeno frequentemente antes do início de manifestações clínicas [B02-F3, B02-F4].

### 6. Vacinação ativa e limites de proteção
A vacinação é a imunização ativa artificial que expõe o organismo a antígenos inofensivos (microrganismos inativados, atenuados ou frações purificadas), muitas vezes combinados a adjuvantes para recrutar a imunidade inata [B02-F3]. Ela induz a resposta primária controlada, gerando plasmócitos de vida longa e células de memória T e B sem provocar o dano patológico da infecção natural [B02-F4]. Todavia, proteção vacinal não é absoluta [B02-F4]: patógenos com alta taxa de mutação podem alterar seus antígenos e escapar do reconhecimento de anticorpos prévios; patógenos de replicação fulminante podem lesar tecidos antes que células B de memória se multipliquem; e fatores individuais do hospedeiro, como envelhecimento imune (imunossenescência), reduzem a diversidade e eficácia da memória formada [B02-F4].

## Exemplo explicado

- **Situação inicial:** Um indivíduo jovem e saudável recebe uma vacina hipotética composta por antígenos proteicos purificados de uma bactéria extracelular fictícia.
- **Etapas:** 
  1. No local da injeção, APCs capturam os antígenos vacinais, migram ao linfonodo e apresentam os peptídeos via MHC de classe II a linfócitos T CD4+ virgens [B02-F3].
  2. Linfócitos B reconhecem o antígeno pelo seu receptor e recebem auxílio dos T CD4+ ativados, desencadeando expansão clonal [B02-F3, B02-F5].
  3. Diferenciam-se plasmócitos de vida curta que produzem IgM inicial, progredindo para IgG, e estabelece-se um contingente residual de linfócitos B de memória e plasmócitos de vida longa [B02-F3, B02-F4, B02-F5].
  4. Meses depois, o indivíduo é exposto à bactéria selvagem. Os anticorpos IgG circulantes opsonizam parte das bactérias de imediato, e as células B de memória ativam-se rapidamente, gerando grande surto de IgG que neutraliza o restante dos microrganismos em poucos dias [B02-F3, B02-F4].
- **Resultado interpretado:** A resposta secundária rápida bloqueou a disseminação da bactéria antes da instalação de doença clínica evidente.
- **Limite da conclusão:** A presença de células de memória garante rapidez de resposta, mas não imunidade absoluta [B02-F4]. Se a bactéria introduzida apresentar mutações nos seus epítopos de superfície ou sofrer alteração na expressão do antígeno, a memória prévia pode falhar em conter o processo infeccioso [B02-F4].

## Confusões a evitar

1. **Confundir anticorpos com células de memória:** Anticorpos são macromoléculas proteicas solúveis secretadas por plasmócitos que circulam nos fluidos corporais e possuem meia-vida finita [B02-F3, B02-F5]. Já as células de memória são células vivas (linfócitos B e T) que persistem por anos, preservam a identidade do antígeno e mantêm a capacidade de se dividir e produzir novas ondas celulares ao reencontrarem o agente patogênico [B02-F3, B02-F4].
2. **Supor que linfócitos T CD4+ destroem diretamente células infectadas:** Linfócitos T auxiliares (CD4+) não possuem maquinário citotóxico de lise ou indução direta de apoptose nas células-alvo [B02-F3]. Sua função é estritamente regulatória e mediada por citocinas para ativar macrófagos, orientar linfócitos B e coordenar outras células imunes, cabendo aos linfócitos T citotóxicos (CD8+) a destruição física direta de células infectadas [B02-F3].

## Confira seu entendimento

1. **Por que a deficiência na apresentação de antígenos por moléculas de MHC de classe II compromete a síntese robusta de anticorpos da classe IgG pelos linfócitos B?**  
   Resposta comentada: O linfócito B depende do auxílio de linfócitos T CD4+ para proliferar intensamente e realizar a troca de classe de anticorpos (de IgM para IgG de maior afinidade) [B02-F3, B02-F4, B02-F5]. Como a ativação dos linfócitos T CD4+ exige obrigatoriamente o reconhecimento de peptídeos exibidos em MHC de classe II pelas APCs, a falha nesse mecanismo bloqueia a ativação de T auxiliares e priva os linfócitos B dos sinais instrucionais essenciais para uma resposta humoral madura [B02-F3, B02-F4].

2. **No exemplo hipotético apresentado, por que uma pessoa idosa vacinada contra a mesma bactéria poderia contrair a doença ao se expor ao patógeno selvagem?**  
   Resposta comentada: O envelhecimento biológico acarreta imunossenescência, caracterizada pela involução tímica, menor diversidade de receptores T e B e falha funcional no suporte dos centros germinativos [B02-F4]. Consequentemente, idosos tendem a formar menos plasmócitos de vida longa e células de memória funcionais após a vacinação primária, gerando títulos inferiores de anticorpos e diminuindo a eficácia da resposta de memória frente ao contato subsequente com o patógeno [B02-F4].

## Síntese

- A resposta imune adaptativa depende do reconhecimento antigênico facilitado pelas células inatas (APCs via MHC para linfócitos T; antígenos intactos para linfócitos B), orquestrando linhagens T auxiliares e citotóxicas em conjunto com a imunidade humoral mediada por anticorpos [B02-F3].
- A expansão clonal multiplica clones antígeno-específicos e culmina na separação funcional entre células efetoras de combate imediato e células de memória de vida longa, que aceleram e qualificam respostas a contatos futuros [B02-F3, B02-F4, B02-F5].
- A vacinação emula esse mecanismo sem produzir dano patológico, porém a eficácia protetora enfrenta limitações reais decorrentes de variações antigênicas microbianas, cinética de disseminação do patógeno e estado imunológico individual do hospedeiro [B02-F3, B02-F4].

## Fontes consultadas

- **[B02-F3]** Marshall, J. S.; Warrington, R.; Watson, W.; Kim, H. L. An introduction to immunology and immunopathology. *Allergy, Asthma & Clinical Immunology*, 2018;14(Suppl 2):49. Seções consultadas: *The immune system: innate and adaptive immunity* (com subseções *Innate immunity*, *Adaptive immunity*, *T cells and APCs* e *B cells*), *Antibody-mediated vs. cell-mediated immunity*, *Passive vs. active immunization*. Texto original e notas de leitura fornecidos. Disponível em: <https://doi.org/10.1186/s13223-018-0278-1>.
- **[B02-F4]** Bugya, Z.; Prechl, J.; Szénási, T.; Nemes, É.; Bácsi, A.; Koncz, G. Multiple Levels of Immunological Memory and Their Association with Vaccination. *Vaccines*, 2021;9(2):174. Seções consultadas: *1. Introduction*, *7. T Dependent B Cell Memory, Intrafollicular B Cell Activation*, *11. Age-Dependence of Immunological Memory*, *13. Immunity in the Elderly*, *14. Conclusions*. Texto original e notas de leitura fornecidos. Disponível em: <https://doi.org/10.3390/vaccines9020174>.
- **[B02-F5]** Clem, A. S. Fundamentals of vaccine immunology. *Journal of Global Infectious Diseases*, 2011;3(1):73. Consulta indireta por meio de notas de leitura fornecidas das seções: *Components of the immune system*, *Types of immunization*, *Stimulation of immunity by vaccines*, *Summary*. Disponível em: <https://doi.org/10.4103/0974-777X.77299>.